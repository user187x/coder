# Changelog

All notable changes to this project will be documented in this file. For commit guidelines, please refer to [Standard Version](https://github.com/conventional-changelog/standard-version).

## v2.1.2

 **Security**:
 - [High] New accounts named with ".." breaks out of scoped folder on creation (GHSA-c84q-q5g6-r47f) -- reporter @dylanzonix
 - [Medium] Fixed session token collision issue when multiple users login simultaneously. (GHSA-c9cr-w724-gqj3) (#3135) Thanks @dl-pt reporters: @Ishtiaque-Ahmed-Risat @AlexWhiplash @tonghuaroot

 **Notes**:
 - Removed "Editor quick save" setting (`userDefaults.fileViewer.quickSave`), the save button is now always present in the editor toolbar. (#3122)
 - add Basque (eu) translation and fix Spanish (es) strings (#3118)

 **Bug Fixes**:
 - fix(webdav): OPTIONS now advertises only methods actually supported and permitted for the user; the DAV header reports class 1 only since LOCK/UNLOCK are not enabled (#3110)
 - fix(download): revalidate single-file downloads so a changed file is not served stale (#3133)
 - Language switcher not working (#3114) (#3117)
 - Viewer showing a stale image after the file changed on disk: single-file downloads are now revalidated by the browser (#3132)

## v2.1.1

Note: this release also contains all changes from v2.0.10-beta changelog

 **New Features**:
 - User and group picker with partial, case-insensitive search when creating access rules (#3085), assigning groups on user edit, and choosing members on group edit.
 - New `PUT /api/access/user-groups` endpoint that atomically replaces a user's group memberships.
 - feat(search): configure the advanced search result limit (#3058) @beemines
 - feat(listing): add sortable Date added and Type columns (#3052) @dweebzxx
 - feat(archive): suggest and preview ZIP filename encodings (#3024) @AnaTofuZ

 **Notes**:
 - Group API breaking changes: `POST /api/access` returns 400 when `ruleCategory=group` names a nonexistent group or `ruleCategory=user` names a nonexistent user, group endpoints return 400/409 instead of 500 for client errors, and `PUT /api/access/group` accepts a `create` flag and returns `unknownMembers`. Existing database records are unaffected; no migration is required.
 - update halloween theme (#3055)
 - Add soft wrap option to the editor config (#3063)
 - add better screenshot view handling (#3059)
 - Update nl.json (#3089) @Stephan-P
 - update german translations (#3062) @fehnomenal
 - Update dev dependencies, add biome, fix types and linting (#3075) @Kurami32

 **Bug Fixes**:
 - Groups assigned in the user edit prompt now refresh the Groups settings list.
 - Creating a group with an existing name now returns a conflict instead of silently overwriting its members.
 - Access rules can no longer create empty groups from typos; group rules must reference an existing group.
 - Empty group names are rejected and new group names must be 2-128 characters without control characters (existing records are unaffected); deleting or renaming a user now updates group memberships.
 - fix(auth): use login endpoint for existing TOTP authentication (#3074)
 - fix: apply theme toggles on anonymous public shares (#3049) @mvanhorn
 - fix(frontend): keep source named files in extractSourceFromPath (#3099) (#3095)
 - fix(auth): identify login fields for password autofill (#3077)
 - fix(backend): skip denied paths in multi-file downloads, 404 when none remain (#3100) @hippi345
 - fix: persist the user scope path chosen in the edit dialog (#3065) @mvanhorn

## v2.1.0

 **Security**:
 - [Moderate] Conflicting upload responses no longer synchronously drain the request body before returning HTTP 409; the server now closes the body and marks the connection for closure, preventing denial-of-service from clients that never send EOF (CWE-400).
 - Share download links no longer create links with token, instead they link to the UI prompting for password before download. If a direct download is required, the `/api/share/direct` api exists and documented by swagger. (#2888)

 **New Features**:
 - Added Storage Quotas
   - configurable by folder, source, user, and share.
   - Administrators can create, edit, view, and delete folder quotas through the interface.
   - Quota information now appears in source views, share details, sidebar progress bars, and folder prompts.
 - Enhancements to the editor (#2714):
   - Added a floating button to open a resizable split view with live editing for markdown files, the scrolling is synced in both sides and scrolling in single-view modes (the viewer and editor in non-split) now also tries to sync with each other so you don't lose context easily.
   - Added a toolbar: This toolbar is present on all the files.
     - JSON files have a button to toggle between formatted and minified versions (#2854) (#2566).
     - Markdown files have a richer toolbar with lots of quick actions, for example you can now browse, navigate and insert images more easily from your current source.
   - Added a prompt to configure some editor settings in UI, that prompt is accessible via the toolbar in the three-dots menu, there you can configure things like:
     - Word wrap, keybinds, autocompletion, scrollbar, etc.
   - The markdown viewer now supports rendering LaTeX Math and Chemistry formulas.
   - Improved and fixed some styles that weren't following the app light/dark theme (#2949).
 - Proxy auth group support: `groupsClaim`, `adminGroup`, and `userGroups` now control role-based access when the proxy sends a group/role header (#2755). Admin is determined by `adminGroup` only.
 - Moved `auth.adminUsername` and `auth.adminPassword` to `auth.methods.password` (legacy top-level keys are migrated automatically on load).
 - Support for `.elrc` (word-by-word lyrics), `.vtt`, `.srt` sidecar files for lyrics in audio files in the media player. (#2838)
 - Added setting to configure the placement of the prompts close button in profile settings (#2853) (#2595).
 - Added "New file templates". You can now add and configure pre-defined filenames + extension for the creation of new files in the context menu on profile settings! (#2881) (#1239).
 - sidebar links can be bulk edited as yaml (#1963) (settings > user management)
 - admins can customize more defaults:
   - share creation defaults and enforcements (#1692) (#2434) (#2279) (#2812) (settings > share management)
   - sidebar link defaults and enforcements (#2561) (settings > user management)
   - tool defaults and enforcement (settings > user management)
 - Add cli init CLI command (#2957)
 - Sort header in file listings inside prompts like move/copy/quick jump, is now sticky. Also added a button to show a search input and filter the items of the current listing (#3028).
 - Quick jump now scrolls and highlights the current item you are previewing (#3028).
 - When hovering `date` and `name` in the listings, will show up the formatted/raw date (the inverse of what you have configured to display) and the full filename (#3028) (#2623).
 - User groups can now be managed from the WebUI under `User Management` -> `Groups` and when editing a user (#2983) (#3040).

 **Notes**:
 - An Admin can remove a `defautlEnabled` source for a user and it will remove removed until an admin adds it back.
 - Enhancements to cross-source copy/move permissions and behavior.
 - Improved resume upload behavior.
 - Play/pause on videos in mobile now is toggled by the button in the middle rather than the whole container (#2828).
 - improved video thumbnail generation speed and efficiency.
 - Added icons based on extension to the upload prompt and new file/folder/rename prompts (#2881).
 - Profile settings show minimal options by default. Full advanced profile settings can be shown by default by enabling `account.showAdvancedProfile`.
 - sidebar links/navigation is button group toggle for clearer visibility
 - Pop-up preview has 200ms debounce delay so it doesn't flash from moving the cursor across files quickly.
 - Added risc-v to official releases
 - Polished a bit some styles across various places of the UI (#3019) (#3028).
 - Moved `Access Management` under `User Management` in the UI (#3040).
 - improved developer experience with native vue webhook reloads.
 - improved ffmpeg handling and concurrency via library upgrades

 **Bug Fixes**:
 - Undo in a fresh opened file on the editor was setting the file empty (#2714)
 - Added some missing styles in the markdown viewer (#2714)
 - Recaptcha not working (#1925) (#2861)
 - Fix disk-usage overstatement on virtiofs bind mounts (#2894)
 - Support non-ASCII share passwords (#2933)
 - Fall back to buffered copies when FUSE rejects fast paths (#2938)
 - Preserve deleted sidebar links across restarts (#2935)
 - scope padding to listing view (#2934)
 - Hide the Replace option on upload/create conflict prompts when the user lacks modify permission (or when a public share disallows replacements), so create-only users are not offered an action that the server rejects (#2837)
 - Preserve Ctrl-click file selection when keyboard state is stale (#2958) (#2923)
 - Avoid false stalls during parallel transfers (#2950) (#2948) thanks @gudcks0305
 - Cap source usage-bar percentage at 100% when indexed size exceeds partition total (#2761) (#2238)
 - On Linux, source partition totals sum distinct filesystems mounted under the source root (nested mounts) so usage bars match indexed content (#2761)
 - Context menu stuck when opened from a listing in a prompt like move/copy or search (#3028).

## v2.0.10

 **Security**:
 - [High] Restricted custom API tokens (`minimal=false`) can no longer be upgraded to a full-permission session via `POST /api/auth/renew`; renew accepts only web session tokens registered in `hashed_tokens` (GHSA-6gr6-5qpq-888p) -- thanks @tao0845.
 - [High] TOTP re-enrollment via `POST /api/auth/otp/generate` and `POST /api/auth/otp/verify` no longer allows anonymous callers to replace an existing second factor using only the account password; reset or replace requires an authenticated self or admin session (first-time enrollment without MFA unchanged) (GHSA-qx86-4v5r-26g5) -- thanks @tao0845.
 - [Low] Public share lyrics and subtitle media routes now honor the share's file-viewer setting, download disable flag, and download limits, matching the public download route (GHSA-p7x3-p5jj-9xfh) -- thanks Yves Soete of Blacksight LLC. @yssoe

 **New Features**:
 - Require password change at next login for password-based users: new user setting `requirePasswordChange` (user defaults + per-user admin toggle), login blocked until the user sets a new password; bootstrap admins with a generated initial password get this automatically ([#2977](https://github.com/gtsteffaniak/filebrowser/issues/2977)). Generated bootstrap passwords use a speakable `word-xxxxx-xx` form (random word from a fixed list plus a 5-character and 2-character code) instead of a long hex string, for easier handoff before the forced change.
 - Config YAML expands `$VAR` and `${VAR}` so values such as `userPassword: "${FILEBROWSER_LDAP_USER_PASSWORD}"` work as documented (#3042).

 **Notes**:
 - Sidebar navigation tree rows are real hyperlinks: middle-click, Ctrl/Cmd+click, and Shift+click use the browser’s default new-tab or new-window behavior.
 - Sidebar source links can now switch between aggregated usage (default) and a root-filesystem-only view via a new "Limit disk usage to source filesystem" toggle.
 - [docker] upgraded ffmpeg from 9.0 to 9.0.2
 - CLI setup command no longer produces full config, instead a minimal config.yaml with comments.

 **Bugfixes**:
 - Fixed slow or broken file listing when `http.baseURL` is a subpath (for example `/files/`): the default source redirect navigated to `/files/{source}` on top of the app base URL, producing `/files/files/{source}` and resolving the wrong storage source until the route recovered.
 - Anonymous visitors on public shares could not play inline video or audio: `GET /public/api/media/stream` returned 403 because view grants were validated before share context was fully hydrated; playback now works when download and the file viewer are allowed ([#3041](https://github.com/gtsteffaniak/filebrowser/issues/3041)).
 - Fixed inflated disk usage for sources spanning multiple ZFS datasets (or btrfs subvolumes): shared-pool filesystems are now grouped by pool and counted once, instead of multiplying capacity by the number of mounted datasets (#3025) (#2997) (#2761).
 - LDAP `userGroups` matching now accepts CN-only config values against full `memberOf` DNs and compares case-insensitively, instead of failing the shared auth helper with strict string equality (#3044).
 - OIDC session expires despite tokenExpirationHours (#3006).
 - Media playback becomes stuck after opening a failing media file since v2.0.8-beta (#3031)

## v2.0.9

 **Security**:
 - Fresh install with default `admin`/`admin` startup generates a random initial password and logs it once (#2977). Updated documentation to follow.
 - OIDC login binds OAuth `state` to an HttpOnly cookie (crypto-random) and rejects tampered callbacks; post-login redirects must be same-app relative paths.
 - Login, logout, and session-expiry redirects reject open-redirect targets (`//`, `/\\`, off-site URLs); signup sends credentials in a JSON body instead of query parameters.

 **Notes**:
 - Webdav always shows hidden files, ignores user preference. (#3004)
 - SQLite shared cache (`cache=shared`) removed from the application database connection: its table-lock conflicts bypass `busy_timeout` and fail immediately. WAL mode already allows concurrent readers.

 **Bugfixes**:
 - Fixed intermittent blank page / blocked inline SPA script after CSP hardening (#2995)
 - ffmpeg unresponsive lock issue (#2996)
 - fixed token migration lockout regression from v2.0.8-beta (#2999)
 - Public shares with OnlyOffice disabled (`enableOnlyOffice=false`) now reject `/office/config` and `/office/callback` requests server-side instead of only hiding the editor in the UI
 - Session/API token registrations now record the JWT expiry; expired mappings are pruned at startup, and tokens expired beyond the same 2-minute grace window used for session rotation no longer resolve a user identity on public share routes
 - Startup now fails when the configured/env auth signing key differs from the key persisted in the application database, instead of warning and minting tokens with divergent keys
 - OnlyOffice document downloads now re-validate redirect targets against the configured document-server host, closing an SSRF gap where a redirect could send the fetch to an internal address
 - OnlyOffice "closed with changes" callbacks now keep the document key until the save succeeds, so a failed save can be retried by the document server instead of being rejected as an unknown session
 - External JWT (JwtAuth) requests now reuse an existing valid session cookie instead of minting and registering a new session token on every request
 - SQLite index and application databases configure `busy_timeout` on every pooled connection, and busy/locked detection now uses driver result codes; index batch writes and maintenance no longer report success when the DB stays busy, and index cache reads return busy errors instead of empty results so listing can fall back to the filesystem.

## v2.0.8

 **Security**:
 - [Critical] A forged JWT could authenticate as any known `belongsTo`. Auth signing keys are now persisted in the application database and JWT validation fails closed when no key is configured. (GHSA-8f9r-wg7w-pfw) (#2987) Thanks @d3do-23 and @whoamis3c.
 - [Medium] Public upload shares with replacements disabled (`allowReplacements=false`) now reject overwrites when clients send `override=true`. (GHSA-3846-gh75-gp3m) Thanks @d3do-23
 - [Medium] OnlyOffice document-server callbacks now verify the shared `integrations.office.secret` JWT (HS256), reject unsigned callback bodies when a secret is configured, and require the callback document key to match the cached editor session for the target path (fail closed on cache miss or path lookup failure).

 **New Features**:
 - add "Upload only what's missing" to the upload conflict prompt (#2985) (#2553)

 **Notes**:
 - Improved UI responsiveness for larger directories and firefox, marginal improvement to memory (#1773) (#2879)
 - `/api/resources/download` and `/public/api/resources/download` now return HTTP 404 when the requested file or directory does not exist, instead of 500 (#2981)
 - `GET /api/resources` returns 400 when the `path` query parameter is missing or empty instead of 500 (#2801)

 **Bugfixes**:
 - Public share folder and multi-file ZIP downloads were empty for anonymous visitors when the source used deny-by-default or path access rules (#2631) (#2365)
 - 401 on pdf download button action (#2978)
 - OnlyOffice saves could no-op with HTTP 200 when JWT was enabled: callback POST bodies wrapped in `token` were ignored and JWT parsing omitted fields such as `url` required to download the updated document from the Document Server.

## v2.0.7

 **New Features**:
 - Add cli init CLI command (#2957)

 **Notes**:
 - Pop-up preview has 200ms debounce delay so it doesn't flash from moving the cursor across files quickly.
 - Added risc-v to official releases

 **Bugfixes**:
 - Hide the Replace option on upload/create conflict prompts when the user lacks modify permission (or when a public share disallows replacements), so create-only users are not offered an action that the server rejects (#2837)
 - Preserve Ctrl-click file selection when keyboard state is stale (#2958) (#2923)
 - Avoid false stalls during parallel transfers (#2950) (#2948) thanks @gudcks0305
 - Cap source usage-bar percentage at 100% when indexed size exceeds partition total (#2761) (#2238)
 - On Linux, source partition totals sum distinct filesystems mounted under the source root (nested mounts) so usage bars match indexed content (#2761)

## v2.0.6

 **Security**:
 - Share download links no longer create links with token, instead they link to the UI prompting for password before download. If a direct download is required, the `/api/share/direct` api exists and documented by swagger. (#2888)

 **Notes**:
 - renaming sources updates sidebar links (#2878)
 - disabling/deleting a user source removes that source from sidebar links (#2942)

 **Bugfixes**:
 - Fix disk-usage overstatement on virtiofs bind mounts (#2894) (#2894)
 - Support non-ASCII share passwords (#2933)
 - Fall back to buffered copies when FUSE rejects fast paths (#2938) (#2924)
 - Preserve deleted sidebar links across restarts (#2935)

## v2.0.5

 **New Features**:
 - Users can set default view mode and thumbnail size from Profile settings (Listing options). Admins can set the same defaults for existing users from the user edit prompt. Values persist to the account and apply on new browsers or devices; they do not override view preferences already saved locally ([#2884](https://github.com/gtsteffaniak/filebrowser/issues/2884)).
 - Admins can edit all profile preference defaults for existing users from the user management panel (listing, preview, sidebar, theme, and related options), matching what was previously available only for new users and global user defaults.

 **Security**:
 - [Moderate] public metadata api returns file content to anonymous share visitors, ignoring the share's download limit and file-viewer setting (GHSA-55mw-cwg7-m8f5) -- thanks @kta1kri

 **Bugfixes**:
 - Fixed infinite loading spinner on `/` and `/login` after CSP security hardening ([#2886](https://github.com/gtsteffaniak/filebrowser/issues/2886), [#2890](https://github.com/gtsteffaniak/filebrowser/issues/2890))
 - fixed darkmode styling bug where background wouldn't respect configured settings when not logged in
 - fixed styling bug where padding was missing from right side of listing view.
 - tilde paths for sources were not properly expanded. (eg "~" for home)
 - fixed tooltip not showing up for some circumstances on mobile, improved consistency.
 - a few styling fixes for inconsistencies (#2908)
 - Disk-usage widget no longer reports PB/TB-scale garbage on Docker Desktop for Mac (virtiofs) bind mounts; space is computed from the filesystem fragment size (`f_frsize`) instead of the optimal-transfer block size (`f_bsize`) on Linux ([#2894](https://github.com/gtsteffaniak/filebrowser/issues/2894)).

## v2.0.4

 **Bugfixes**:
 - OnlyOffice editor failed to load after the CSP security fix; allow configured `integrations.office.url` and `integrations.office.internalUrl` origins in `script-src` ([#2874](https://github.com/gtsteffaniak/filebrowser/issues/2874)).

## v2.0.3

 **Security**:
 - [High] Stored XSS via HTML preview: strip `<script>` from sanitized srcdoc, remove `allow-same-origin` from the preview iframe sandbox, set HttpOnly on the session cookie, and add a nonce-based `script-src` CSP on the SPA shell (GHSA-vvm6-jwrf-hgmg) -- thanks @qrn12580
 - [Moderate] Non-admin users could PATCH privileged fields on their own account (scopes, permissions, etc.), allowing privilege escalation; restores v1 non-admin field guard on PATCH /api/users (GHSA-p5cc-4p84-c4m2) -- thanks @Chri6s

 **New Features**:
 - Added option to globally disable the "Install App" message via `frontend.disablePWAInstall`
 - PWA improvements for installed mobile apps: dedicated maskable icons (192/512), manifest and splash colors that follow the instance default theme, runtime `theme-color` sync on dark-mode toggle, and edge-to-edge safe-area layout for notched devices (#2625) (#2869) -- thanks @APatenaude

 **Bugfixes**:
 - Fixed Fuji `.raf` thumbnail preview by extracting the camera-embedded JPEG from the RAF header (regression for files where TIFF-based raw extraction does not apply).
 - Image previews for unsupported decodable formats now return HTTP 415 immediately instead of attempting JPEG decode and returning HTTP 500.
 - OIDC: preserve the verified ID-token user identifier when falling back to the UserInfo endpoint for missing groups, so login no longer fails with HTTP 500 when UserInfo returns groups but omits the configured identifier.
 - LDAP: restore `memberOf` as the default `groupsClaim` when unset, fixing group-based admin and login authorization for existing LDAP configs after the v2.0.2 default changed to `groups`.
 - "Install app" message reappears after being cleared on device.
 - Restored upload chunk size `0` to disable chunking as documented ([#2202](https://github.com/gtsteffaniak/filebrowser/issues/2202)).
 - Fixed iOS 26 / WebKit multi-chunk upload stall by isolating chunk connections and returning partial chunk JSON responses ([#2734](https://github.com/gtsteffaniak/filebrowser/issues/2734)).
 - Sidebar folder links with custom names, icons, or styles no longer disappear after restart; multiple shortcuts to different folders on the same source are preserved ([#2809](https://github.com/gtsteffaniak/filebrowser/issues/2809)).
 - Adding a source to a user via scopes now auto-adds a matching sidebar link; removing a source keeps the link (shown disabled) so users can delete it manually.
 - A password reset via CLI returns user to a password method user.
 - Authentication login methods are consistently enforced without modifying existing account settings.

## v2.0.2

 **Bugfixes**:
 - OIDC: `groupsClaim` value is always included in requested scopes and falls back to the UserInfo endpoint when the ID token omits the groups claim.
 - Windows: fix backslash duplication in navigation URLs, folder sizes showing 4 KB, and download/preview failures (#2815, #2816)
 - Wrong extension in the 'new database was created popup (#2817) (#2824)
 - External subtitles fail to load on public video shares due to authenticated subtitle endpoint (#2822) (#2827)
 - OnlyOffice is inaccessible on password-protected shares (#2811)
 - FFmpeg 9.0 incorrectly detected as below minimum 5.0.0 on Windows (#2820) -- thanks @yzxcj797
 - Queue buttons not clickable in the desktop panel in audio files.

## v2.0.1

 **Security**:
 - [High] Symlink following on read paths no longer escapes source or user/share scope (GHSA-mgqf-5mf5-prfj) -- thanks @je-lv @KasperBuilds
 - [Moderate] Absolute paths in API path/file parameters could bypass user scope and read files outside the source mount (GHSA-rqqq-wv83-rp74) -- thanks @Wei-Leo
 - [Moderate] Logout did not invalidate session JWTs with equivalent Base64URL spellings (GHSA-8m35-wcjh-95q7) -- thanks @corbanvilla @soh3e @dderpym (This vulnerability was discovered as part of a U.C. Berkeley security research project by: Corban Villa, Sohee Kim, and Austin Chu)
 - [Moderate] Stored XSS via unsanitized DOCX hyperlink in DocViewer (GHSA-9wm6-jcjh-3m8c) -- thanks @karen93shieh @je-lv @EclipsSec
 - [Moderate] Revoked JWTs could still authenticate on public-share and withOrWithoutUser routes until natural expiry, bypassing logout and Api-permission revocation on that surface (GHSA-4wmj-rq3c-m65v) -- thanks @hypnguyen1209

 **Notes**:
 - GroupMap `SyncUserGroups` fix so JWT/OIDC/LDAP group memberships survive restart (#2742).
 - Session renew is handled by client keep-alive. removed per-request `X-Renew-Token` header handling.
 - Improvements to document thumbnail generation performance.
 - behavior changes for typing to select files in listing view.
 - next/previous buttons don't hide automatically on photos (#2767)
 - added more actions available in advanced search (#2776)

 **Bugfixes**:
 - GroupMap mutations (`SyncUserGroups`, add/remove group members) are write-through to SQL so JWT/OIDC/LDAP group memberships survive restart (#2742).
 - `defaultEnabled` behavior change/fix so defaultEnabled means its always added to users on startup and login. (updated docs too)
 - Long uploads/downloads no longer lose the session mid-transfer: proactive session JWT keep-alive renews before expiry (#2638).
 - Disable auto logout/session expiry if there are active file transfers going (#2638)
 - upload options get cut off on mobile (#2685)
 - Uploading image: image gets cut-off (#2765)
 - Process aborts (not just 500) during PDF thumbnail generation (#2763)
 - PDF preview generation prevents file uploads from completing (#2752)
 - Brings back double-tap to zoom images that was mistakenly removed.
 - multiple embedded subtitles with same language bug (#2756)
 - gallery view download button missing (#2767)
 - fixed HEIC rotation regression from v1.5.x
 - fixed raw image preview regression from v1.5.x
 - html viewer takes full height
 - Members without download permission receive 403 when opening text-based files despite OnlyOffice preview being enabled (#2777)

## v2.0.0

This version represents the most significant change to date. It **requires** both a database migration and config structural changes. See the [migration guide](https://filebrowserquantum.com/en/docs/getting-started/v2/migration/) for step-by-step upgrade instructions, [About v2.0.0](https://filebrowserquantum.com/en/docs/getting-started/v2/about/) for a full summary, and the [config migration tool](https://filebrowserquantum.com/en/docs/getting-started/v2/config-migration/) to convert legacy config.

 **Breaking Changes**:
 - Removed: `GET /api/raw` and `GET /public/api/raw` download routes — use `/api/resources/download` instead.
 - Removed: `/share/…` URL redirect to `/public/share/…` — use `/public/share/…` directly.
 - Removed: singular `source` search api param (use `sources`), bare `scope` paths without `sourceName:` prefix, and `glob` / `useGlob` aliases (use `useWildcard`).
 - Removed `config.conditionals`, source-level `indexingIntervalMinutes` (indexing always uses adaptive scheduling), and deprecated rule fields `fileNames` / `folderNames` / top-level `hidden` — use `config.rules` with `fileName`, `folderName`, and `ignoreHidden` on rules. See [Exclusion rules](https://filebrowserquantum.com/en/docs/user-guides/general-configuration/exclusion-rules/).
 - Removed: deprecated `userDefaults` config formats (nested and flat) — use the [config migration tool](https://filebrowserquantum.com/en/docs/getting-started/v2/config-migration/) to convert before upgrading.
 - Changed: `PUT /api/users` moved to the more appropriate `PATCH` method and requires specifying `which` in the body. Blank or `all` values are rejected.
 - Changed: http related config options in `server` config key moved to `http` config key. See [HTTP settings](https://filebrowserquantum.com/en/docs/configuration/http/).
 - Changed (reverse proxy): `http.trustedHeaders` (v1.5.x list) removed — use `http.trustProxyHeaders: true` when behind nginx, Traefik, or Caddy. When enabled, FileBrowser honors `X-Forwarded-Host`, `X-Forwarded-Proto`, `X-Forwarded-For`, and `X-Real-IP` for client IP, cookies, OIDC callbacks, WebAuthn, share URLs, rate limiting, and activity logs. Default is `false` (direct connection values). The [config migration tool](https://filebrowserquantum.com/en/docs/getting-started/v2/config-migration/) converts v1 `trustedHeaders` lists to `trustProxyHeaders: true`. See [Reverse proxy](https://filebrowserquantum.com/en/docs/getting-started/reverse-proxy/) and [HTTP trustProxyHeaders](https://filebrowserquantum.com/en/docs/configuration/http/#trustproxyheaders).
 - Changed: `FILEBROWSER_DATABASE` environment variable — use `FILEBROWSER_DATABASE_PATH` instead. See [Environment variables](https://filebrowserquantum.com/en/docs/reference/environment-variables/) and [Server settings](https://filebrowserquantum.com/en/docs/configuration/server/).
 - Changed: Moved stream api to `/api/media/stream`. See [API reference](https://filebrowserquantum.com/en/docs/reference/api/).
 - Changed: CLI user management — canonical commands are `user set <username> --password [value]` and `user promote <username>`; `set -u username,password` is deprecated. See [CLI reference](https://filebrowserquantum.com/en/docs/reference/cli/).


 **New Features**:
 - View grant mechanism to distinguish between UI viewing and download. See [Access control overview](https://filebrowserquantum.com/en/docs/access-control/access-control-overview/).
 - granular per-source file permissions (view, download, modify, create, delete) with automatic migration from global permissions
   - per-source defaults configurable in `settings > access management`
   - `view` permission is automatically set to true unless explicitly set to false. See [Access control overview](https://filebrowserquantum.com/en/docs/access-control/access-control-overview/).
   - can be enforced for all users. See [Access control overview](https://filebrowserquantum.com/en/docs/access-control/access-control-overview/).
 - New activity logs for user activity.
   - charts and historical data
   - export to csv reports
 - Media player improvements:
   - Refreshed playback queue UI: Supports thumbnails, stored into session storage, and has a "clear queue" button (#2575) (#2600).
   - Loop now has 3 states (off/single/all) and neither of them will clear the existing queue (#2600).
   - New "Audio visualizer" for audio files (desktop-only), you can configure some basic things to your taste (#2575) (#2620).
   - The current state of the audio panel now is stored into local storage.
   - More gestures: Swipe up to enter/exit fullscreen, long-press to change playback speed, single tap to pause (#2575).
   - Videos now will resume fullscreen and PiP when navigating (queue auto-navigation, swipes gestures or next/previous) (#2649).
 - Added `F4` shortcut to refresh the current directory and metadata (#2600).
 - opt-in feature to send deployment analytics to filebrowser quantum developer servers
   - anonymized with a viewer so users can see what info would be sent.
   - if opt-in, every month a snapshot of your deployment config would be sent to developer servers
   - this will help me know what features are being used and what versions everyone is on over time. I will also provide a public dashboard with this information in the future.
 - WebDAV now supports set modification time via the `X-OC-Mtime` header for clients that support it (#2626). See [WebDAV docs](https://filebrowserquantum.com/en/docs/features/webdav/).
 - Copy operations now preserve their original modification times (#2642) (#2647):
   - WebUI preserves both, files and directories.
   - WebDAV `COPY` preserves modification times only for files, is limitation we have with webdav.
 - User default enhancements
   - Config `userDefaults` seeds SQLite on first run; only fields explicitly set in config stay locked in **Settings → User defaults** (other defaults remain editable)
   - Added administrator controls for universal user defaults and enforced preferences in `settings > user management > user defaults`.
   - Added configurable default file permissions per source in `settings > access management`.
   - Added a User Defaults editor for account, permission, and profile preferences in the edit/create user prompt. See [User management](https://filebrowserquantum.com/en/docs/configuration/users/).
 - Database env var rename: `FILEBROWSER_DATABASE` is removed (startup fails if set). Use `FILEBROWSER_DATABASE_PATH` (default `filebrowser.sqlite`) or `server.database.path` in config. See [Environment variables](https://filebrowserquantum.com/en/docs/reference/environment-variables/) and [Server settings](https://filebrowserquantum.com/en/docs/configuration/server/).
 - CLI: `user set` with `--password` (inline value, interactive prompt on TTY, or piped stdin); `user promote` for admin grant without password reset. See [CLI reference](https://filebrowserquantum.com/en/docs/reference/cli/).

 **Notes**:
 - v2.x.x uses a new write-through backend state management. Changes go through a fast memory layer and also write changes to database to stay in sync. See [About v2.0.0](https://filebrowserquantum.com/en/docs/getting-started/v2/about/).
 - CLI server start (`./filebrowser`), `setup`, `version`, and `set rule` syntax unchanged; see [CLI docs](https://filebrowserquantum.com/en/docs/reference/cli/)
 - new dropdown and input styles
 - swipe gestures to dismiss notifications (#2672)
 - user updates are more granular, don't include entire user payload.
 - `user.id` has been moved to a backend property and all frontend apis now query users by username. Swagger has been updated. See [API reference](https://filebrowserquantum.com/en/docs/reference/api/).
 - removed legacy and deprecated properties from API responses and generated config output
 - `/api/media/stream` is audio/video only (range-based chunking). Non-media inline viewing uses `GET /api/resources/view`. Both endpoints use the same `viewToken` from file metadata. See [API reference](https://filebrowserquantum.com/en/docs/reference/api/).
 - removed exiftool as an optional helper, always built with the supported libraries (requires 64 bit os)
 - If migration issues arise, see [Migration troubleshooting](https://filebrowserquantum.com/en/docs/getting-started/migration/troubleshooting/).
 - default browser media player option removed, always uses themed plyr
 - [docker] upgraded ffmpeg from 8.1.2 to 9.0

## v1.5.5

 **BugFixes**:
 - fix uncustomized (minimal) API tokens creation needed by webdav clients (#2503)

## v1.5.4

 **Notes**:
 - PWA installation name now capped at 30 characters instead of 12 (#2699)

 **BugFixes**:
 - fix forward slash blocked in text fields when the search shortcut listener intercepts `/` (#2696)

## v1.5.3

 **BugFixes**:
 - fix probe canShare with the real file, not a fixed text/plain stand-in (#2664)
 - When the logout button is pressed, the user is redirected to an invalid URL that does not honor baseURL / externalUrl (#2657)
 - fix redirect to login when an authenticated request returns 401 (expired session)

## v1.5.2

 **Notes**:
 - [docker] upgraded ffmpeg version 8.1.1 to 8.1.2

 **BugFixes**:
 - Fixed OnlyOffice reopening an older editor state after a document is modified (#2633) (#2578).
 - Cannot "Reset and generate new two-factor code" to reset the TOTP for a user (#2399) (#2641).

## v1.5.1

 **BugFixes**:
 - fix http config section being dropped so trustedHeaders and disableRateLimit apply (#2602) (#2560)
 - fix upload shares with password (#2589) (#2573)
 - fix token when returning from preview on shares with pass (#2588) (#2465)
 - fix share undefined url after editing (#2567) (#2523)
## v1.5.0

 **New Features**:
 - Added basic html viewer with relative reference support (#2522)
 - Shares can have pinned files, requires a user to have edit access to share (#2522)
 - Enhanced search
   - now uses "lazy" match by default. (#2509)
   - added missing `case sensitive` option in the UI
 - Progressive Web App (PWA) improvements
   - restored install prompt with sidebar install button (#2086)
   - camera and video capture buttons on upload (mobile-friendly `capture` inputs)
   - send files to other apps via the Web Share API (`Send to app` in the context menu)
 - App notifications for file operations (#2478)
   - optional browser notifications when uploads, chunked downloads, move/copy, or failures finish while the tab is in the background
   - single on/off toggle in Notifications settings, stored in browser local storage

 **Notes**:
 - [docker] upgraded ffmpeg version 8.1 to 8.1.1

 **BugFixes**:
 - fixed PWA manifest `scope` and `id` so install works when the app is served under a base URL
 - installing a public share as a PWA now opens the share URL instead of the site root (#2302)

## v1.4.4

 **BugFixes**:
 - Pinning/Unpinning file resets users' scope permission (#2532)

## v1.4.3

 **Security**:
 - [High] Path traversal in subtitle handler allows any authenticated user to read arbitrary files (GHSA-vvp7-h4fj-m28w)

 **New Features**:
 - pinned files/folders (#2396) (#2510)
 - Markdown Image relative reference support (#2355)
 - Add an option to create a new folder for unarchiving (#2338)

 **Notes**:
 - added fallback to show text in notification if copy fails (#2517)
 - added `alt`+`arrow up` shortcut as alias of `backspace` to go into parent directory (#2501) (#2521)
 - added `alt`+`arrow down` shortcut as alias of `enter` to open files in Listing View (#2501) (#2521)
 - updated help menu with better translations
 - migrate i18n to v11 (#2472) (#2504)
 - migrate eslint (#2459)
 - improved preview cancellation to improve performance when navigating UI.

 **BugFixes**:
 - fix lyrics regex parsing (#2505)
 - fix folder previews issue (#2487) (#2492)
 - fix accidental exit on images while using gestures (#2508)
 - navigating using the up/down arrow keys in Listing View was "jumping randomly" in some view modes (#2521)
 - socket field in config.yaml is ignored (#2497)
 - fix keep opened file selected after closing its preview @anpryl (#2515)


## v1.4.2

 **Security**:
 - [Moderate] Add Rate Limiting on Authentication Endpoint Enables Brute Force Attacks (GHSA-r4v7-6wcg-ghj5)
 - [Critical] Path traversal in public share PATCH allows file ops outside shared directory -- thanks @Revanth011 and @fg0x0 (GHSA-qqqm-5547-774x)

 **New Features**:
 - read-only source configuration via `source.config.readOnly: true` (#2438)

 **Notes**:
 - auth rate limiting can be disabled via `auth.disableRateLimit`
 - updated share hash middleware (#2443)
 - updated source info popup to include private and readOnly properties

 **BugFixes**:
 - Logout from share page now redirects to the share instead of `/Login` again. (#2245)
 - `This location cannot be reached` error when navigating with FileTree in shares. (#2245)
 - Fix FileTree rename and move actions in previews. (#2245)
 - Delete prompt not showing date and thumbnails in some previews. (#2245)
 - fix path slash issue on windows (#2451) (#2433) (#2419)
 - Always force url rewrite for onlyoffice internal URL. Fixes Error saving with OnlyOffice (#2450)
 - Overriding a Deny with an Allow not working (#2405)

## v1.4.1

 **Security**:
 - Fix critical: unauthenticated user can view source info

## v1.4.0

 **New Features**:
 - Add Passkey (WebAuthn) support for passwordless authentication (#2287) (#2379) -- thanks @juansoler
 - Lyrics support for audio files (#2360):
   - Updated UI for audio previews!
   - The lyrics and the player gets syncronized in UI with the audio player.
   - Supports embedded lyrics (ID3v2 USLT, flac, ogg, clyr) and sidecar `.lrc` files with the same name as the audio file.
   - The `Q` shortcut in audio files will toggle the new panel visibility.
   - `E` shortcut to change between tabs of the panel if it's open.
 - Api log filtering support via `apiFilter` option for logging.
   - regex filter that excludes matching full api paths from being logged. (eg. `/user\?id\=self`) Defaults to `^/health|^/favicon.ico|^/static|^/public/static`
   - Add config option to disable /health endpoint logging (#2291)
 - More shortcuts (#2300)
   - `CTRL+F1` switch to normal view.
   - `CTRL+F2` switch to gallery view.
   - `CTRL+F3` switch to list view.
   - `Double click` on empty space to select all items.
 - Option to hide certain files in UI by extension (#2403) (#2277)
 - Additional search features
   - wildcard search similar to regex, but limited to sqlite GLOB syntax (#769)
   - advanced search tool that shows all results in a listing thats sortable and actionable like a normal listing (#1051)
   - advanced search supports multiple custom scopes per search
   - multiple search terms with AND or OR logic support

 **Notes**:
 - Enhanced indexing scheduler which doesn't wake the disk as often.
 - New API route `media/lyrics` used to fetch and parse lyrics (embedded or from `.lrc` sidecar) (#2360)
 - Swiping down gesture in fullscreen videos exit fullscreen instead of close preview.
 - Improved styles for path selection and tables
 - Improved style of drag and drop into listing view (#2407)
 - Edit Sidebar links has new "show tools in sidebar" toggle and all users have this enabled by default. can be disabled via for new users `userDefaults.sidebar.showTools: false`
 - Update user defaults ordering (#1140)
 - Save view modes and sizes into local storage instead of db (#2301)

 **BugFixes**:
 - Blue overlay when using gestures in video files on mobile (#2360)
 - Playback queue wasn't updating when changing of folder (#2360)
 - Added missing `UserDefaults.listing.showCopyPath` option to config file (#2364)
 - Delete prompt thumbnail didn't worked when using it with the `delete` shortcut. (#2407)
 - Searching icons in the Icon picker prompt wasn't working properly (#2407)
 - Drag and drop style state was stuck until page reload (#2407)
 - Navigate close settings shows "something went wrong" (#2047)

## v1.3.10

 **Notes**:
 - When indexing is disabled for a source, the usage will always reported as partition size.
 - removed deprecated `source.config.disableIndexing`, see [rules](https://filebrowserquantum.com/en/docs/advanced/source-configuration/conditional-rules/#disable-indexing)

 **BugFixes**:
 - Disable index option not working (#2385)

## v1.3.9

 **Security**:
 - [Critical] Unauthenticated Path Traversal in Public Share Delete Allows Arbitrary File Deletion GHSA-fwj3-42wh-8673
 - [Moderate] Stored XSS via SVG File in Public Share (Missing CSP Header) GHSA-mmpx-jh39-wrv6

 **BugFixes**:
 - Fix context menu items and adjusted when items show to more accurately reflect permissions.

## v1.3.8

 **BugFixes**:
 - Quick download icon style after icon change.
 - Missing error popup for resource creatoin actions (upload/create)
 - EnforcedOtp login failure until restart (#2330)
 - Thumbnails for Folders only display sporadically (#2353)
 - Unwanted user scope change for users with non-default scopes (#2347)
 - Fix sidebar source info totals (#2321) (#2322) (#982)
 - Error uploading a large number of photos -- only 100 items get uploaded (#2348)

## v1.3.7

 **Notes**:
 - creating/deleting password-based user requires reauthentication (#2112)

 **BugFixes**:
 - TOTP works for admin but fails for standard users on re-login until Docker is restarted (#2330)
 - No Loginfields shown if password authentification is set to false (#2331)

## v1.3.6

 **BugFixes**:
 - file watcher not working for files and not respecting line count (#2314)
 - "source" type link shows up multiple times when adding sidebar links if user has multiple sources.
 - JWT ES256 results in error (#2188)
 - single file shares not loading editor text content (#2122)

## v1.3.5

 **Notes**:
 - any password change or admin user property change for a password user requires reauthentication (#2112)

 **BugFixes**:
 - PWA icon fixes (#2292)
 - deny-rule'd folders visible in directory listings (regression from v1.2.4-stable) (#2295)
 - OTP and password requirement fixes (#2112) (#2263)
 - CLI not picking up config properly
 - Storage usage numbers on first load adjusted.
 - Some items in userDefaults are not setting defaults for new users properly #2278
 - Fix copy to clipboard and simplify code (#2281) (#2274)
 - Fix search shortcut `/` and pdf previews (#2307)
 - Special permissions bit not set when declared in createDirectoryPermission (#2283)
 - Execute permission altered after editing sh script with FB Quantum (#2309)
 - Source is red but working (#2289)

## v1.3.4

 **New Features**:
 - Epub placementg url anchors to bookmark a specific location on the doc.
 - Add Requirement for Current Password When Changing Account Password (#2112)
 - Copy file path to clipborad through right click (#2204)

 **Notes**:
 - user scope editing has path picker and filesystem validation

 **BugFixes**:
 - Swiping media files doesn't respect Playback Queue (#2243)
 - Audio metadata and album thumbnails doesn't work (#2236)
 - Search spinner wouldn't show up sometimes while searching
 - The default landing page source should always be the first source in the sidebar, that wasn't always respected.

## v1.3.3

 **New Features**:
 - Copy/paste files and folders (`CTRL+C`/`CTRL+V`) from other apps (win explorer, thunar, finder, etc) to upload them directly (#2197)
 - Caption font size can be adjusted in video settings
 - Ability to adjust the startup check method for sql database via `server.startupIntegrityCheck` (#2221)
 - Status bar for editor and markdown viewer (#2226)

 **Notes**:
 - `.fbx` 3d model files added to supported previews.
 - removed upx compression on docker image (#2193)
 - videos double tap to fast-forward and rewind added.
 - Adjust Image album swipe behavior (#2068)
   - swipe animation for next/previous
   - swipe down on image to close and go to parent folder.
   - supports videos
 - chunked uploads will save to a temporary file at the destination and renamed on completion. Better upload pause handling (#2129)
 - The Icons in the UI were updated! (#2203)
   - More supported icons in the Icon Picker tool.
   - More file types have new icons across all the listings (such as `.md`, `.apk`, etc).
 - `.fbx` 3d model files added to supported previews.
 - removed upx compression on docker image (#2193)
 - chunked uploads will save to a temporary file at the destination and renamed on completion. Better upload pause handling (#2129)
 - deprecated `source.config.CreateUserDir`, now its always `true`. If a user directory doesn't exist it will get created empty.
 - `CTRL`+`Mouse Wheel` shortcut to change listing size. Also for change font size in editor (#2227)

 **BugFixes**:
 - Archives don't preserve file metadata (#2063)
 - Chunked upload setting fails: "0" does not disable chunking as expected (#2202)
 - Incorrect Chinese labels for Upload controls in Quantum UI (#2191)
 - Chunked download stops after first chunk, add message explaining (#2074)
 - Esc to Cancel and Enter to confirm popup (#2079)
 - Language-tagged subtitle files not detected for videos (#2199)
 - Unable to use proxy auth since 1.3.0-beta (#2173)
 - Updating setting on a LDAP user turns the "Login Method" to password. Thus preventing further logins. (#2179)

## v1.3.2-beta

 **Security**:
 - Patched Username Enumeration via Authentication Timing Side-Channel  GHSA-7789-65hx-f26w

 **New Features**:
  - Option in settings `userDefaults.preferEditorForMarkdown` to prefer editor first for Markdown files (#2136)
  - Copy to clipboard button for code blocks in Markdown Viewer (#2160)
  - Add "Last modified" filter in search dialog (#2157)

 **Notes**:
 - docs preview for text and pdf has a 2 second timeout. If it hangs for whatever reason, the maximum time would be 2 seconds. (#2105) (#2114)
 - Downloading multiple files streams the archive creation rather than using cacheDir -- thanks @janakoram (#2125) (#2130)
   - `server.maxArchiveSizeGB` now defaults to 20 (GB) and only applies to archive/unarchive actions (not downloads).
   - browser download progress bar will no longer show for archive downloads. this is the main drawback to the streaming approach.
   - should allow for much higher parallel download support and lower cleanup maintenenance.
 - [docker] ffmpeg version upgraded to 8.1
 - remote ip in logs now prefers `X-Forwarded-For` if it exists, then `X-Real-IP`, then lastly the standard RemoteAddr. Useful when running behind a proxy to log the public IP of each request. (#2110)
 - changed loading spinner style to be more compatible with safari browsers.

 **BugFixes**:
 - Wrong username in share settings (#2147) (#2148)
 - [OnlyOffice] Error when saving a file under a user scope #2133
 - Cannot edit shared file in OnlyOffice #2143
 - PWA install button disappeared (#2086)
 - Deleting a root folder was possible #2128
 - PUT resource api errors if action against a folder (#2153)
 - LDAP authentication issue if a password caontains @ symbol (#2154)
 - Share banner seems to be not working for custom urls (#2120)

## v1.3.1-beta

 **Security**:
 - Patched Stored XSS in public share page via unsanitized share metadata (text/template misuse) GHSA-r633-fcgp-m532
 - Patched Incomplete Remediation of CVE-2026-27611: Password-Protected Share Bypass via /public/api/share/info GHSA-525j-95gf-766f

 **New Features**:
  - More user options for settings (#2072) (#2067):
    - Option to disable thumbnails `userDefaults.preview.audio` and `userDefaults.preview.models` for Audio and 3D Models.
    - Option to disable files in the Tree navigation `userDefaults.hideFilesInTree`
    - Option to disable source files deletion when creating/extracting archives. `userDefaults.deleteAfterArchive`

 **Notes**:
 - Share icon does not show in share listing or for shares for other users.
 - File Size Analyzer tool max items increased from 100 to 200.
 - changed symlink detection logic.

 **BugFixes**:
 - 405 response code error on Webdav in 1.3.0-beta (#2054)
 - Motion Preview setting not saving when changed in profile settings.
 - Context menu on tools not working.

## v1.3.0-beta

Note: a potentially breaking change for docker users: \the default user is now "filebrowser" 1000:1000 instead of root.

 **New Features**:
 - New Sidebar Features
   - Sidebar tree navigation (#2006) (#350)
   - Source usage to be customized to show os-reported values rather than calculated. This can be changed per source by editing the source link in the sidebar. (#1266) (#982)
 - Archive/Unarchive actions in UI (#1252) (#335) (#1569)
   - new api to archive/unarchive files on the server
   - requires `create` user permissions
   - archiving actions respect `server.maxArchiveSize`
 - Added share icon to items that are shared (#1420)
 - Authentication enhancements
   - LDAP login support with OIDC feature parity. (#591)
   - userGroup for OIDC and LDAP, only users in a group will get access. (#1964)
   - Add JWT token authentication support (#1364)
 - Enhanced thumbnail and item previews
   - Added ability to show "motion preview" for folders with multiple child items that have previews. cycles through the first 4 images.
   - support for reading embedded images from raw image or heic/heif files (#215)
   - reorganized and simplified thumbnail settings in profile settings (#1968)
   - removed `highQuality` thumbnail option which only affected gallery view. Now its always enabled.
   - improved caching for unsupported images, the same file won't be attempted again with the same modtime.
   - supports 3d model previews.
 - FileWatcher also supports watching directories
 - Support previews for 3D model files (STL, OBJ, 3MF, etc.) (#1273)
   - supported formats via threejs: GLTF, GLB, OBJ, STL, PLY, DAE (Collada), 3MF, 3DS, USDZ, USD, USDA, USDC, AMF, VRML, WRL, VTK, VTP, PCD, XYZ, VOX, KMZ
   - supports animations (for formats that contain them)
   - supports embedded textures, external neighboring file textures, or textures in `/textures` subdirectory
 - Enhanced prompts
   - All prompts have a taskbar with a close button
   - Prompts can be freely moved by dragging taskbar
   - Prompt styling has been updated
   - Clicking outside of prompts no longer automatically closes them.
 - add webdav support (#209) -- thanks to @reddac for (#1764)
   - see docs on how to use
   - requires api an un-customized api token as password
   - respects access rules
   - requires download permission to view and modify/create/delete permission to modify.

 **Notes**:
 - Docker images default to `filebrowser` user instead of root
 - reorganized api routes
   - consolidated tags for swagger to be more accurately grouped
   - tools are all behind `/api/tools` routes
   - `/api/raw` is deprecated (but functional). The `/api/resources/download` route will be used instead.
   - `/api/preview` has been removed and replaced with `/api/resources/preview`
   - `/api/onlyoffice` have been replaced with `/api/office`
   - `/api/shares` has been moved to `/api/share/list`
   - `/api/auth/tokens` has been moved to `/api/auth/token/list` and `/api/auth/token` added to get specific token info
   - `PUT /api/token` has been moved to `POST /api/token`
   - `/public/api/shareinfo` has been moved to `/public/api/share/info`
   - `POST /resources/bulk/delete` api has been moved to `DELETE /resources/bulk` (#1984)

 **BugFixes**:
 - Long folder names get cut off at top navigation bar (#1934)

## v1.2.2-stable

 **Security**:
 - Patched Stored XSS in public share page via unsanitized share metadata (text/template misuse)

 **New Features**:
 - "Divider" option in sidebar links to add a text or divider between links ()
 - shares offer a "go to source Location" sidebar link and button when editing a share.

 **Notes**:
 - Share edit/delete permissions are scoped to the user's shares rather than global (#2050)

 **BugFixes**:
 - fixed the requirement that the database path needed to be set in the config file, now it loads `FILEBROWSER_DATABASE` value by default, fallback to config file property.
 - Error downloading zipped directory: no such file or directory (users with scope) #2015

## v1.2.1-stable

 **BugFixes**:
 - startup icon generation order issue (#2019)
 - login button on shares not showing (#2028)
 - removed file watcher link in context menu for shares (#2025)
 - Direct download link for single-file shares generates incorrect URL (#2026)
 - Deleting files causes error V1.2.0 #2039

## v1.2.7-beta

 **BugFixes**:
 - head > title > infinitely duplicating titles (#2016)
 - Proxy auth not working with Nginx, stuck at logo (#2013)

## v1.2.6-beta

 **Security**:
 - resolves https://github.com/gtsteffaniak/filebrowser/security/advisories/GHSA-8vrh-3pm2-v4v6

## v1.2.5-beta

 **Notes**:
 - Dependency Updates for frontend and backend packages
 - Upgrade to go 1.26
 - file list prompt interaction behavior, single-click always selects, double-click navigates. (#1911)

 **BugFixes**:
 - .ssa and .ass subtitle files get their styling removed during conversion (#1933)
 - custom icons issue
 - new database message for noauth (#1935)

## v1.2.4-beta

 **Notes**:
 - Changed `/api/media/subtitles` api endpoint to better support subtitles.
 - Correcting some errors in French language (#1947)
 - add Dutch `nl.json` for frontend i18n -- thanks @Stephan-P (#1957)
 - share banner and icon images automatically serve a scaled down 1024x1024

 **BugFixes**:
 - Can't access directories with space (and possibly other special characters) when browsing a public link share (#1956)
 - External ASS subtitles are not usable in web preview (#1933)
 - Filename blocking rename/move (#1950)
 - enforcedOtp: true blocks all user settings updates with HTTP 400 (#1962)
 - Share favicon URL not showing up and Share description causing endless loading (#1911)
 - folder sizes not updated for changes to filesystem outside of filebrowser (#1974)

## v1.2.3-beta

 **Notes**:
 - Removed upload api behavior to assume paths ending in "/" are folders, strictly uses isDir query param
 - renamed public upload api query param from `targetPath` to `path`. see swagger docs.

 **BugFixes**:
 - fix stuck motion preview popup window issue
 - Chunked uploads ignore User Scope and are saved to Source Root (#1894)
 - share delete with user scope issue
 - fix favicon pwa icon, having the PWA respect the favicon/loginIcon (#1899)
 - delete prompt icons show image previews

## v1.2.2-beta

 **New Features**:
 - Resizable sidebar (#1896)
 - OIDC Authentication: Change Button Text via `frontend.oidcLoginButtonText` (#1708)
 - improved favicon processing (#1899)
   - supports more formats
   - supports larger images
   - automatcially generates multiple favicon sizes on startup for non-svg images. Custom svg favicons need a companion *.png to exist broad compatibilty
   - Enhanced media playback: Ability to control the queue from your device's lock screen and notification panel - Will also show
   metadata of the current playing media if available (#1917)

 **Notes**:
 - Better text file content detection (#1726)
 - More url encoding changes for API which should make things more consistent. Open issues if you see path/source not found errors.
 - adjustments to the startup behavior for sqlite index for reusing the previous database on startup
 - CTRL + B disables sticky sidebar forever (#1869)
 - added context menu back to duplicate finder
 - Sharing a link for uploads - folder/file access and UX polishing (#1902)
 - improved listing view and scrolling performance
 - improved image viewer which will utilize recent thumbnails as a placeholder when loading the full image.
 - Small reorganization of "Share" settings to make the popup clear (#1826)

 **BugFixes**:
 - Added docker default `FILEBROWSER_CONFIG="/home/filebrowser/data/config.yaml"` back -- mistakenly removed. see https://filebrowserquantum.com/en/docs/getting-started/config/#3-default-locations. (#1891)
 - Fix brand text in login screen (#1898)
 - Sidebar links cointains urls with 2x repeated source name (#1847)
 - 2 factor auth getting overwritten if you edit the auth from admin (#1819)
 - New created user's files are listing error, Probably related with language setting. (#1565)
 - thumbnail generation cpu/memory and concurrency bug.
   - added 75MB filesize limit for image previews
   - optimized concurrency for large vs small images


## v1.2.1-beta

 **New Features**:
 - Global disable onlyoffice editor via "*" file option to disable all files for a specific user. (#1533)

 **Notes**:
 - upgraded imaging package and improved thumbnail generation performance. (#1797) (#1850)
 - updated download api to use repeated `file` query param for path instead of `files` with comma. See swagger for details (#1881)

 **BugFixes**:
 - OnlyOffice stopped working after 1.2.0 upgrade due to download api changes
 - Search result link to wrong path when search context other than / (#1863)
 - File actions doesn't work if using user scopes (#1879)
 - Drop items into folders doesn't work (#1860)
 - duplicate finder context menu (#1862)
 - File list in previews doesn't show the parent items (#1861)

## v1.2.0-beta

This is a major version update with many code changes which could cause unexpected behavior. Upgrades should proceed with caution and report any undesriable behavior by opening an issue on github. The index is now fully in sqlite database - see [Indexing Overview](https://filebrowserquantum.com/en/docs/features/indexing/) for more information.

Sorry for the delay -- a lot of effort went into this release, specifically about fine-tuning sqlite indexing. It took me a long time to iron out the behavior, but it should be mostly there now. Enjoy and report any issues as always :)

 **New Features**:
 - SQLite-based indexing
   - reduced memory usage, higher CPU and IO usage.
   - index persistence between restarts (requires [persistent cacheDir](https://filebrowserquantum.com/en/docs/configuration/server/#cachedir))
 - new tool - "realtime file watcher" low latency if user has realtime permissions (#917)
 - Access control works with individual files too
 - conditionally hide symbolic links as indexing rule config (#1540)
 - External applications can connect to filebrowser over webDAV (#209) (#1764)
 - make breadcrumbs act as a drop area (#1785)
 - search multiple sources at once (#848)
 - file uploads resume from bad internet connection #1599
 - chunked downloads - fix for 524 errors on cloudflare #1502
 - made size calculation consistent: defaults to "size on disk" style to mimic "du -sh", and allows config `source.config.useLogicalSize: true` for 0 size folders and actual size file sizes. (#1266)
 - Feature: allow deleting selected duplicates from duplicate finder (#1659)
 - share changes:
  - opengraph support for shared links
  - Allow adding "share settings" option to customizable sidebar links (#1825)
  - file picker for share favicon and banner icon
  - Allow disabling "Login button" for shares (#1673)

 **Notes**:
 - `server.cacheDirCleanup` defaults to `false` instead of `true`. For docker, you would still need to mount a cacheDir volume to persist cache between restarts.
 - indexing rules have been streamlined, see [wiki]. The previous style is deprecated but still functional.
 - improved listing load times for directories with metadata -- a two-pass approach. First a fast load to get the listing items, then a second api request to include metadata.
 - Enhanced delete prompt
 - bulkDelete API added and replaces the delete API for all UI actions. See swagger docs for usage.
 - raw download and patch resource api simplified to a single source per request. See swagger docs for usage.
 - UserScope function re-organization, if you notice any user scope issues, please open a GitHub issue.
 - file upload resume from bad internet connection #1599

 **BugFixes**:
 - Source info not properly read from external storage NAS (#1727)
 - ensure user requests scopes are strongly enforced (#1789)

## New Contributors
* @reddec made their first contribution in https://github.com/gtsteffaniak/filebrowser/pull/1764
* @maximeborges made their first contribution in https://github.com/gtsteffaniak/filebrowser/pull/1849

**Full Changelog**: https://github.com/gtsteffaniak/filebrowser/compare/v1.1.6-beta...v1.2.0-beta

## v1.1.6-beta

 **Notes**:
 - "showHidden" is now a backend attribute. Shares will NOT show hidden files by default unless configured to.
 - improved listing view UI performance, especially for folders with many items. (#1773)

 **BugFixes**:
 - SortBy config is not respected when navigating next/previous (#1786)
 - unauthenticated users unable to preview files (#1792)
 - File permission not correctly applied( #1790)
 - API Key loses "download" permission after creation despite being enabled (#1799)
 - never exclude root folder (#1749)
 - sources with "files" name not showing after 1.1.x update (#1772)
 - Symbolic links can't be deleted from webui. (#1566)
 - panic: close of closed channel during indexing (#1771)
 - Public sharing returns 404 errors for album art (#1792)
 - Directories with some symbols in their name "fail to open" (#1808)

## v1.1.5-beta

 **Notes**:
 - Major git container tag request #1756

 **BugFixes**:
 - Sharing broken if source `disableIndexing: true` (#1742)
 - Password protected share permission issues (#1729) (#1606) (#1593)
 - Sidebar Sliding left (#1737)
 - file permissions not working (#1762)
 - handle Close() errors in archive creation (#1745)
 - Move custom CSS and user-selected theme styles to the end of the body (#1744)

## v1.1.4-beta

 **New Features**:
 - toggle to show searching results with thumbnails #1545

 **Notes**:
 - file list has loading spinner to help prevent double click issues and give better feedback
 - improved cacheDir startup checks
   - warning for slow read/write speeds below 50MB/s
   - warning for low free space below 20GB
   - warning if read/write latency is slow
   - fatal for any errors reading or writing to the directory
   - links to official docs for more info
 - access rule changes:
   - denied folders won't show up in parent directory listing view (#1684)
   - tools will respect access rules
   - shares will check access rules based on user that created the share

 **BugFixes**:
 - passwords with special characters not working properly (#1648)
 - encoded filename navigation issue (#1711)
 - Fix/Improve some behaviors in nextPrevious (#1707)
 - Files recognized as folder if they have the same name as previously deleted folders #1697
 - multi logger support issue #1701

## v1.1.3-beta

 **Notes**:
 - continue create user dir scope even if filesystem path creation fails #1509
 - access control cache is cleared more aggresively to ensure no delay
 - removed default .ico favicon in favor of .svg

 **BugFixes**:
 - indexing used size increases over time #1685
 - download progress is not shown #1687

## v1.1.2-beta

 **Notes**:
 - changes to duplicate detector
   - temp SQLite database each query to reduce memory pressure
   - max limit is 500 groups total
 - Downloads from UI requests utf-8 formatted names to support chinese and other characters. Updated swagger docs.
 - beta releases no longer publish to `latest` docker tag #1675

 **BugFixes**:
 - better index status updates, fixing delays #1649
 - fixed long load times for listings with media info due sequential processing of files.
 - downloaded files always included `utf-8` in filename #1671
 - custom sidebar links allow external links like `https://google.com`
 - html title not populated correctly for links #1676

## v1.1.1-beta

 **Notes**:
 - [docker] upgraded ffmpeg 8.0 to 8.0.1
 - stricter access control checks on file downloads.
 - Wrong translation on Chinese "save" button #1650
 - Incorrect Spanish Translations in Folder Creation and Rename Actions #1626
 - duplicate file detector has stricter partial checksum match #1617

 **BugFixes**:
 - added missing exiftool to docker image for heic conversion orientation support
 - v1.1.0-beta - Incorrect naming of 1 file in directory-info #1621
 - disable only office viewing settings not applying
 - OnlyOffice integration does not work behind proxy authentication #1422
 - Newly created users "add on" to defined scope of previous user #1628 #1518
 - disable chown on upload / file saving #1469 #1546
 - Uploading a file will silently overwrite any existing file with the same name #1564
 - share file url issue
 - Fix drag and drop and rows in normal view #1651
 - Some text based files are not able to edit. #1567

## v1.1.0-beta

 **New Features**:
 - Added tools
   - size analyzer -- quickly show largest files in interactive graphical chart
   - duplicate finder -- find duplicate files larger than 1MB
   - material icon picker and previewer
 - Listing View Style updates
   - Status bar for listing view #1459
   - Duration field shows up if media is shown with duration
   - More dynamic view modes with additional styling changes
   - Total display modes consolidated into 3 main groups: list, gallery, normal. "icon" and "compact" mode exist as views based on display size setting.
 - Customizable sidebar links
   - Logged in users can have their preferences saved and synced
   - Can rearrange, add custom links, and save your preferences.
   - Can customize shares with their own custom sidebar links.
 - Dynamic scopes for OIDC #1414 #1363
 - Share and Access Rules validation
   - If a file/path is moved/renamed in UI its rules and shares will always follow.
   - If a file/path is moved/renamed outside UI, a warning message will show and ability to associate to new path
 - Cascade delete access in Access Management when deleting a User #1347
 - Enhanced notifications #1331
   - Added "toast" notification type support -- most success messages show as toast now.
   - multiple stacked notifications possible
   - notification button support, such as click to open folder after moving file.
   - notification history (not including toasts)
   - Add swipe and visual timeout to notifications #1600
 - Choose different bind ip via `server.listen` #1573
 - Allow disabling clearing cache each startup via `server.cacheDirCleanup: false` in config #1576

 **Notes**:
 - more efficient user update actions. Successful PUT actions return only 204 if successful.
 - Do not enter directory on "New Folder" action #1343
 - Improved indexing performance - individual scanners per directory at root.
 - Improved search memory efficiency
 - Improved scrolling performance
 - Static file handling has been streamlined, could potentially see some changes from this.
 - No longer automatically publishing any dev builds to docker
 - deprecated "DefaultLandingPage" option -- now determined by first source link in sidebar.
 - Improve rename prompt #1608 #1556

 **BugFixes**:
 - uploading/editing/saving to password protected shares error
 - updating a share with password protection without a password removed the password.
 - per-user download counts were not persistant accross restarts
 - "Update" button in Chinese wraps incorrectely #1542

## v1.0.1-stable

 **BugFixes**:
 - UserDefault always applies to newly created users #1518
 - Updating user's own password sometimes doesn't work
 - Anonymous Share link with optional password does not allow downloads #1553
 - Share options should go in the meta tags #1511
 - Unable to select compression format when downloading multiple files/dir via Share link (v1.0.0) #1557
 - fixed sidebar clipping on some browsers like safari
 - Files show as Download is not available even though it is #1537

## v1.0.1-beta & v1.0.0-stable

 **New Features**:
 - login icon support added via `frontend.loginIcon` config path variable

 **Notes**:
 - updated default login icon
 - stopped publishing rolling `dev` docker tag.
 - build requirement change -- from node 18 > node 20 with npm 9.0.0+
 - version is not shown for unauthenticated users #1444
 - adjusted how static assets are served to better handle icon standards
 - fixed signup login #1444
 - update makefile linker flags to properly set version and sha #1474
 - better windows build support -- `make setup` and `make dev` work as long as git is installed on windows
 - added better first initilization detection
   - If filebrowser initialized and does not detect a database, a new warning message in server logs appears.
   - If theres no database on start, any admin user's first login will see a welcome message in the ui.
   - For docker, it defaults to ./data/database.db, but will also fallback to ./database.db without any additional configuration.

 **BugFixes**:
 - Generating multiple HEIC previews in parallel fails #1470
 - ? in path not always encoded right #1447
 - fixed some condition that the halloween background doesn't load properly
 - some comments not showing up on config viewer in settings

## v1.0.0-beta

 **Notes**:
 - Enhanced onlyoffice debugger with more wholistic backend logs
 - Updated info prompt styling
 - share qr code links to externalUrl for entire share if exists #1329

 **BugFixes**:
 - cookie host is set using x-Forwarded-Host to better support reverse proxies.
 - HEIC conversion not working #1460
 - 'Prevent user changing their password' also prevents admins changing the users password. #1365
 - OnlyOffice write problem #1397 #1068
 - Conditionals starting with a . seem to not work. #1455
 - Last modified in file info is empty #1443
 - Share links: 'Default View Mode' does not apply to subfolders. #1463

## v0.8.11-beta

 **New Features**:
 - OnlyOffice debugger now shows backend logs as well for admin users.
 - If proxy auth based `username` equals `auth.adminUsername`, the user will be promoted to admin.
 - Guard against accidently cancelling uploads #1419
 - Added a quirky halloween theme that automatically applies on october 31st -- you can disable this from happening by setting `frontend.styling.disableEventThemes`

 **Notes**:
 - Removed share setting `enableOnlyOfficeEditing` -- uses value from `allowEditing`
 - Anonymous users can now edit if a share has edit permissions enabled.
 - No "Incompatible user settings detected" message if its first setup
 - cookie handling revamped
   - fully backend managed
   - `auth` cookie name changed to `filebrowser_quantum_jwt`
   - auth cookie for password users no longer session based #1439
   - removed state jwt state variable -- 100% cookie based.

 **BugFixes**:
 - Fixed issue editing onlyoffice on shares #1397
 - Added proper and robust logging / error handling for the onlyoffice callback. #1422 #1068
 - If a file was moved/renamed/deleted onlyoffice would re-save the original file without error, now it gives error the file doesn't exist anymore.
 - OnlyOffice integration does not work behind proxy authentication #1422
 - proxy-based authentication with docker does not work unless set up with password-based login first #1226
 - Select all bug on safari mobile #1421
 - Dragging a item into itself #1446

## v0.8.10-beta

 **New Features**:
 - Add marquee selection to listing view -- thanks @Kurami32 #1388

 **Notes**:
 - More changes to login auth flow
 - respects `FILEBROWSER_DISABLE_AUTOMATIC_BACKUP='true'` env var #1398
 - Deprecating `conditionals.hidden` instead use `conditionals.ignoreHidden`

 **BugFixes**:
 - Fix material outline styling
 - "feels lonely here" when clicking at source tab #1387
 - Anonymous upload bug 0.8.9 #1383
 - changing previews between documents in onlyoffice #1410
 - onlyoffice should display user language #1061
 - Filebrowser will hard fail when OIDC provider is not found #733
 - some API endpoints always return 404 #849

## v0.8.9-beta

> [!CAUTION]
> If you have indexing rules -- such as [maxWatchers](https://github.com/gtsteffaniak/filebrowser/blob/39514169f17ed9586d587dd496257588ded6e532/frontend/public/config.generated.yaml#L30), [neverWatchPaths](https://github.com/gtsteffaniak/filebrowser/blob/39514169f17ed9586d587dd496257588ded6e532/frontend/public/config.generated.yaml#L31C9-L31C24), [exclude](https://github.com/gtsteffaniak/filebrowser/blob/39514169f17ed9586d587dd496257588ded6e532/frontend/public/config.generated.yaml#L32C9-L32C16) rules, [include](https://github.com/gtsteffaniak/filebrowser/blob/39514169f17ed9586d587dd496257588ded6e532/frontend/public/config.generated.yaml#L43) rules, see [the migration guide](https://filebrowserquantum.com/en/docs/user-guides/general-configuration/exclusion-rules/) for help.

 **New Features**:
 - Playback Queue for media -- thanks @Kurami32 #1339
 - Ctrl+b Shortcut to toggle sidebar, open settings, search #1172
 - Add a "select all" toggle in the menu #974
 - Save on exit text editor -- thanks @srini-abhiram #1334 #1241
 - Disabled indexing for subfolders but allow browsing #783
 - Added more granular create/upload, delete, and download (includes viewing content) permission #1200 #1199
 - Upload settings can be adjusted directly in the upload prompt
 - Added paste confirmation prompt when using copy/paste keyboard shortcuts.
 - Updated shares
   - `disableDownload` to disable download and (content viewing).
   - `allowReplacements` to share permission -- prohibits replacing files on conflict #661
   - normal shares can create/upload files if given permission

 **Notes**:
 - Optimized font and icon loading.
 - the next/previous buttons will follow media queue order if playback mode has a queue.
 - All new exclude rules -- see [full config example](https://github.com/gtsteffaniak/filebrowser/wiki/Full-Config-Example)
 - The order of sources will strictly match order in config.yaml. Default landing page is root first source unless otherwise configured in profile settings.
 - Uploading changes #1371
   - Chunked uploading can no longer be explicitly disabled, defaults to 5MB chunks
   - Automatic chunked/non-chunked uploads based on size. If an item exceeds the chunk size, chunked uploading will occur. If its less than chunk size, no chunked upload.
   - To "disable" chunked upload, you an set your chunk size very large -- 0 chunk size will be reset to 5MB.

 **BugFixes**:
 - Remember the previous location after closing a preview #1336
 - fixed issue related to multi-config parsing #1267
 - Cannot save text files, missing button #1326 #1367
 - Files are being overwritten and/or content disappears #1312
 - moving between items using next/previous will reset the req and show a responsive loading spinner -- fixing several state related issues.
 - access management: child folders accessible stopped showing up #1332
 - Make source inaccessible if directory does not exist rather than exiting on start #1264
 - HTTP Proxy environment gets ignored since version v0.8.6-beta #1324
 - album artwork preview not showing on shares
 - fixed OIDC logout causing a loop #995 #1361
 - fixed checksum failure #1372
 - Copy, paste, cut shortcuts don't work and make the UI unusable #1375

## v0.8.8-beta

 **New Features**:
 - Ability to split configuration files via yaml anchoring #1267
   - see [How to: Use multiple config files](https://github.com/gtsteffaniak/filebrowser/wiki/How-to:-Use-multiple-config-files)
 - added [Init Script Help wiki](https://github.com/gtsteffaniak/filebrowser/wiki/Init-Script-Help) to examples how you can bootstrap filebrowser quantum programatically
 - Add capability to edit files permissions #813
   - see updated full config for help using `server.filesystem`
 - better copy/move prompt "in progress" indicator
 - better login error message feedback
 - Add capability to disable certain video previews at server level. See full config for help.
 - Added ability to play media in same folder sequentially or shuffled.
 - upload/upload only share links. #661
 - Default landing directory if no other redirect is found (set profile settings) #781
 - share download limit feature can apply per user -- and disables anonymous download when enabled.
 - Docker health check #1292
 - embedded subtitle support is now **disabled** by default, can be enabled via `integrations.media.extractEmbeddedSubtitles`. Per share configuration is also possible via `extractEmbeddedSubtitles` toggle. This change is because reading subtitles requires processing the entire file, and multi GB video files can take 10-20 seconds.

 **Notes**:
 - Some standardized path format changes for access rules to ensure the rules apply. A migration check happens on startup, all rules should still be in effect without any issues, but double check.
 - moved `server.debugMedia` to `integrations.media.debug`
 - optimized thumbnail generation workflow
   - more concurrency changes for video thumbnails (now half of the numImageProcessors config)
   - 15s timeout added to preview api
   - preview operations are cancelled if api request is terminated.
   - reduced io overhead for video previews
   - you can now disable individual video file previews system wide at server config level (all enabled by default)

 **BugFixes**:
 - video plyr dark mode style issue where buttons are black instead of white
 - error when running without a config file #1280
 - Issue persist in 0.8.7 with Access Management #1282
 - all static resources go through /public/static url to fix logout loop #995
 - "realtime" Permission of API keys is not working #1141
 - "Path not found" when trying to share a file or folder inside a sub-directory #1139
 - logout path redirect not working
 - 2FA secret error #1305
 - console errors during login/logout
 - fix scoped user share creation issue #1309
 - share close button and navigation issues.
 - OnlyOffice source not found when opening shared file #1285
 - user scoped onlyoffice error saving files with Onlyoffice #1068

## v0.8.7-beta

 **New Features**:
 - json logging format support

 **Notes**:
 - increased overall file size limit to retrieve metadata from 50MB to 300MB #1234
 - document previews don't show up as folder previews.

 **BugFixes**:
 - Fix directories empty issue when disableIndexing is true #1249
 - OIDC to Authentik behind CloudFlare with Bot Fight turned on triggers a JS challenge #1165
 - OIDC Auth - loop with expired token #995
 - We lost the ability for download all? #1250
 - Directories are all empty when disableIndexing is true #1248
 - Access Management: issues on the shared folder when there's a sub folder #1208
 - user preferences for individual preview file types not getting respected (disable/enable office,image,video)
 - High server load when browsing folders with .mkv files #1259
 - 2FA can not be disabled with non-admin user #1244
 - 2FA not working on login #1243
 - Thumbnails of .m4a, .flac, and .opus are not displaying #1234
 - creating files/folders with same name overwrite each other #1242

## v0.8.6-beta

 **Notes**:
 - Please remove `indexAbumArt` config option from your config: it has been deprecated... I found a way to detect album art without impacting indexing performance -- so its default behavior.
 - Download button should be invisible before password input #1162
 - opus files / opus files detected wrongly #1164
 - changed autoplay behavior on plyr to not start playing if blocked instead of playing muted.
 - QR-Code disappearing / sliding out from shared link #1155
 - audio player matches dark/light mode better

 **BugFixes**:
 - Copy/Move index update changes to be more thorough and update album artwork #1220 #1219
 - fix preview related issues #1225 #1223
 - Scrollbar missing on user-edit-prompt in v0.8.5-beta #1221
 - copy share download link inconsistency #1207
 - fixed some onlyoffice related issues #1192 #1068
 - Creating a file, then a folder with the same name makes the folder unusable #1167
 - fix plyr issue switching from video to audio via next/previous button.

## v0.8.5-beta

 **New Features**:
 - backend media metadata processing
   - significantly improved performance
   - album artwork shows in listing view as preview thumbnail Album art thumbnail: display embedded covers of mp3/flac files #925
   - folders can show album art if enabled with indexing `server.sources.config.indexAlbumArt:true`
   - removed need for frontend dependancies.
 - optional thumbnail support for folders -- uses first child item with thumbnail as cover. Useful in combination with album metadata support to show album covers for folders with music.
 - Remember folder view type (and sorting) for each folder #966
 - heic is supported in viewer (via ffmpeg conversion) when on non-safari browser. This can be enabled via `integrations.ffmpeg.convert.impagePreview.heic: true` #1191
 - OnlyOffice: Add option to open documents in viewer mode (`integrations.office.viewOnly`) #1193
 - Exclude folders and file names 'starting with' or wildcard option #1054
 - added better info for failed uploads #1050
 - upload prompt "clear completed" can be changed to "clear all" in uploads & downloads settings to clear error and conflict states as well. #1128
 - share 'default view mode' option #1212
 - Universal Next/Previous buttons
   - available for all listing items (including office/markdown etc)
   - remembers sort order from parent directory
   - new "Quick Jump" prompt if you drag the next/previous icons. This shows other files available to "jump" directly to quickly.

 **Notes**:
 - Added more tests to ensure new features work in future.
 - caching for preview images is md5 based. Moved, renamed, or duplicate images don't get re-generated. Same album artwork shares cache.
 - Hide @eaDir folder by default #1212
 - defaults to hide "@eadir" folders (common for synology) #1212
 - After move/copy, ability to move to the destination folder #999

 **BugFixes**:
 - Access Management: issue with access settings #1195
 - fix shutdown panic related to sse connection
 - Custom theming not working in 0.8.4 beta #1204
 - Config Viewer not working #1189
 - "Path not found" when trying to share a file or folder inside a sub-directory #1139
 - files containing "+" in share issue #1089

## v0.8.4-beta

 **New Features**:
 - New media player styles and features
   - Custom Media Player: enhanced media player using plyr thanks @Kurami32 (see #1160)
   - Custom Media Player: also adds support for metadata
   - added embeded video subtitle support (for both native and custom player). @maxbin123 #1072 #1157
   - Users can disable the customer player and opt of native in profile settings.
 - Option to disable backend update check via `server.disableUpdateCheck` #1134
 - added `frontend.favicon` and `frontend.description` for html overrides
 - onlyoffice is now supported in shares. Both viewing and editing can be configured per-share.
 - Added only office debug view and wiki to assist with debugging issues #1068 #911 #1074
 - Dark mode enforcement possible for shared links #1029
 - added `System & Admin` section to settings
   - includes a new config viewer to see current running config (hides secrets) #838
 - added `server.minSearchLength` to allow adjusting the length requirement for search #1174

 **Notes**:
 - access management: specific folders/files with access are shown instead permission denied for parent folder
 - navigation no longer appends last location hash which should fix some unwanted navation behavior #1070
 - altered the context menu style and behavior.
 - documentation update: comma or Space separated extensions #1138
 - Files and folders can be created with "/" or "\" on the name #1126
 - Share management should not be allowed without authentication #1163
 - Question about customizing session timeout #1184

 **BugFixes**:
 - access management: delay showing rule changes in the list fixed. #1131
 - Color names are not localized #1159
 - rename issues #1170 #1171
 - some shortcuts not working #1056
 - Can't copy/paste text on mobile #1168
 - Can't change between images inside of the share image viewer. #1144
 - fixed and updated translations with variables always showing english.

## v0.8.3-beta

 **BugFixes**:
 - fixed search bar style bug in mobile #1147

## v0.8.2-beta

 **New Features**:
 - added `source.config.denyByDefault` configuration to enable a deny-by-default access rule. A source enabled with this will deny access unless an "allow" rule was specifically created. (Similar to creating a root-level denyAll rule)
 - allow oidc user source access and permission based on username and groups is fulfilled by denyByDefault source with access rules https://github.com/gtsteffaniak/filebrowser/issues/824
 - "open parent folder" in context menu and search results https://github.com/gtsteffaniak/filebrowser/issues/1121
 - added friendly "share not found" page.

 **Notes**:
 - 8.0 ffmpeg version bundled with docker
 - go 1.25 upgrade with green tea GC enabled
 - totp secrets accept non-secure strings, only throwing warning
 - adjusted download limit so it also counts viewing text "content" of files (like in editor). You can also "disable file viewing" to stop the editor from showing. lower quality file image previews are not counted as downloads.
 - updated invalid share message to be more clear https://github.com/gtsteffaniak/filebrowser/issues/1120

 **BugFixes**:
 - fixed /public/static routes issue
 - shares redirect to login - https://github.com/gtsteffaniak/filebrowser/issues/1109
 - some static assets not available to anonymous user - https://github.com/gtsteffaniak/filebrowser/issues/1102
 - more safari style issues https://github.com/gtsteffaniak/filebrowser/issues/1110
 - fix public share download issues https://github.com/gtsteffaniak/filebrowser/issues/1118 https://github.com/gtsteffaniak/filebrowser/issues/1089
 - fixed disable file viewer setting and enforced on backend

## v0.8.1-beta

 **New Features**:
 - api for generate download link (see swagger) https://github.com/gtsteffaniak/filebrowser/issues/1007
 - added `source.config.disabled` option to disable a source without removing it from config file.
 - added `source.config.private` option to designate as private -- currently just means no sharing permitted.
 - hide share card in share
 - download count for a share shows up on share management

 **Notes**:
 - updated description for indexingIntervalMinutes https://github.com/gtsteffaniak/filebrowser/issues/1067

 **BugFixes**:
 - fixed styling issues https://github.com/gtsteffaniak/filebrowser/issues/1086 https://github.com/gtsteffaniak/filebrowser/issues/1081 https://github.com/gtsteffaniak/filebrowser/issues/1082 https://github.com/gtsteffaniak/filebrowser/issues/1098
 - fix download limit issue https://github.com/gtsteffaniak/filebrowser/issues/1085
 - fixed oidc user defaults for new user https://github.com/gtsteffaniak/filebrowser/issues/1071
 - shares get updated when files moved in ui https://github.com/gtsteffaniak/filebrowser/issues/760
 - click listing behavior doesn't clear (introduced in 0.8.0) https://github.com/gtsteffaniak/filebrowser/issues/1101
 - show download count and limit in share list in settings https://github.com/gtsteffaniak/filebrowser/issues/1103
 - fix windows alt+arrow movement issue https://github.com/gtsteffaniak/filebrowser/issues/1094
 - nav memory issue for filenames with brackets https://github.com/gtsteffaniak/filebrowser/issues/1092
 - files with "+"" in name issue https://github.com/gtsteffaniak/filebrowser/issues/1089
 - fixed editor bug in share view https://github.com/gtsteffaniak/filebrowser/issues/1084
 - other share related issues https://github.com/gtsteffaniak/filebrowser/issues/1087 https://github.com/gtsteffaniak/filebrowser/issues/1064


## v0.8.0-beta

  This is a major release, new features and changes could introduce breaking behavior. Here are the known potentially breaking changes:

  - all public api and share url's get a `/public` prefix, making it easier to use with a reverse proxy. Any existing share link will still work but get redirected.
  - a small change to styling you may need to update your custom styling, for example the id `#input` was renamed `#search-input`

 **New Features**:
 - New access control system. You can add new allow / deny / denyAll rules for users/groups for specific paths on specific sources.
   - groups currently only works with provided oidc groups, but will add a full group management option for manual creation. https://github.com/gtsteffaniak/filebrowser/issues/545
 - share view changes -- now aligns with the standard listing view. This means files can be viewed and edited (if permission allows) just like a normal listing.
 - many share links customization enhancements
   - only share to certain authenticated users https://github.com/gtsteffaniak/filebrowser/issues/656 https://github.com/gtsteffaniak/filebrowser/issues/985
   - one-time download links
   - customize share theme https://github.com/gtsteffaniak/filebrowser/issues/827 https://github.com/gtsteffaniak/filebrowser/issues/1029
   - share link public changes https://github.com/gtsteffaniak/filebrowser/issues/473
   - shares can be modified/configured after creation.
   - download throttling for shares

 **Notes**:
 - hover effect on list/compact view https://github.com/gtsteffaniak/filebrowser/issues/1036

 **BugFixes**:
 - fix new file "true" content issue https://github.com/gtsteffaniak/filebrowser/issues/1048
 - editor allows device default popup https://github.com/gtsteffaniak/filebrowser/issues/1049

## v0.7.18-beta

 **Notes**:
 - desktop context menu "select multiple" enabled as optional user default (#1000)
 - onlyoffice readonly document types (".pages", ".numbers", ".key") list (#1018)
 - onlyoffice tweaks to make more consistent, added logging (#1015)

 **BugFixes**:
 - fix lightBackground issue (#1021)
 - fix user save issues (#1020, #1027)
 - fix image preview cache issue (#989)
 - fix file/folder count issue (#989)
 - only first file was upload on drag-n-drop (#1024)

## v0.7.17-beta

See an example of custom css styling that uses the reduce-rounded-corners.css by default and allows users to choose other themes. You can add your own themes as well that users can choose from in profile settings:

```
frontend:
  styling:
    lightBackground: "#f0f0f0"   # or names of css colors
    darkBackground: "#121212"
    customCSS: "custom.css"  # custom css file always applies first, then user themes on top of that.
    customThemes:
      "default": # if "default" is specified as the name, it will be the default option
        description: "Reduce rounded corners"
        css: "reduce-rounded-corners.css" # path to css file to use
      "original":
        description: "Original rounded theme"
        css: ""  # you could default to no styling changes this way.
```

 **New Features**:
 - more custom styling options (thanks @mordilloSan for #997)
   - background colors can be easily set in config
   - provided an example `reduce-rounded-corners.css` available by default in docker. (#986, #837)
   - added feature to specify multiple css themes that users can choose from in profile settings
 - swipe between photos on mobile (#825)

 **Notes**:
 - changed partition calculations on linux for total disk size (#982)
 - upload conflict detection for folders offers "replace all" if the folder already exists in target location.

 **BugFixes**:
 - TOTP prompt not showing generated code issue https://github.com/gtsteffaniak/filebrowser/issues/996
 - select mulitple deselect on mobile (#1002)
 - viewing svg images.

## v0.7.16-beta

 **Notes**:
 - more server logging for uploads when debug logging is enabled

 **BugFixes**:
 - fix onlyoffice integration viewing bug (#990)
 - fix uploading files with exec permissions (#984)
 - fix redirect on no source path (#989)
 - refresh file info on rename (#989)
 - listing refreshes when uploads finish (#989)
 - disable edit mode for certain onlyoffice files (#971)

## v0.7.15-beta

 **New Features**:
 - added userDefault `disableViewingExt`. The new properties apply to all files, not just office.
 - code blocks in markdown viewer have line numbers and each line is highlightable

 **Notes**:
 - replaced `disableOfficePreviewExt` with more generally applicable `disablePreviewExt` to disable preview for any specific file type.
 - more tooltip descriptions for settings options

 **BugFixes**:
 - fix chinese and other language error (#972, #969)
 - fix docker dockerfile for `docker run` (#973)
 - fix double slash href on single source (#968)
 - fix sources named "files" or "share" issue (#949, #574)
 - focus input field on popups (#976)
 - hopeful fix for size calculation (#982)
 - edit button is not working on .md files (#983)

## v0.7.14-beta

 **Notes**:
 - Updated translations https://github.com/gtsteffaniak/filebrowser/issues/957
 - enabled more doc types for onlyoffice https://github.com/gtsteffaniak/filebrowser/discussions/945

 **BugFixes**:
 - noauth user issue https://github.com/gtsteffaniak/filebrowser/issues/955
 - error 403 on source name with special characters https://github.com/gtsteffaniak/filebrowser/issues/952
 - delete pictures in previewer issue https://github.com/gtsteffaniak/filebrowser/issues/456
 - trailing slash source name issue https://github.com/gtsteffaniak/filebrowser/issues/920
 - image lazy loading issue causing all items to get previews at one time, not just whats in view.

## v0.7.13-beta

 **New Features**:
 - copy and Move files between sources https://github.com/gtsteffaniak/filebrowser/issues/689
 - new enhanced upload prompt
   - uses chunked uploads https://github.com/gtsteffaniak/filebrowser/issues/770
   - all or individual uploads can be paused/resumed
   - individual uploads can be retried
   - individual file upload progress https://github.com/gtsteffaniak/filebrowser/issues/871
   - keeps screen on https://github.com/gtsteffaniak/filebrowser/issues/900

 **Notes**:
 - lots of UI improvements
 - reworked a lot of the frontend path/source logic to be more consistent.
 - updated sort behavior to be natural sort https://github.com/gtsteffaniak/filebrowser/issues/551
 - optional quick save icon https://github.com/gtsteffaniak/filebrowser/issues/918
 - improved language support: zh-tw chinese traditional (tawain)

 **BugFixes**:
 - more accurate disk used calculation -- accounting for hard links and sparse files. https://github.com/gtsteffaniak/filebrowser/issues/921
 - fix api key revoking mechanism
 - fixed shift-select https://github.com/gtsteffaniak/filebrowser/issues/929
 - video preview images on safari https://github.com/gtsteffaniak/filebrowser/issues/932
 - sticky mode isn't sticky https://github.com/gtsteffaniak/filebrowser/issues/916

## v0.7.12-beta

Happy 4th of July!

The most noteworthy change is that no sources will be automatically enabled for any user. In order for a user to use a source, it needs to be added for that user. Or to keep a source available for all users, you can specify `defaultEnabled` in the source config to maintain the same behavior. See the wiki

 **New Features**:
 - setting added `deleteWithoutConfirming`, useful for quickly deleting files -- does not apply to folders.
 - more options for minimal UI https://github.com/gtsteffaniak/filebrowser/issues/745
 - dedicated section for sidebar customization in profile settings https://github.com/gtsteffaniak/filebrowser/issues/437

 **Notes**:
 - Filebrowser no longer requires a default source, users can be created without any sources.
 - Disables changing login type fallback behavior https://github.com/gtsteffaniak/filebrowser/issues/620
 - Uses calculated index size as "used" and total partition size as "total" https://github.com/gtsteffaniak/filebrowser/issues/875
 - Select multiple won't show up in context menu when using a desktop browser (with keyboard), opting for keyboard shortcuts
 - Updated translations that were not complete, such as simplified chinese https://github.com/gtsteffaniak/filebrowser/issues/895
 - larger min drop target size https://github.com/gtsteffaniak/filebrowser/issues/902
 - refresh page after file actions https://github.com/gtsteffaniak/filebrowser/issues/894
 - improved user PUT handler for easier user modification via API https://github.com/gtsteffaniak/filebrowser/issues/897
 - optional sidebar actions for upload/create https://github.com/gtsteffaniak/filebrowser/issues/885

 **BugFixes**:
 - fix delete in preview when moving between pictures. https://github.com/gtsteffaniak/filebrowser/issues/456
 - getting file info issue when indexing is disabled.
 - fixed initial sort order https://github.com/gtsteffaniak/filebrowser/issues/551
 - incorrect filename Drag and Drop fixes https://github.com/gtsteffaniak/filebrowser/issues/880
 - fix share duration always showing just now https://github.com/gtsteffaniak/filebrowser/issues/896

## v0.7.11-beta

 **Breaking Changes**:
  - `auth.resetAdminOnStart` has been removed. Instead, if you have `auth.adminPassword` set it will always be reset on startup. If you want to change your default admin password afterwards, make sure to unset `auth.adminPassword` so it doesn't get reset on startup.
  - renamed include/exclude rules see [updated example wiki](https://github.com/gtsteffaniak/filebrowser/wiki/Configuration-And-Examples#example-advanced-source-config)!

 **New Features**:
 - more comprehensive exclude/include rules (see example wiki above).
   - include/exclude parts of folder names as well https://github.com/gtsteffaniak/filebrowser/issues/854
   - include/exclude file or folder names globally.
 - `source.config.neverWatchPaths` is now functional -- a list of paths that get indexed initially, but skips re-indexing. Useful for directories you don't expect to change ever, still show up in search but get don't contribute to indexing time after initial indexing.

 **Notes**:
 - updated swagger docs https://github.com/gtsteffaniak/filebrowser/issues/849

 **BugFixes**:
 - fix version update notification for binary https://github.com/gtsteffaniak/filebrowser/issues/836
 - ctrl-click cache issue https://github.com/gtsteffaniak/filebrowser/issues/735
 - fix admin user reset OIDC user https://github.com/gtsteffaniak/filebrowser/issues/811 https://github.com/gtsteffaniak/filebrowser/issues/851
 - fix windows and binary muPdf issue https://github.com/gtsteffaniak/filebrowser/issues/744
 - fix logout oidc issue https://github.com/gtsteffaniak/filebrowser/issues/829 https://github.com/gtsteffaniak/filebrowser/issues/662
 - file name upload bug https://github.com/gtsteffaniak/filebrowser/issues/662
 - could not create share with absolute timestamps enabled https://github.com/gtsteffaniak/filebrowser/issues/764
 - context menu off screen issue https://github.com/gtsteffaniak/filebrowser/issues/828

## v0.7.10-beta

 **OIDC change**: if you specify `oidc.userIdentifier: "username"`, originally this would map to `preferred_username` but now it maps to `username` explicitly. To maintain the same behavior update your config to `userIdentifier: "preferred_username"`. This was updated to allow for `username` to work as [some might need](https://github.com/gtsteffaniak/filebrowser/pull/789).

 **New Features**:
 - Added settings option to stop sidebar from automatically hiding on editor and previews. https://github.com/gtsteffaniak/filebrowser/issues/744
 - Added more secrets loadable from environment variables. https://github.com/gtsteffaniak/filebrowser/issues/790
 - Include/exclude files are checked for existence to assist with configuration, will show as warning if something is configured but doesn't exist.
 - Added open in new tab link for preview items to view the raw picture, pdf, etc. Especially helpful for safari viewing PDF documents. https://github.com/gtsteffaniak/filebrowser/issues/734
 - Added autoplay media toggle in user profile, to automatically play videos and audio.

 **Notes**:
 - Allowed to delete default admin user https://github.com/gtsteffaniak/filebrowser/issues/811 https://github.com/gtsteffaniak/filebrowser/issues/762
 - Better try/catch error handling for user feedback for shares https://github.com/gtsteffaniak/filebrowser/issues/732

 **BugFixes**:
 - Fix share scope creation issue https://github.com/gtsteffaniak/filebrowser/issues/809
 - Fix oidc token logout issue https://github.com/gtsteffaniak/filebrowser/issues/791
 - Non-admin users OTP issue https://github.com/gtsteffaniak/filebrowser/issues/815
 - Linewrap issue for a few cases https://github.com/gtsteffaniak/filebrowser/issues/810
 - BaseUrl redirect issue with proxies https://github.com/gtsteffaniak/filebrowser/issues/796
 - Fix exclude still shows up in ui issue https://github.com/gtsteffaniak/filebrowser/issues/797
 - Copy/move functions are async https://github.com/gtsteffaniak/filebrowser/issues/812
 - fix subtitle fetch issue https://github.com/gtsteffaniak/filebrowser/issues/766
 - fix location memory issue for url encoded file names

## v0.7.9-beta

 **New Features**:
 - Admin users will get a small notification banner for available update in sidebar with link to new release.

 **Notes**:
 - docker now defaults to ./data/databse.db as the database path allowing a simplified initial docker-compose.yaml. Existing configurations do not need updating.
 - oidc groups header updates admin permission of existing user (either add/remove if role exists)'
 - builds amd64 binary with musl for compatibility (glic error) https://github.com/gtsteffaniak/filebrowser/issues/755
 - renamed `server.sources.config.disabled` to `server.sources.config.disableIndexing`
 - better support for running with disabled index.
 - small indexing behavior tweaks.
 - markdown viewer hides sidebar https://github.com/gtsteffaniak/filebrowser/issues/744
 - quick download only applies to files

 **BugFixes**:
 - subtitles filename issue https://github.com/gtsteffaniak/filebrowser/issues/678
 - search result links not working with custom baseUrl https://github.com/gtsteffaniak/filebrowser/issues/746
 - preview error for office native preview https://github.com/gtsteffaniak/filebrowser/issues/744
 - more source name safety for special characters.
 - shares with special character errors https://github.com/gtsteffaniak/filebrowser/issues/753
 - backspace navigates back a page when typing https://github.com/gtsteffaniak/filebrowser/issues/663
 - markdown viewer scrolling https://github.com/gtsteffaniak/filebrowser/issues/767
 - fix user permissions updated when modifying api key permissions
 - fix language change issue https://github.com/gtsteffaniak/filebrowser/issues/768 https://github.com/gtsteffaniak/filebrowser/issues/487

## v0.7.8-beta

Note: if using oidc, please update from 0.7.7 to resolve invalid_grant issue. Also - oidc no longer creates users automatically by default -- must be enabled.

 **New Features**:
 - More oidc user creation options https://github.com/gtsteffaniak/filebrowser/issues/685
   - `auth.methods.oidc.createUser` must be true to automatically create user, defaults to false.
   - `auth.methods.oidc.adminGroup` allows using oidc provider group name to enable admin user creation.

 **BugFixes**:
 - fix save editor info sometimes saves wrong file. https://github.com/gtsteffaniak/filebrowser/issues/701
 - make ctrl select work on mac or windows. https://github.com/gtsteffaniak/filebrowser/issues/739
 - oidc login failures introduced in 0.7.6 https://github.com/gtsteffaniak/filebrowser/issues/731
 - oidc respects non-default baseURL

## v0.7.7-beta

  This release cleans up some of the native preview (image preview) feature logic. And adds simple docx and epub viewers as well. Going through all of this, I think I know how I can add full-fledge google doc and microsoft office viewer support (no edit). But, for now "onlyOffice" remains the most comprehensive solution with most compatibility and ability to fully edit. One day, I think I will be able to integrate a minimal license-free server into the docker image. But that's something for another time.

  Native preview (image preview) support is also available for linux arm64 and amd64 binaries, and windows exe.

 **New Features**:
 - since theres a wider kind of document preview types, a new disableOfficePreviewExt option has been added.
 - native (and simple) docx and epub viewers.
 - Other documents like xlsx get full size image preview when opened and no onlyoffice support.

 **Notes**:
 - all text mimetype files have preview support.
 - high-quality preview image sizes bumped from 512x512 to 640x640 to help make text previews readable.
 - no config is allowed and defaults to on source at current directory.

 **BugFixes**:
 - fix otp clearing on user save https://github.com/gtsteffaniak/filebrowser/issues/699
 - admin special characters and general login improvements https://github.com/gtsteffaniak/filebrowser/issues/594
 - updated editor caching behavior https://github.com/gtsteffaniak/filebrowser/issues/701
 - move/copy file path issue and overwrite https://github.com/gtsteffaniak/filebrowser/issues/687
 - fix popup preview loading on safari
 - `preview.highQuality` only affects gallery view mode. popop preview is always high quality, and icons are always low quality.

## v0.7.6-beta

 **New Features**:
 - native document preview generation enabled for certain document types on the regular docker image (no office integration needed)
   - supported native document preview types:
     - ".pdf",  // PDF
     - ".xps",  // XPS
     - ".epub", // EPUB
     - ".mobi", // MOBI
     - ".fb2",  // FB2
     - ".cbz",  // CBZ
     - ".svg",  // SVG
     - ".txt",  // TXT
     - ".docx", // DOCX
     - ".ppt",  // PPT
     - ".pptx", // PPTX
     - ".xlsx", // exel XLSX
     - ".hwp",  // HWP
     - ".hwp",  // HWPX
 - proxy logout redirectUrl support via `auth.methods.proxy.logoutRedirectUrl` https://github.com/gtsteffaniak/filebrowser/issues/684

 **Notes**:
 - image loading placeholders added and remain if image can't be loaded.
 - no more arm32 support on main image -- use a `slim` tagged image.

 **BugFixes**:
 - onlyoffice and other cache issues https://github.com/gtsteffaniak/filebrowser/issues/686
 - gallery size indicator centering https://github.com/gtsteffaniak/filebrowser/issues/652

## v0.7.5-beta

 **New Features**
 - new `./filebrowser.exe setup` command for creating a config.yaml on first run. https://github.com/gtsteffaniak/filebrowser/issues/675
 - new 2FA/OTP support for password-based users.
 - `auth.password.enforcedOtp` option to enforce 2FA usage for password users.

 **Notes**:
 - logging uses localtime, optional UTC config added https://github.com/gtsteffaniak/filebrowser/issues/665
 - generated config example now includes defaults https://github.com/gtsteffaniak/filebrowser/issues/590
 - `server.debugMedia` config option added to help debug ffmpeg issues in the future (don't enable unless debugging an issue)
 - more translations additions from english settings https://github.com/gtsteffaniak/filebrowser/issues/653
 - visual tweaks https://github.com/gtsteffaniak/filebrowser/issues/652
 - enhanced markdown viewer with code view spec

 **BugFixes**:
 - long video names ffmpeg issue fixed https://github.com/gtsteffaniak/filebrowser/issues/669
 - certain files not passing content https://github.com/gtsteffaniak/filebrowser/issues/657
 - https://github.com/gtsteffaniak/filebrowser/issues/668
 - allow edit markdown files
 - rename button doesn't close prompt https://github.com/gtsteffaniak/filebrowser/issues/664
 - webm video preview issue https://github.com/gtsteffaniak/filebrowser/issues/673
 - fix signup issue https://github.com/gtsteffaniak/filebrowser/issues/648
 - fix default source bug
 - https://github.com/gtsteffaniak/filebrowser/issues/666
 - fix 500 error for subtitle videos https://github.com/gtsteffaniak/filebrowser/issues/678
 - spaces and special characters in source name issue https://github.com/gtsteffaniak/filebrowser/issues/679

![image](https://github.com/user-attachments/assets/28e4e67e-31a1-4107-9294-0e715e87b558)

## v0.7.4-beta

 **Notes**:
 - Updated German translation. https://github.com/gtsteffaniak/filebrowser/pull/644

 **BugFixes**:
 - windows control click https://github.com/gtsteffaniak/filebrowser/issues/642
 - create user issue https://github.com/gtsteffaniak/filebrowser/issues/647

## v0.7.3-beta

Note: OIDC changes require config update.

 **New Features**
 - Added code highlights to text editor and enabled text editor for all asci files under 25MB
 - Motion previews for videos -- cycles screenshots of vidoes. https://github.com/gtsteffaniak/filebrowser/issues/588
 - Optionally reset default admin username/password on startup, to guarentee a username/password on startup if needed. Use by setting `auth.resetAdminOnStart` true https://github.com/gtsteffaniak/filebrowser/issues/625

 **Notes**:
 - Updated translations everywhere. https://github.com/gtsteffaniak/filebrowser/issues/627
 - Office viewer is now full-screen with floating close button. https://github.com/gtsteffaniak/filebrowser/issues/542
 - OIDC config additions
   - `issuerUrl` required now to get relevant oidc configurations.
   - `disableVerifyTLS` optionally, disable verifying HTTPS provider endpoints.
   - `logoutRedirectUrl` optionally, redirect the user to this URL on logout.
   - other URL config parameters are no longer accepted -- replace with issuerUrl.
 - Aadmins allowed to change user login methods in user settings when creating or updating users.
   - https://github.com/gtsteffaniak/filebrowser/issues/618
   - https://github.com/gtsteffaniak/filebrowser/issues/617
 - Hide header when showing only office https://github.com/gtsteffaniak/filebrowser/issues/542

 **BugFixes**:
 - Editor save shows notification
 - Preview settings resetting on startup
 - Not all languages show correctly https://github.com/gtsteffaniak/filebrowser/issues/623
 - scopes sometimes reset on startup https://github.com/gtsteffaniak/filebrowser/issues/636
 - Update save password option
   - https://github.com/gtsteffaniak/filebrowser/issues/587
   - https://github.com/gtsteffaniak/filebrowser/issues/619
   - https://github.com/gtsteffaniak/filebrowser/issues/615

## v0.7.2-beta

The `media` tags introduced in 0.7.0 have been removed -- all docker images have media enabled now.

  **Notes**:
  - Reverts enforced user login methods types -- until suitable methods to alter are available.
  - When updating a user, updating scope always sets to the exact scope specified on updated.
  - Redirect api messages are INFO instead of WARN
  - Settings has close button instead of back https://github.com/gtsteffaniak/filebrowser/issues/583

  **Bug Fixes**:
  - Hover bug when exact timestamp setting enabled https://github.com/gtsteffaniak/filebrowser/issues/585

## v0.7.1-beta

The `media` tags introduced in 0.7.0 have been removed -- all docker images have media enabled now.

  **Notes**:
  - changes to support jwks url needed for authelia - still needs testing to ensure it works https://github.com/gtsteffaniak/filebrowser/issues/575, added debug logs to help identify any further issues.
  - added apache license file back https://github.com/gtsteffaniak/filebrowser/discussions/599
  - updated toggle view icons to better match.
  - adjusted popup preview position on mobile.
  - updated createUserDir logic, https://github.com/gtsteffaniak/filebrowser/issues/541
    - it always creats user dir (even for admins)
    - scope path must exist if it doesn't end in username, and if it does, the parent dir must exist
    - enforced user login methods types -- can't be changed. a password user cannot login as oidc, etc.

  **Bug Fixes**:
  - right click context menu issue https://github.com/gtsteffaniak/filebrowser/issues/598
  - upload file issue https://github.com/gtsteffaniak/filebrowser/issues/597
  - defaultUserScope is not respected https://github.com/gtsteffaniak/filebrowser/issues/589
  - defaultEnabled is not respected https://github.com/gtsteffaniak/filebrowser/issues/603
  - user has weird navigation barhttps://github.com/gtsteffaniak/filebrowser/issues/593
  - fix multibutton state issue for close overlay https://github.com/gtsteffaniak/filebrowser/issues/596

## v0.7.0-beta

 **New Features**:
 - New authentication method: OIDC (OpenID Connect)
 - UI refresh
   - Refreshed icons and styles to provide more contrast https://github.com/gtsteffaniak/filebrowser/issues/493
   - New scrollbar which includes information about the listing https://github.com/gtsteffaniak/filebrowser/issues/304
   - User-configurable popup previewer and user can control preview size of images.
   - Enhanced user settings page with more toggle options.
   - Replaced checkboxes with toggles switches https://github.com/gtsteffaniak/filebrowser/issues/461
   - Refreshed Breadcrumbs style.
   - Main navbar icon is multipurpose menu, close, back and animates
   - Enhanced source info on the UI
     - User must have permission `realtime: true` property to get realtime events.
     - Sources shows status of the directory `ready`, `indexing`, and `unavailable`
   - Top-right overflow menu for deleting / editing files in peview https://github.com/gtsteffaniak/filebrowser/issues/456
   - Helpful UI animation for drag and drop files, to get feedback where the drop target is.
   - More consistent theme color https://github.com/gtsteffaniak/filebrowser/issues/538
 - New file preview types:
   - Video thumbnails available via new media integration (see configuration wiki for help) https://github.com/gtsteffaniak/filebrowser/issues/351
   - Office file previews if you have office integration enabled. https://github.com/gtsteffaniak/filebrowser/issues/460

  **Notes**:
  - sesssionId is now unique per window. Previously it was shared accross browser tabs.
  - DisableUsedPercentage is a backend property now, so users can't "hack" the information to be shown.
  - Updated documentation for resources api https://github.com/gtsteffaniak/filebrowser/issues/560
  - Updated placeholder for scopes https://github.com/gtsteffaniak/filebrowser/issues/475
  - When user's API permissions are removed, any api keys the user had will be revoked.
  - `server.enableThumbnails` moved to `server.disablePreviews` defaulting to false.
  - `server.resizePreview` moved to `server.resizePreviews` (with an "s" at the end)

  **Bug Fixes**:
  - Nil pointer error when source media is disconnected while running.
  - Source selection buggy https://github.com/gtsteffaniak/filebrowser/issues/537
  - Upload folder structure https://github.com/gtsteffaniak/filebrowser/issues/539
  - Editing files on multiple sources https://github.com/gtsteffaniak/filebrowser/issues/535
  - Prevent the user from changing the password https://github.com/gtsteffaniak/filebrowser/issues/550
  - Links in setting page does not navigate to correct location https://github.com/gtsteffaniak/filebrowser/issues/474
  - Url encoding issue https://github.com/gtsteffaniak/filebrowser/issues/530
  - Certain file types being treated as folders https://github.com/gtsteffaniak/filebrowser/issues/555
  - Source name with special characters https://github.com/gtsteffaniak/filebrowser/issues/557
  - Onlyoffice support on proxy auth https://github.com/gtsteffaniak/filebrowser/issues/559
  - Downloading with user scope https://github.com/gtsteffaniak/filebrowser/issues/564
  - User disableSettings property to be respected.
  - Non admin users updating admin settings.
  - Right click context issue on safari desktop.
  - office save file issue.

## v0.6.8-beta

 **New Features**
 - environment variables are available for certain secrets.
   - see wiki https://github.com/gtsteffaniak/filebrowser/wiki/Environment-Variables
   - thanks @aaronkyriesenbach https://github.com/gtsteffaniak/filebrowser/pull/511

 **Notes**:
 - config validation (see https://github.com/gtsteffaniak/filebrowser/wiki/Full-Config-Example)
   - fails when config file contains unknown fields (helps spot typos)
   - some light value validation on certain fields
   - removed recaptcha -- was disabled and not used before.
   - moved `recaptcha` and `signup` configs to `auth.methods.password`

 **BugFixes**:
 - fix scope reset on restart https://github.com/gtsteffaniak/filebrowser/issues/515
 - Clicking empty space to deselect https://github.com/gtsteffaniak/filebrowser/issues/492

## v0.6.7-beta

 **Notes**:
 - added full tests for single source example.
 - adds descriptive error if temp dir can't be created on fatal startup
 - clears temp directory on shutdown.
 - removed put settings api (unused)
 - removed more unused config properties.

 **BugFixes**:
 - fix url encoding issue for search links when theres only one source https://github.com/gtsteffaniak/filebrowser/issues/501
 - files with # could have problems, double encoded.

## v0.6.6-beta

 **New Feature**:
 - limit tar size creation to limit server burden. For example, don't let customers try to download the entire filesystem as a zip. see `server.maxArchiveSize` on config wiki.

 **Notes**:
 - disableUsedPercentage also hides text and source bar.
 - share errors show up in logs in more verbose way.
 - archive creation occurs on disk rather than in memory, use `server.cacheDir` to determine where temp files are stored.
 - automatically ensures leading slash for scope
   - https://github.com/gtsteffaniak/filebrowser/issues/472
   - https://github.com/gtsteffaniak/filebrowser/issues/476

 **BugFixes**:
 - fix proxy user creation issue https://github.com/gtsteffaniak/filebrowser/issues/478
 - externalUrl prefix issue fixed for shares. https://github.com/gtsteffaniak/filebrowser/issues/465
 - fix File Opens Instead of Just Downloading https://github.com/gtsteffaniak/filebrowser/issues/480
 - fix Download file name https://github.com/gtsteffaniak/filebrowser/issues/481

## v0.6.5-beta

 **Notes**:
 - added more share and download tests

 **BugFixes**:
 - fix share download issue https://github.com/gtsteffaniak/filebrowser/issues/465
 - fix content length size calculation issue when downloading multiple files.

## v0.6.4-beta

 **BugFixes**:
 - fix preview arow issue. https://github.com/gtsteffaniak/filebrowser/issues/457
 - fix password change issue.
 - apply user defaults to publi user on startup https://github.com/gtsteffaniak/filebrowser/issues/451

## v0.6.3-beta

 **Notes**:
 - windows directories get better naming, root directories like "D:\ get named "D", otherwise base filepath is the name when unselected "D:\path\to\folder" gets named "folder" (just like linux)
 - `.pdf` files added to default onlyoffice exclusion list.

 **BugFixes**:
 - windows would not refresh file info automatically when viewing because of path issue.
 - windows paths without name for "D:\" would cause issues.
 - share path error https://github.com/gtsteffaniak/filebrowser/issues/429
 - fix bug where resource content flag would load entire file into memory.

## v0.6.2-beta

 **Notes**:
 - Added playwright tests for bugfixes for permantent fix for stability.
    (except onlyoffice since it requires integrations)

 **BugFixes**:
 - Context menu should only be available inside the folder/files container https://github.com/gtsteffaniak/filebrowser/issues/430
 - drag and drop files from desktop to browser is fixed.
 - replace prompt cancel button didn't work.
 - key events on listing page not working (like delete key)
 - fixed share viewing issue https://github.com/gtsteffaniak/filebrowser/issues/429
 - disableUsedPercentage hides entire source https://github.com/gtsteffaniak/filebrowser/issues/438
 - createUserDir fix for proxy users and new users https://github.com/gtsteffaniak/filebrowser/issues/440

## v0.6.1-beta

 **New Feature**:
 - download size information is added, including when downloding multiple files in zip/tar.gz. The browser will see the XMB of X GB and will show browser native progress.

 **BugFixes**:
 - fixed onlyoffice bug https://github.com/gtsteffaniak/filebrowser/issues/418
 - fixed breadcrumbs bug https://github.com/gtsteffaniak/filebrowser/issues/419
 - fixed search context bug https://github.com/gtsteffaniak/filebrowser/issues/417
 - fixed sessionID for search

## v0.6.0-beta

> [!WARNING]
> This release includes several config changes that could cause issues. Please backup your database file before upgrading.

This release has several changes that should work without issues... however, still backup your database file first and proceed with caution. User permissions and source config changes have been updated -- and the `server.root` paramter is no longer used.

This is a significant step towards a stable release. There shouldn't be any major breaking config changes after this.

 **New Features**:
  - multiple sources support https://github.com/gtsteffaniak/filebrowser/issues/360
    - listing view keeps them independant, you switch between the two and the url address will have a prefix `/files/<sourcename>/path/to/file` when there is more than 1 source.
    - search also happens independantly, with a selection toggle per source. searching current source searches the current scope in the listing view, if you toggle to an alternative source it will search from the source root.
    - copy/moving is currently only supported within the same source -- that will come in a future release.
  - `FILEBROWSER_CONFIG` environment variable is respected if no CLI config parameter is provided. https://github.com/gtsteffaniak/filebrowser/issues/413

 **Notes**:
  - downloads no longer open new window.
  - swagger updated with auth api help for things like api token.
    - GET api keys now uses `name` query instead of `key`. eg `GET /api/auth/tokens?name=apikeyname`
  - user permissions simplified to four permission groups (no config change required):
    - **removed**  : create, rename, delete, download
    - **remaining**: admin, modify, share, api
    - `scope` is deprecated, but still supported, applies to default source. if using multiple sources, set `defaultUserScope` at the [source config](https://github.com/gtsteffaniak/filebrowser/wiki/Configuration#default-source-configuration) instead.
  - **removed** user rules and commands.
    - commands feature has never been enabled so just removing the references.
    - rules will come back in a different form (not applied to the user).
  - `server.root` is completely removed in favor of `server.sources`

 **BugFixes**:
  - fix conflict resolution issue https://github.com/gtsteffaniak/filebrowser/issues/384
  - many user creation page bugfixes.
  - fix share delete issue https://github.com/gtsteffaniak/filebrowser/issues/408

## v0.5.4-beta

 **BugFixes**:
  - default scope share issue. @theryecatcher https://github.com/gtsteffaniak/filebrowser/pull/387
  - drag and drop on empty folders https://github.com/gtsteffaniak/filebrowser/issues/361
  - preview navigation issue https://github.com/gtsteffaniak/filebrowser/issues/372
  - auth proxy password length error https://github.com/gtsteffaniak/filebrowser/issues/375

<img width="294" alt="image" src="https://github.com/user-attachments/assets/669bca75-98d4-47c1-838b-1ffee2967d7d" />

## v0.5.3-beta

 **New Features**:
  - onlyoffice disable filetypes for user specified file types. https://github.com/gtsteffaniak/filebrowser/issues/346

 **Notes**:
  - navbar/sidebar lightmode style tweaks.
  - any item that has utf formatted text will get editor.
  - tweaks to create options on context menu.
  - removed small delay on preview before detecting the file.

 **BugFixes**:
  - fix `/files/` prefix loading issue https://github.com/gtsteffaniak/filebrowser/issues/362
  - fix special characters in filename issue https://github.com/gtsteffaniak/filebrowser/issues/357
  - fix drag and drop issue https://github.com/gtsteffaniak/filebrowser/issues/361
  - fix conflict issue with creating same file after deletion.
  - fix mimetype detection https://github.com/gtsteffaniak/filebrowser/issues/327
  - subtitles for videos https://github.com/gtsteffaniak/filebrowser/issues/358
    - supports caption sidecar files : ".vtt", ".srt", ".lrc", ".sbv", ".ass", ".ssa", ".sub", ".smi"
    - embedded subtitles not yet supported.

## v0.5.2-beta

 **New Features**:
  - Markdown file preview https://github.com/gtsteffaniak/filebrowser/issues/343
  - Easy access download button https://github.com/gtsteffaniak/filebrowser/issues/341

 **Notes**:
  - Adds message about what sharing means when creating a link.
  - api log duration is now always in milliseconds for consistency.
  - advanced index config option `fileEndsWith` is now respected.
  - Added Informative error for missing files for certificate load https://github.com/gtsteffaniak/filebrowser/issues/354

 **BugFixes**:
  - onlyoffice close window missing files issue https://github.com/gtsteffaniak/filebrowser/issues/345
  - fixed download link inside file preview

## v0.5.1-beta

 > Note: I changed the [config](https://github.com/gtsteffaniak/filebrowser/wiki/Configuration#example-auth-config) for password auth again... It was a mistake just to make it a boolean, so now you can provide options, going forward this allows for more.

  **New Features**:
  - password length requirement config via `auth.methods.password.minLength` as a number of characters required.

  **Bugfixes**:
  - NoAuth error message "resource not found"
  - CLI user configuration works and simplified see examples in the [Wiki](https://github.com/gtsteffaniak/filebrowser/wiki/CLI)

## v0.5.0-beta

 > Note: This Beta release includes a configuration change: `auth.method` is now deprecated. This is done to allow multiple login methods at once. Auth methods are specified via `auth.methods` instead. see [example on the wiki](https://github.com/gtsteffaniak/filebrowser/wiki/Configuration#example-auth-config).

  **New Features**:
  - Upload progress notification https://github.com/gtsteffaniak/filebrowser/issues/303
  - proxy auth auto create user when `auth.methods.proxy.createUser: true` while using proxy auth.

  **Notes**:
  - Context menu positioning tweaks.
  - using /tmp cachedir is disabled by default, cache dir can be specified via `server.cacheDir: /tmp` to enable it. https://github.com/gtsteffaniak/filebrowser/issues/326

  **Bugfixes**:
  - Gracefully shutdown to protect database. https://github.com/gtsteffaniak/filebrowser/issues/317
  - validates auth method provided before server startup.
  - fix sidebar disk space usage calculation. https://github.com/gtsteffaniak/filebrowser/issues/315
  - Fixed proxy auth header support (make sure your proxy and server are secure!). https://github.com/gtsteffaniak/filebrowser/issues/322

## v0.4.2-beta

  **New Features**:
  - Hidden files changes
    - windows hidden file properties are respected -- when running on windows binary (not docker) with NTFS filesystem.
    - windows "system" files are considered hidden.
    - changed user property from `hideDotFiles` to `showHidden`. Defaults to false, so a user would need to must unhide hidden files if they want to view hidden files.

  **Notes**:
  - cleaned up old and deprecated config.
  - removed unneeded "Global settings". All system configuration is done on config yaml, See configuration wiki for more help.

  **Bugfixes**:
  - Another fix for memory https://github.com/gtsteffaniak/filebrowser/issues/298

## v0.4.1-beta

  **New Features**:
  - right-click actions are available on search. https://github.com/gtsteffaniak/filebrowser/issues/273

  **Notes**:
  - delete prompt now lists all items that will be affected by delete
  - Debug and logger output tweaks.

  **Bugfixes**:
  - calculating checksums errors.
  - copy/move issues for some circumstances.
  - The previous position wasn't returned when closing a preview window https://github.com/gtsteffaniak/filebrowser/issues/298
  - fixed sources configuration mapping error (advanced `server.sources` config)

## v0.4.0-beta

  **New Features**:
  - Better logging https://github.com/gtsteffaniak/filebrowser/issues/288
    - highly configurable
    - api logs include user
  - onlyOffice support for editing only office files (inspired from https://github.com/filebrowser/filebrowser/pull/2954)

  **Notes**:
  - Breadcrumbs will only show on file listing (not on previews or editors)
  - Config file is now optional. It will run with default settings without one and throw a `[WARN ]` message.
  - Added more descriptions to swagger API

## v0.3.7-beta

  **Notes**:
  - Adding windows builds back to automated process... will replace manually if they throw malicious defender warnings.
  - Adding playwright tests to all pr's against dev/beta/release branches.
    - These playwright tests should help keep release more reliably stable.

  **Bugfixes**:
  - closing with the default bar issue.
  - tar.gz archive creation issue

## v0.3.6-beta

  **New Features**:
  - Adds "externalUrl" server config https://github.com/gtsteffaniak/filebrowser/issues/272

  **Notes**:
  - All views modes to show header bar for sorting.
  - other small style changes

  **Bugfixes**:
  - select and info bug after sorting https://github.com/gtsteffaniak/filebrowser/issues/277
  - downloading from shares with public user
  - Ctrl and Shift key modifiers work on listing views as expected.
  - copy/move file/folder error and show errors https://github.com/gtsteffaniak/filebrowser/issues/278
  - file move/copy context fix.

## v0.3.5

  **New Features**:
  - More indexing configuration options possible. However consider waiting on using this feature, because I will soon have a full onboarding experience in the UI to manage sources instead.
    - added config file options "sources" in the server config.
    - can enable/disable indexing a specified list of directories/files
    - can enable/disable indexing hidden files
    - prepped for multiple sources (not supported yet!)
  - Theme and Branding support (see updates to [configuration wiki](https://github.com/gtsteffaniak/filebrowser/wiki/Configuration) on how to use)
  - Automatically expire shares https://github.com/gtsteffaniak/filebrowser/issues/208

  **Notes**:
  - MacOS application files (ending in ".app") were previously treated as folders, now they are treated as a single file.
  - No longer indexes "$RECYCLE.BIN" or "System Volume Information" directories.
  - Icon styling tweaked so all icons have a background.
  - Updated Login page styling.
  - Settings profile menu has been simplified, password changes happen in user management.
  - Improved windows compatibility and built on windows platform to fix false windows defender warning.
  - If no "root" location is provided in the server config, the default is the **current directory** (rather than `/srv` like before)

  **Bugfixes**:
  - Fixed setting share expiration time would not work due to type conversion error.
  - More safari fixes related to text-selection.
  - Sort by name value sorting ignores the extension, only sorts by name https://github.com/gtsteffaniak/filebrowser/issues/230
  - Fixed manual language selection issue.
  - Fixed exact date time issue.

New login page:

<img width="300" alt="image" src="https://github.com/user-attachments/assets/d3ed359e-a969-4f6a-9f72-94d2b68aba49" />


Example branding in sidebar:

<img width="500" alt="image2" src="https://github.com/user-attachments/assets/d8ee14ca-4495-4106-9d26-631a5937e134" />

Example user settings page:

<img width="500" alt="image3" src="https://github.com/user-attachments/assets/79757a11-669e-4597-bd3d-e41efd667a1e" />

## v0.3.4

  **Bugfixes**:
  - Safari right-click actions.
  - Some small image viewer behavior
  - Progressive webapp "install to homescreen" fix.

## v0.3.3

  **New Features**
  - Navigating remembers your previous scroll position when opening items and then navigating backwards.
  - New Icons with larger selection of file types
  - file "type" is shown on item info page.
  - added optional non-root "filebrowser" user for docker image. See https://github.com/gtsteffaniak/filebrowser/issues/251
  - File preview supports more file types:
    - images: jpg, bmp, gif, tiff, png, svg, heic, webp

  **Notes**:
  - The file "type" is now either "directory" or a specific mimetype such as "text/xml".
  - update safari styling

  **Bugfixes**:
  - Delete/move file/folders sometimes wouldn't work.
  - Possible fix for context menu not showing issue. See https://github.com/gtsteffaniak/filebrowser/issues/251
  - Fixed drag/drop not refreshing immediately to reflect changes.

## v0.3.2

  **New Features**
  - Mobile search has the same features as desktop.

  **Notes**:
  - Added compression. Helpful for browsing folders with a large number of items. Considering https://github.com/gtsteffaniak/filebrowser/issues/201 resolved, although future pagination support will still come.
  - Compressed download options limited to `.zip` and `.tar.gz`
  - right-click context menu stays in view.

  **Bugfixes**:
  - search result links when non-default baseUrl configured
  - frontend sort bug squashed https://github.com/gtsteffaniak/filebrowser/issues/230
  - bug which caused "noauth" method not to work after v0.3.0 routes update

## v0.3.1

  **New Features**
  - Adds Smart Indexing by default.

  **Notes**:
  - Optimized api request response times via improved caching and simplified actions.
  - User information persists more reliably.
  - Added [indexing doc](./docs/indexing.md) to explain the expectations around indexing and how it works.
  - The index should also use less RAM than it did in v0.3.0.

  **Bugfixes**:
  - Tweaked sorting by name, fixes case sensitive and numeric sorting. https://github.com/gtsteffaniak/filebrowser/issues/230
  - Fixed unnecessary authentication status checks each route change
  - Fix create file action issue.
  - some small javascript related issues.
  - Fixes pretty big bug viewing raw content in v0.3.0 (utf format message)

## v0.3.0

  This Release focuses on the API and making it more accessible for developers to access functions without the UI.

  **New Features**:
  - You can now long-live api tokens to interact with API from the user settings page.
    - These tokens have the same permissions as your user.
  - Helpful swagger page for API usage.
  - Some API's were refactored for friendlier API usage, moving some attributes to parameters and first looking for a api token, then using the stored cookie if none is found. This allows for all api requests from swagger page to work without a token.
  - Add file size to search preview! Should have been in last release... sorry!

  **Notes**:
  - Replaced backend http framework with go standard library.
  - Right-click Context menu can target the item that was right-clicked. To fully address https://github.com/gtsteffaniak/filebrowser/issues/214
  - adjusted settings menu for mobile, always shows all available cards rather than grayed out cards that need to be clicked.
  - longer and more cryptographically secure share links based on UUID rather than base64.

  **Bugfixes**:
  - Fixed ui bug with shares with password.
  - Fixes baseurl related bugs https://github.com/gtsteffaniak/filebrowser/pull/228 Thanks @SimLV
  - Fixed empty directory load issue.
  - Fixed image preview cutoff on mobile.
  - Fixed issue introduced in v0.2.10 where new files and folders were not showing up on ui
  - Fixed preview issue where preview would not load after viewing video files.
  - Fixed sorting issue where files were not sorted by name by default.
  - Fixed copy file prompt issue

## v0.2.10

  **New Features**:
  - Allows user creation command line arguments https://github.com/gtsteffaniak/filebrowser/issues/196
  - Folder sizes are always shown, leveraging the index. https://github.com/gtsteffaniak/filebrowser/issues/138
  - Searching files based on filesize is no longer slower.

  **Bugfixes**:
  - fixes file selection usage when in single-click mode https://github.com/gtsteffaniak/filebrowser/issues/214
  - Fixed displayed search context on root directory
  - Fixed issue searching "smaller than" actually returned files "larger than"

  **Notes**:
  - Memory usage from index is reduced by ~40%
  - Indexing time has increased 2x due to the extra processing time required to calculate directory sizes.
  - File size calculations use 1024 base vs previous 1000 base (matching windows explorer)

## v0.2.9

  This release focused on UI navigation experience. Improving keyboard navigation and adds right click context menu.

  **New Features**:
  - listing view items are middle-clickable on selected listing or when in single-click mode.
  - listing view items can be navigated via arrow keys.
  - listing view can jump to items using letters and number keys to cycle through files that start with that character.
  - You can use the enter key and backspace key to navigate backwards and forwards on selected items.
  - ctr-space will open/close the search (leaving ctr-f to browser default find prompt)
  - Added right-click context menu to replace the file selection prompt.

  **Bugfixes**:
  - Fixed drag to upload not working.
  - Fixed shared video link issues.
  - Fixed user edit bug related to other user.
  - Fixed password reset bug.
  - Fixed loading state getting stuck.

## v0.2.8

- **Feature**: New gallery view scaling options (closes [#141](https://github.com/gtsteffaniak/filebrowser/issues/141))
- **Change**: Refactored backend files functions
- **Change**: Improved UI response to filesystem changes
- **Change**: Added frontend tests for deployment integrity
- **Fix**: move/replace file prompt issue
- **Fix**: opening files from search
- **Fix**: Display count issue when hideDotFile is enabled.

## v0.2.7

 - **Change**: New sidebar style and behavior
 - **Change**: make search view and button behavior more consistent.
 - **Fix**: [upload file bug](https://github.com/gtsteffaniak/filebrowser/issues/153)
 - **Fix**: user lock out bug introduced in 0.2.6
 - **Fix**: many minor state related issues.

## v0.2.6

This change focuses on minimizing and simplifying build process.

- **Change**: Migrated to Vite / Vue 3
- **Change**: removed npm modules
  - replaced vuex with custom state management via src/store
  - replaced noty with simple card popup notifications
  - replaced moment with simple date formatter where needed
  - replaced vue-simple-progress with vue component
- **Feature**: improved error logging
  - backend errors show the root function that called them during the error
  - frontend errors print errors to console that fail try/catch
  - all frontend errors via popup notification & print to console as well
- **Fix**: Allow editing blank text based files in editor
- tweaked listing styles
- Feature: Allow disabling the index via configuration yaml

## v0.2.5

- Fix: delete user prompt works using native hovers.

## v0.2.4

- Feature: [create-folder-feature](https://github.com/gtsteffaniak/filebrowser/pull/105)
- Feature: [playable shared video](https://github.com/filebrowser/filebrowser/issues/2537)
- Feature: photos, videos, and audio get embedded preview on share instead of icon
- Fix: sharable link bug, now uses special publicUser
- Bump go version to 1.22
- In prep for vue3 migration, npm modules removed:
  - js-base64
  - pretty-bytes
  - whatwg-fetch
  - lodash.throttle
  - lodash.clonedeep

## v0.2.3

- Feature: token expiration time now configurable
- FIX: Hidden files are still directly accessible. (https://github.com/filebrowser/filebrowser/issues/2698)
- FIX: search/user context bug

## v0.2.2

- CHG: **Speed:** (0m57s) - Decreased by 78% compared to the previous release.
- CHG: **Memory Usage:** (41MB) - Reduced by 45% compared to the previous release.
- Feature: Now utilizes the index for file browser listings!
- FIX: Editor issues fixed on save and themes.

## v0.2.1

- Addressed issue #29 - Rules can now be configured and read from the configuration YAML.
- Addressed issue #28 - Allows disabling settings per user.
- Addressed issue #27 - Shortened download link for password-protected files.
- Addressed issue #26 - Enables dark mode per user and improves switching performance.
- Improved styling with more rounded corners and enhanced listing design.
- Enhanced search performance.
- Fixed authentication issues.
- Added compact view mode.
- Improved view mode configuration and behavior.
- Updated the configuration file to accept new settings.

## v0.2.0

- **Improved UI:**
  - Enhanced the cohesive and unified look.
  - Adjusted the header bar appearance and icon behavior.
- The shell feature has been deprecated.
  - Custom commands can be executed within the Docker container if needed.
- The JSON config file is no longer used.
  - All configurations are now performed via the advanced `config.yaml`.
  - The only allowed flag is specifying the config file.
- Removed old code for migrating database versions.
- Eliminated all unused `cmd` code.

## v0.1.4

- **Various UI fixes:**
  - Reintroduced the download button to the toolbar.
  - Added the upload button to the side menu.
  - Adjusted breadcrumb spacing.
  - Introduced a "compact" view option.
  - Fixed a slash issue with CSS right-to-left (RTL) logic.
- **Various backend improvements:**
  - Added session IDs to searches to prevent collisions.
  - Modified search behavior to include spaces in searches.
  - Prepared for full JSON configuration support.
- Made size-based searches work for both smaller and larger files.
- Modified search types not to appear in the search bar when used.

## v0.1.3

- Enhanced styling with improved colors, transparency, and blur effects.
- Hid the sidebar on desktop views.
- Simplified the navbar to include three buttons:
  - Open menu
  - Search
  - Toggle view
- Revised desktop search style and included additional search options.

## v0.1.2

- Updated the UI to better utilize search features:
  - Added more filter options.
  - Enhanced icons with colors.
  - Improved GUI styling.
- Improved search performance.
- **Index Changes:**
  - **Speed:** (0m32s) - Increased by 6% compared to the previous release.
  - **Memory Usage:** (93MB) - Increased by 3% compared to the previous release.

## v0.1.1

- Improved search functionality with indexing.
- **Index Changes (Baseline Results):**
  - **Speed:** (0m30s)
  - **Memory Usage:** (90MB)

## v0.1.0

- No changes from the original.

Forked from [filebrowser/filebrowser](https://github.com/filebrowser/filebrowser).

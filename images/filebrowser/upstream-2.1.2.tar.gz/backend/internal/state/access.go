package state

import (
	"fmt"
	"slices"

	"github.com/gtsteffaniak/filebrowser/backend/internal/database/access"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing/iteminfo"
)

// AccessPermitted reports whether username may access indexPath on sourcePath.
// When accessDb is not initialized, access is allowed.
func AccessPermitted(sourcePath string, indexPath utils.IndexPath, username string) bool {
	if accessDb == nil {
		return true
	}
	return accessDb.Permitted(sourcePath, indexPath, username)
}

func AllowUser(sourcePath string, indexPath utils.IndexPath, username string) error {
	return accessDb.AllowUser(sourcePath, indexPath, username)
}

func AllowGroup(sourcePath string, indexPath utils.IndexPath, groupname string) error {
	return accessDb.AllowGroup(sourcePath, indexPath, groupname)
}

func DenyUser(sourcePath string, indexPath utils.IndexPath, username string) error {
	return accessDb.DenyUser(sourcePath, indexPath, username)
}

func DenyGroup(sourcePath string, indexPath utils.IndexPath, groupname string) error {
	return accessDb.DenyGroup(sourcePath, indexPath, groupname)
}

func DenyAll(sourcePath string, indexPath utils.IndexPath) error {
	return accessDb.DenyAll(sourcePath, indexPath)
}

func GetFrontendRules(sourcePath string, indexPath utils.IndexPath) (access.FrontendAccessRule, bool) {
	return accessDb.GetFrontendRules(sourcePath, indexPath)
}

func GetAllRules(sourcePath string) (map[string]access.FrontendAccessRule, error) {
	return accessDb.GetAllRules(sourcePath)
}

func GetRulesForUser(sourcePath, username string) map[string]access.FrontendAccessRule {
	return accessDb.GetRulesForUser(sourcePath, username)
}

func GetRulesForGroup(sourcePath, groupname string) map[string]access.FrontendAccessRule {
	return accessDb.GetRulesForGroup(sourcePath, groupname)
}

func RemoveUserCascade(sourcePath string, indexPath utils.IndexPath, username string, allow bool) (int, error) {
	return accessDb.RemoveUserCascade(sourcePath, indexPath, username, allow)
}

func RemoveGroupCascade(sourcePath string, indexPath utils.IndexPath, groupname string, allow bool) (int, error) {
	return accessDb.RemoveGroupCascade(sourcePath, indexPath, groupname, allow)
}

func RemoveAllowUser(sourcePath string, indexPath utils.IndexPath, username string) (bool, error) {
	return accessDb.RemoveAllowUser(sourcePath, indexPath, username)
}

func RemoveAllowGroup(sourcePath string, indexPath utils.IndexPath, groupname string) (bool, error) {
	return accessDb.RemoveAllowGroup(sourcePath, indexPath, groupname)
}

func RemoveDenyUser(sourcePath string, indexPath utils.IndexPath, username string) (bool, error) {
	return accessDb.RemoveDenyUser(sourcePath, indexPath, username)
}

func RemoveDenyGroup(sourcePath string, indexPath utils.IndexPath, groupname string) (bool, error) {
	return accessDb.RemoveDenyGroup(sourcePath, indexPath, groupname)
}

func RemoveDenyAll(sourcePath string, indexPath utils.IndexPath) (bool, error) {
	return accessDb.RemoveDenyAll(sourcePath, indexPath)
}

func GetUserGroups(username string) []string {
	return accessDb.GetUserGroups(username)
}

func GetAllGroups() []string {
	return accessDb.GetAllGroups()
}

func AddUserToGroup(group, username string) error {
	return accessDb.AddUserToGroup(group, username)
}

func RemoveUserFromGroup(group, username string) error {
	return accessDb.RemoveUserFromGroup(group, username)
}

func SyncUserGroups(username string, newGroups []string) error {
	return accessDb.SyncUserGroups(username, newGroups)
}

// GroupExists reports whether a group name is already registered.
func GroupExists(groupname string) bool {
	if accessDb == nil {
		return false
	}
	return slices.Contains(accessDb.GetAllGroups(), groupname)
}

// RemoveUserFromAllGroups removes a username from every group's member list.
func RemoveUserFromAllGroups(username string) error {
	if accessDb == nil {
		return nil
	}
	return accessDb.RemoveUserFromAllGroups(username)
}

// RenameUserInGroups replaces one username with another in all group member lists.
func RenameUserInGroups(oldName, newName string) error {
	if accessDb == nil {
		return nil
	}
	return accessDb.RenameUserInGroups(oldName, newName)
}

// RenameUserInRules replaces one username with another in all path access allow/deny lists.
func RenameUserInRules(oldName, newName string) error {
	if accessDb == nil {
		return nil
	}
	return accessDb.RenameUserInRules(oldName, newName)
}

// RemoveAllRulesForUser removes a username from every path access allow and deny list.
func RemoveAllRulesForUser(username string) error {
	if accessDb == nil {
		return nil
	}
	return accessDb.RemoveAllRulesForUser(username)
}

// SetAccessSQLStoreForTest replaces the SQL persister used by access control (tests only).
func SetAccessSQLStoreForTest(store access.SQLPersister) {
	if accessDb != nil {
		accessDb.SetSQLStore(store)
	}
}

func UpdateRulePath(sourcePath string, oldPath, newPath utils.IndexPath) error {
	return accessDb.UpdateRulePath(sourcePath, oldPath, newPath)
}

func RemoveRuleByPathKey(sourcePath, pathKey string) {
	accessDb.RemoveRuleByPathKey(sourcePath, pathKey)
}

func AddApiToken(tokenString string, userID uint64) error {
	if accessDb == nil {
		return fmt.Errorf("access storage not available")
	}
	return accessDb.AddApiToken(tokenString, userID)
}

// BearerTokenGrace re-exports access.BearerTokenGrace for callers that should
// not depend on the access package directly.
const BearerTokenGrace = access.BearerTokenGrace

// RegisterSessionToken maps a session bearer JWT to its owner user id.
func RegisterSessionToken(tokenString string, userID uint64) error {
	if accessDb == nil {
		return fmt.Errorf("access storage not available")
	}
	return accessDb.AddSessionToken(tokenString, userID)
}

// RetireSessionToken schedules a rotated session token for revocation after a
// short grace window so in-flight requests carrying the old cookie still work.
func RetireSessionToken(tokenString string) error {
	if accessDb == nil {
		return fmt.Errorf("access storage not available")
	}
	return accessDb.RetireToken(tokenString)
}

// HashedTokenOwner returns the owner id and session type for a registered bearer
// token hash. ok is false when the hash has no mapping (unknown or already revoked).
func HashedTokenOwner(tokenString string) (userID uint64, isSession bool, ok bool) {
	if accessDb == nil {
		return 0, false, false
	}
	info, found := accessDb.GetHashedTokenInfo(tokenString)
	if !found {
		return 0, false, false
	}
	return info.UserID, info.IsSession, true
}

func RemoveApiToken(tokenString string) error {
	return accessDb.RemoveApiToken(tokenString)
}

func IsTokenRevoked(token string) bool {
	if accessDb == nil {
		return false
	}
	return accessDb.IsTokenRevoked(token)
}

func RevokeToken(token string) error {
	return accessDb.RevokeToken(token)
}

// CheckChildItemAccess filters directory listings using in-memory access rules.
func CheckChildItemAccess(response *iteminfo.FileInfo, idx *indexing.Index, username string) error {
	if accessDb == nil {
		return nil
	}
	return accessDb.CheckChildItemAccess(response, idx, username)
}

// UpdateAccessRulesOnMove rewrites access rule paths when a resource moves within one source.
func UpdateAccessRulesOnMove(sourcePath string, oldPath, newPath utils.IndexPath) (int, error) {
	if accessDb == nil {
		return 0, nil
	}
	return accessDb.UpdateRules(sourcePath, oldPath, newPath)
}

// GetGroupMembers returns every group with its sorted member usernames.
func GetGroupMembers() map[string][]string {
	return accessDb.GetGroupMembers()
}

// SetGroupMembers creates the group if needed and replaces its member list.
func SetGroupMembers(group string, usernames []string) error {
	return accessDb.SetGroupMembers(group, usernames)
}

// DeleteGroup removes a group and every access rule entry that references it.
func DeleteGroup(group string) error {
	return accessDb.DeleteGroup(group)
}

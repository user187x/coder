package state

import (
	"fmt"
	"reflect"
	"strings"

	"github.com/google/uuid"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/quota"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/share"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
	"github.com/gtsteffaniak/filebrowser/backend/internal/toolaccess"
	"github.com/gtsteffaniak/filebrowser/backend/internal/usersidebar"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/go-logger/logger"
)

// User operations

// copyBackendSourcePermissions returns a shallow copy of the per-source permissions map.
func copyBackendSourcePermissions(m map[string]users.SourceFilePermissions) map[string]users.SourceFilePermissions {
	if m == nil {
		return nil
	}
	out := make(map[string]users.SourceFilePermissions, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

// copyUserSlices deep-copies user slice/map fields into userCopy.
func copyUserSlices(userCopy *users.User, user *users.User) {
	if user.BackendScopes != nil {
		userCopy.BackendScopes = make([]users.BackendScope, len(user.BackendScopes))
		copy(userCopy.BackendScopes, user.BackendScopes)
	}
	if user.BackendSourcePermissions != nil {
		userCopy.BackendSourcePermissions = copyBackendSourcePermissions(user.BackendSourcePermissions)
	}
	if user.Tokens != nil {
		userCopy.Tokens = make(map[string]users.AuthToken, len(user.Tokens))
		for k, v := range user.Tokens {
			userCopy.Tokens[k] = v
		}
	}
	if user.SidebarLinks != nil {
		userCopy.SidebarLinks = make([]users.SidebarLink, len(user.SidebarLinks))
		copy(userCopy.SidebarLinks, user.SidebarLinks)
	}
	if user.FrontendScopes != nil {
		userCopy.FrontendScopes = make([]users.FrontendScope, len(user.FrontendScopes))
		copy(userCopy.FrontendScopes, user.FrontendScopes)
	}
	if user.SourcePermissions != nil {
		userCopy.SourcePermissions = copyBackendSourcePermissions(user.SourcePermissions)
	}
	if user.ApiKeys != nil {
		userCopy.ApiKeys = make(map[string]users.AuthToken, len(user.ApiKeys))
		for k, v := range user.ApiKeys {
			userCopy.ApiKeys[k] = v
		}
	}
	if user.PasskeyCredentials != nil {
		userCopy.PasskeyCredentials = copyWebAuthnCredentials(user.PasskeyCredentials)
	}
	if user.PinnedItems != nil {
		userCopy.PinnedItems = copyPinnedItems(user.PinnedItems)
	}
}

func copyWebAuthnCredentials(in []users.WebAuthnCredential) []users.WebAuthnCredential {
	out := make([]users.WebAuthnCredential, len(in))
	for i, c := range in {
		out[i] = c
		if c.Transport != nil {
			out[i].Transport = append([]string(nil), c.Transport...)
		}
	}
	return out
}

func copyPinnedItems(in users.PinnedItems) users.PinnedItems {
	if in == nil {
		return nil
	}
	out := make(users.PinnedItems, len(in))
	for srcPath, dirs := range in {
		dirCopy := make(map[string][]string, len(dirs))
		for dirPath, names := range dirs {
			dirCopy[dirPath] = append([]string(nil), names...)
		}
		out[srcPath] = dirCopy
	}
	return out
}

// GetUserByID retrieves a user by stable numeric id (admin APIs, hashed_tokens lookup).
func GetUserByID(id uint64) (users.User, error) {
	if id == 0 {
		return users.User{}, errors.ErrNotExist
	}
	usersMux.RLock()
	defer usersMux.RUnlock()

	if cached, ok := getCachedUserByID(id); ok {
		return *cached, nil
	}

	user, err := loadUserByIDFromDB(id)
	if err != nil {
		return users.User{}, err
	}
	putUserInCache(user)
	userCopy := *user
	copyUserSlices(&userCopy, user)
	return userCopy, nil
}

// GetUserByUsername returns a user by username (30m cache, SQLite on miss).
func GetUserByUsername(username string) (users.User, error) {
	usersMux.RLock()
	defer usersMux.RUnlock()

	if cached, ok := getCachedUserByUsername(username); ok {
		return *cached, nil
	}

	user, err := loadUserByUsernameFromDB(username)
	if err != nil {
		return users.User{}, err
	}
	putUserInCache(user)
	userCopy := *user
	copyUserSlices(&userCopy, user)
	return userCopy, nil
}

// UserIDForUsername returns the stable id for a login name (for id-keyed user storage).
func UserIDForUsername(username string) (uint64, error) {
	u, err := GetUserByUsername(username)
	if err != nil {
		return 0, err
	}
	return u.ID, nil
}

// GetAllUsers returns all users from SQLite (not a long-lived memory map).
func GetAllUsers() ([]users.User, error) {
	usersMux.RLock()
	defer usersMux.RUnlock()

	usersList, err := sqlDb.ListUsers()
	if err != nil {
		return nil, err
	}
	out := make([]users.User, 0, len(usersList))
	for _, user := range usersList {
		if user == nil {
			continue
		}
		userCopy := *user
		copyUserSlices(&userCopy, user)
		out = append(out, userCopy)
	}
	return out, nil
}

// UserForShareOwner resolves the user who owns a share link.
func UserForShareOwner(link share.Share) (users.User, error) {
	if link.UserID == 0 {
		return users.User{}, errors.ErrNotExist
	}
	return GetUserByID(link.UserID)
}

// CreateUser creates a new user with plaintext password.
//
// Scope model: only BackendScopes are persisted (SQL user_data). JSON "scopes" on the API unmarshals into
// FrontendScopes; state converts those to BackendScopes via APIScopesToBackend, clears FrontendScopes, then
// may apply default-enabled sources. In-memory/cache users always keep FrontendScopes nil; GET handlers use
// PrepForFrontend to repopulate FrontendScopes from BackendScopes for responses.
func CreateUser(user *users.User, plaintextPassword string) error {
	if err := users.ValidateUsername(user.Username); err != nil {
		return err
	}
	if _, err := GetUserByUsername(user.Username); err == nil {
		return fmt.Errorf("user with username %s already exists", user.Username)
	} else if err != errors.ErrNotExist {
		return err
	}
	// Hash password if provided
	if plaintextPassword != "" {
		if err := settings.ValidatePasswordPolicy(plaintextPassword); err != nil {
			return err
		}
		hashedPassword, err := utils.HashPwd(plaintextPassword)
		if err != nil {
			return fmt.Errorf("failed to hash password: %w", err)
		}
		user.Password = hashedPassword
	}

	// Incoming API "scopes" → BackendScopes; FrontendScopes must not remain on the persisted user.
	if err := applyScopesFromAPI(user); err != nil {
		return err
	}

	// If still no BackendScopes (omitted or invalid API names), same defaults as ApplyUserDefaults.
	preserveRequirePasswordChange := user.RequirePasswordChange
	applyUserSettingsDefaults(user)
	if preserveRequirePasswordChange {
		user.RequirePasswordChange = true
	}
	defaults := EffectiveUserDefaults()
	enforced := EffectiveEnforced()
	settings.ApplyEnforcedDefaultsFrom(user, defaults, enforced)
	settings.ApplyEnforcedSourcePermissionsFrom(user, GetSourceAccessDefaults(), GetEnforcedSourcePermissions())

	users.SyncBackendSourcePermissionsMap(user)

	applySidebarLinkDefaults(user)

	applyToolAccessDefaults(user)

	if links, changed := usersidebar.PrepareSidebarLinksForPersist(user.SidebarLinks, user.BackendScopes); changed {
		user.SidebarLinks = links
	}

	usersMux.Lock()
	defer usersMux.Unlock()

	if user.ID == 0 {
		nid, genErr := utils.RandomUint64ID()
		if genErr != nil {
			return fmt.Errorf("allocate user id: %w", genErr)
		}
		user.ID = nid
	}

	if err := sqlDb.CreateUser(user); err != nil {
		return err
	}

	putUserInCache(user)

	return nil
}

func validatePatchFieldList(fields ...string) error {
	if len(fields) == 0 {
		return fmt.Errorf("which must list at least one JSON field name to update")
	}
	for _, jsonFieldName := range fields {
		jsonFieldName = strings.TrimSpace(jsonFieldName)
		if jsonFieldName == "" {
			return fmt.Errorf("which must not contain empty field names")
		}
		if strings.EqualFold(jsonFieldName, "all") {
			return fmt.Errorf("invalid which field %q", jsonFieldName)
		}
	}
	return nil
}

// FieldListIncludes reports whether fields contains name, case-insensitively.
func FieldListIncludes(fields []string, name string) bool {
	for _, f := range fields {
		if strings.EqualFold(strings.TrimSpace(f), name) {
			return true
		}
	}
	return false
}

// UpdateUser patches an existing user with write-through to SQL.
// fields must list JSON tag names (e.g. "showFirstLogin", "scopes", "permissions").
// If plaintextPassword is provided (non-empty), it will be hashed when "password" is in fields.
func UpdateUser(user *users.User, plaintextPassword string, fields ...string) error {
	if err := validatePatchFieldList(fields...); err != nil {
		return err
	}

	sourceDefaults := GetSourceAccessDefaults()
	sourceEnforced := GetEnforcedSourcePermissions()

	usersMux.Lock()
	defer usersMux.Unlock()

	storedSnapshot, err := loadExistingUserLocked(user)
	if err != nil {
		return fmt.Errorf("user %s not found in cache", user.Username)
	}
	existingUser := cloneUserPtr(storedSnapshot)

	existingVal := reflect.ValueOf(existingUser).Elem()
	newVal := reflect.ValueOf(user).Elem()

	for _, jsonFieldName := range fields {
		jsonFieldName = strings.TrimSpace(jsonFieldName)
		if strings.EqualFold(jsonFieldName, "password") {
			if plaintextPassword == "" {
				return fmt.Errorf("password field requires a non-empty plaintext password")
			}
			if err := settings.ValidatePasswordPolicy(plaintextPassword); err != nil {
				return err
			}
			hashedPassword, hashErr := utils.HashPwd(plaintextPassword)
			if hashErr != nil {
				return fmt.Errorf("failed to hash password: %w", hashErr)
			}
			existingUser.Password = hashedPassword
			continue
		}

		structFieldName := findFieldByJSONTag(reflect.TypeOf(user).Elem(), jsonFieldName)
		if structFieldName == "" {
			structFieldName = jsonFieldName
		}

		existingField := existingVal.FieldByName(structFieldName)
		newField := newVal.FieldByName(structFieldName)
		if !existingField.IsValid() || !existingField.CanSet() || !newField.IsValid() {
			return fmt.Errorf("unknown or read-only user field %q", jsonFieldName)
		}
		existingField.Set(newField)
	}

	if FieldListIncludes(fields, "otpEnabled") && !existingUser.OtpEnabled {
		existingUser.TOTPSecret = ""
		existingUser.TOTPNonce = ""
	}

	if fieldListRequiresScopeConversion(fields) {
		if err := applyScopesFromAPI(existingUser); err != nil {
			return err
		}
	}

	if sidebarFieldsPatched(fields) {
		var links []users.SidebarLink
		var changed bool
		if fieldListRequiresScopeConversion(fields) {
			links, changed = usersidebar.PrepareSidebarLinksForPersist(existingUser.SidebarLinks, existingUser.BackendScopes)
		} else {
			links, changed = usersidebar.NormalizeSidebarLinks(existingUser.SidebarLinks)
		}
		if changed {
			existingUser.SidebarLinks = links
		}
		if enforcedErr := usersidebar.ValidateEnforcedSidebarLinks(existingUser.SidebarLinks, existingUser.BackendScopes, EffectiveSidebarLinkDefaults(), existingUser.Permissions.Admin); enforcedErr != nil {
			return enforcedErr
		}
	}

	if FieldListIncludes(fields, "toolAccess") {
		if enforcedErr := toolaccess.ValidateEnforcedToolAccess(existingUser, EffectiveToolAccessDefaults()); enforcedErr != nil {
			return enforcedErr
		}
	}

	return commitUserUpdate(existingUser, storedSnapshot, sourceDefaults, sourceEnforced)
}

func commitUserUpdate(existingUser, storedSnapshot *users.User, sourceDefaults users.SourceFilePermissions, sourceEnforced settings.SourceFilePermissionsEnforcement) error {
	oldUsername := storedSnapshot.Username
	oldUserID := storedSnapshot.ID

	users.SyncBackendSourcePermissionsMap(existingUser)
	existingUser.FrontendScopes = nil
	existingUser.SourcePermissions = nil

	defaults := EffectiveUserDefaults()
	enforced := EffectiveEnforced()
	if err := settings.ValidateUserAgainstEnforcedDefaults(existingUser, defaults, enforced); err != nil {
		return err
	}
	if err := settings.ValidateUserScopePermissionsAgainstEnforced(existingUser, sourceDefaults, sourceEnforced); err != nil {
		return err
	}
	if err := usersidebar.ValidateEnforcedSidebarLinks(existingUser.SidebarLinks, existingUser.BackendScopes, EffectiveSidebarLinkDefaults(), existingUser.Permissions.Admin); err != nil {
		return err
	}
	toolaccess.MergeEnforcedToolAccess(existingUser, EffectiveToolAccessDefaults())
	if err := toolaccess.ValidateEnforcedToolAccess(existingUser, EffectiveToolAccessDefaults()); err != nil {
		return err
	}

	for _, bs := range existingUser.BackendScopes {
		if bs.Quota == nil || bs.Quota.LimitBytes <= 0 {
			continue
		}
		meter := bs.Quota.Meter
		if meter == "" {
			meter = quota.MeterIndexScope
		}
		sourceName := ""
		if src, ok := settings.Config.Server.SourceMap[bs.Path]; ok {
			sourceName = src.Name
		}
		if sourceName != "" {
			if err := quota.ValidateConfiguredMeter(sourceName, meter); err != nil {
				return fmt.Errorf("scope quota: %w", err)
			}
		}
	}

	for _, bs := range existingUser.BackendScopes {
		if bs.Quota != nil && bs.Quota.LimitBytes > 0 && bs.Quota.ID == "" {
			bs.Quota.ID = uuid.New().String()
		}
	}

	removedQuotaIDs := removedScopeQuotaIDs(storedSnapshot, existingUser)

	if oldUsername != existingUser.Username {
		if err := sqlDb.UpdateUserUsername(oldUsername, existingUser); err != nil {
			return err
		}
		if accessDb != nil {
			if err := renameUserInAccess(oldUsername, existingUser); err != nil {
				return err
			}
		}
		if oldUserID != 0 && oldUserID != existingUser.ID {
			userRecordCache.Delete(userCacheKeyID(oldUserID))
		}
		userRecordCache.Delete(userCacheKeyName(oldUsername))
	} else if err := sqlDb.UpdateUser(existingUser); err != nil {
		return err
	}

	for _, id := range removedQuotaIDs {
		if err := OnUserScopeQuotaRemoved(id); err != nil {
			return err
		}
	}
	for _, bs := range existingUser.BackendScopes {
		if err := OnUserScopeQuotaChanged(bs.Quota); err != nil {
			return err
		}
	}

	putUserInCache(existingUser)
	return nil
}

// renameUserInAccess renames the user in group memberships and path rules after the SQL rename
// has been written. On failure every earlier step is reverted (keeping the other updated fields)
// so the stores never disagree about which username owns the memberships.
func renameUserInAccess(oldUsername string, updated *users.User) error {
	revertSQL := func() {
		reverted := *updated
		reverted.Username = oldUsername
		if err := sqlDb.UpdateUser(&reverted); err != nil {
			logger.Errorf("failed to revert username %q to %q after rename failure: %v", updated.Username, oldUsername, err)
		}
	}
	if err := accessDb.RenameUserInGroups(oldUsername, updated.Username); err != nil {
		revertSQL()
		return fmt.Errorf("failed to rename user in groups: %w", err)
	}
	if err := accessDb.RenameUserInRules(oldUsername, updated.Username); err != nil {
		if revErr := accessDb.RenameUserInGroups(updated.Username, oldUsername); revErr != nil {
			logger.Errorf("failed to revert group memberships for %q after rename failure: %v", oldUsername, revErr)
		}
		revertSQL()
		return fmt.Errorf("failed to rename user in access rules: %w", err)
	}
	return nil
}

func removedScopeQuotaIDs(before, after *users.User) []string {
	oldByPath := map[string]string{}
	for _, bs := range before.BackendScopes {
		if bs.Quota != nil && bs.Quota.LimitBytes > 0 && bs.Quota.ID != "" {
			oldByPath[bs.Path] = bs.Quota.ID
		}
	}
	newByPath := map[string]string{}
	for _, bs := range after.BackendScopes {
		if bs.Quota != nil && bs.Quota.LimitBytes > 0 && bs.Quota.ID != "" {
			newByPath[bs.Path] = bs.Quota.ID
		}
	}
	var removed []string
	for path, id := range oldByPath {
		if newByPath[path] != id {
			removed = append(removed, id)
		}
	}
	return removed
}

// fieldListPatchesBackendScopes reports whether fields include persisted scope paths (JSON tag
// "backendScopes", case-insensitive; matches struct name BackendScopes as well).
func fieldListPatchesBackendScopes(fields []string) bool {
	for _, f := range fields {
		f = strings.TrimSpace(f)
		if strings.EqualFold(f, "backendScopes") {
			return true
		}
	}
	return false
}

func fieldListPatchesAPISourcePermissions(fields []string) bool {
	for _, f := range fields {
		f = strings.TrimSpace(f)
		if strings.EqualFold(f, "sourcePermissions") || strings.EqualFold(f, "scopes") {
			return true
		}
	}
	return false
}

func fieldListRequiresScopeConversion(fields []string) bool {
	return fieldListPatchesBackendScopes(fields) || fieldListPatchesAPISourcePermissions(fields)
}

func sidebarFieldsPatched(fields []string) bool {
	return FieldListIncludes(fields, "sidebarLinks") || fieldListRequiresScopeConversion(fields)
}

// applyScopesFromAPI converts API scopes (with nested permissions) into BackendScopes.
// Legacy sourcePermissions map is merged into scopes when permissions are omitted per scope.
func applyScopesFromAPI(user *users.User) error {
	if len(user.SourcePermissions) > 0 && len(user.FrontendScopes) > 0 {
		byName := make(map[string]users.SourceFilePermissions, len(user.SourcePermissions))
		for name, perms := range user.SourcePermissions {
			byName[name] = perms
		}
		for i, scope := range user.FrontendScopes {
			if scope.Permissions != nil {
				continue
			}
			if perms, ok := byName[scope.Name]; ok {
				p := perms
				user.FrontendScopes[i].Permissions = &p
			}
		}
	}
	defaults := settings.DefaultSourceFilePermissions()
	if user.Permissions.Admin {
		defaults = settings.AdminSourceFilePermissions()
	}
	for i, scope := range user.FrontendScopes {
		if scope.Permissions != nil {
			continue
		}
		p := defaults
		user.FrontendScopes[i].Permissions = &p
	}
	if len(user.FrontendScopes) > 0 {
		backend, convErr := users.APIScopesToBackend(user.FrontendScopes)
		if convErr != nil {
			return convErr
		}
		user.BackendScopes = backend
		user.DeclinedDefaultSources = settings.ComputeDeclinedDefaultSources(user.BackendScopes)
	} else if len(user.SourcePermissions) > 0 {
		backendPerms, convErr := users.APISourcePermsToBackend(user.SourcePermissions)
		if convErr != nil {
			return convErr
		}
		for i, scope := range user.BackendScopes {
			if perms, ok := backendPerms[scope.Path]; ok {
				user.BackendScopes[i].Permissions = perms
			}
		}
	}
	user.FrontendScopes = nil
	user.SourcePermissions = nil
	return nil
}

// findFieldByJSONTag recursively searches for a struct field by its JSON tag name
// Handles embedded structs by searching through all levels
func findFieldByJSONTag(t reflect.Type, jsonTag string) string {
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)

		// Check if this field's JSON tag matches
		jsonTagValue := field.Tag.Get("json")
		if jsonTagValue != "" {
			// Parse tag (might be "fieldName,omitempty")
			tagName := strings.Split(jsonTagValue, ",")[0]
			if tagName == jsonTag {
				return field.Name
			}
		}

		// If this is an embedded struct (Anonymous field), search recursively
		if field.Anonymous && field.Type.Kind() == reflect.Struct {
			if nestedFieldName := findFieldByJSONTag(field.Type, jsonTag); nestedFieldName != "" {
				// For embedded structs, we can access the field directly by name
				// because Go promotes embedded struct fields
				return nestedFieldName
			}
		}
	}

	return ""
}

// DeleteUser deletes a user by stable numeric id (non-zero).
func DeleteUser(id uint64) error {
	if id == 0 {
		return fmt.Errorf("user not found in state")
	}
	usersMux.Lock()
	defer usersMux.Unlock()

	user, err := loadExistingUserLocked(&users.User{ID: id})
	if err != nil {
		return fmt.Errorf("user not found in state")
	}

	if err := removeUserAccess(user.Username); err != nil {
		return err
	}
	if err := sqlDb.DeleteUserByID(id); err != nil {
		return err
	}

	deleteUserFromCache(user)

	if accessDb != nil {
		_ = accessDb.RemoveHashedTokensForUser(id)
	}

	return nil
}

// DeleteUserByUsername deletes a user by username
func DeleteUserByUsername(username string) error {
	usersMux.Lock()
	defer usersMux.Unlock()

	user, err := loadExistingUserLocked(&users.User{FrontendUser: users.FrontendUser{Username: username}})
	if err != nil {
		return fmt.Errorf("user not found in state")
	}

	uid := user.ID
	if err := removeUserAccess(username); err != nil {
		return err
	}
	if err := sqlDb.DeleteUserByUsername(username); err != nil {
		return err
	}

	deleteUserFromCache(user)

	if accessDb != nil && uid != 0 {
		_ = accessDb.RemoveHashedTokensForUser(uid)
	}
	return nil
}

// removeUserAccess strips a username from group memberships and path rules before the user row is
// deleted. Each step rolls itself back on failure and any error aborts the delete, so a reused
// username can never inherit leftovers. The failure mode is fail-safe: if the later SQL delete
// fails the user only loses access, and a retry is idempotent.
func removeUserAccess(username string) error {
	if accessDb == nil {
		return nil
	}
	if err := accessDb.RemoveUserFromAllGroups(username); err != nil {
		return fmt.Errorf("failed to remove user from groups: %w", err)
	}
	if err := accessDb.RemoveAllRulesForUser(username); err != nil {
		return fmt.Errorf("failed to remove user from access rules: %w", err)
	}
	return nil
}

// TokenNameForRawToken returns the persisted token name when rawToken matches a stored API key.
func TokenNameForRawToken(user *users.User, rawToken string) (string, bool) {
	if user == nil {
		return "", false
	}
	usersMux.RLock()
	defer usersMux.RUnlock()
	return users.TokenNameByRaw(user.Tokens, rawToken)
}

// AddUserToken adds an API token to a user
func AddUserToken(ownerUsername string, token users.AuthToken) error {
	usersMux.Lock()
	defer usersMux.Unlock()

	user, err := loadExistingUserLocked(&users.User{FrontendUser: users.FrontendUser{Username: ownerUsername}})
	if err != nil {
		return fmt.Errorf("user not found in state")
	}

	// Check if token already exists
	if user.Tokens != nil {
		if _, tokenExists := user.Tokens[token.Name]; tokenExists {
			return fmt.Errorf("token with name %s already exists for user", token.Name)
		}
	}

	// Prepare the update
	if user.Tokens == nil {
		user.Tokens = make(map[string]users.AuthToken)
	}
	users.StoreToken(user.Tokens, token)

	if err := sqlDb.UpdateUser(user); err != nil {
		return err
	}

	putUserInCache(user)

	return nil
}

// DeleteUserToken removes an API token from a user
func DeleteUserToken(ownerUsername string, tokenName string) error {
	usersMux.Lock()
	defer usersMux.Unlock()

	user, err := loadExistingUserLocked(&users.User{FrontendUser: users.FrontendUser{Username: ownerUsername}})
	if err != nil {
		return fmt.Errorf("user not found in state")
	}

	// Check if token exists
	if user.Tokens == nil {
		return fmt.Errorf("user has no tokens")
	}
	if _, tokenExists := user.Tokens[tokenName]; !tokenExists {
		return fmt.Errorf("token with name %s not found for user", tokenName)
	}

	users.RemoveTokenByName(user.Tokens, tokenName)

	if err := sqlDb.UpdateUser(user); err != nil {
		return err
	}

	putUserInCache(user)

	return nil
}

package fileutils

import (
	"bytes"
	"io"
	"os"
	"path/filepath"
	"syscall"
	"testing"
	"time"
)

type copyFileRangeRejectingWriter struct {
	bytes.Buffer
	readFromCalls int
}

func (w *copyFileRangeRejectingWriter) ReadFrom(r io.Reader) (int64, error) {
	w.readFromCalls++
	buf := make([]byte, 4)
	n, err := r.Read(buf)
	if n > 0 {
		_, _ = w.Write(buf[:n])
	}
	if err != nil {
		return int64(n), err
	}
	return int64(n), syscall.EBADF
}

func TestUnixModeToFileMode_setgid(t *testing.T) {
	m := unixModeToFileMode(0o2770)
	if got := m.Perm(); got != 0o770 {
		t.Fatalf("Perm() = %#o, want 0770", got)
	}
	if m&os.ModeSetgid == 0 {
		t.Fatal("expected ModeSetgid")
	}
	if m&os.ModeSetuid != 0 || m&os.ModeSticky != 0 {
		t.Fatalf("unexpected special bits: %#o", m)
	}
}

func TestCommonPrefix(t *testing.T) {
	testCases := map[string]struct {
		paths []string
		want  string
	}{
		"same lvl": {
			paths: []string{
				"/home/user/file1",
				"/home/user/file2",
			},
			want: "/home/user",
		},
		"sub folder": {
			paths: []string{
				"/home/user/folder",
				"/home/user/folder/file",
			},
			want: "/home/user/folder",
		},
		"relative path": {
			paths: []string{
				"/home/user/folder",
				"/home/user/folder/../folder2",
			},
			want: "/home/user",
		},
		"no common path": {
			paths: []string{
				"/home/user/folder",
				"/etc/file",
			},
			want: "",
		},
	}
	for name, tt := range testCases {
		t.Run(name, func(t *testing.T) {
			if got := CommonPrefix('/', tt.paths...); got != tt.want {
				t.Errorf("CommonPrefix() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCopyFilePreservesModTime(t *testing.T) {
	fileTime := time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC)
	dirTime := time.Date(2026, 6, 7, 8, 9, 0, 0, time.UTC)
	testCases := map[string]struct {
		isDir     bool
		checkPath map[string]time.Time
	}{
		"file":      {checkPath: map[string]time.Time{"": fileTime}},
		"directory": {isDir: true, checkPath: map[string]time.Time{"": dirTime, "nested.txt": fileTime}},
	}
	for name, tt := range testCases {
		t.Run(name, func(t *testing.T) {
			src := t.TempDir()
			dst := filepath.Join(t.TempDir(), "dst")
			srcPath := src
			if tt.isDir {
				nested := filepath.Join(src, "nested.txt")
				if err := os.WriteFile(nested, []byte("hi"), 0644); err != nil {
					t.Fatal(err)
				}
				if err := os.Chtimes(nested, fileTime, fileTime); err != nil {
					t.Fatal(err)
				}
				if err := os.Chtimes(src, dirTime, dirTime); err != nil {
					t.Fatal(err)
				}
			} else {
				srcPath = filepath.Join(src, "file.txt")
				if err := os.WriteFile(srcPath, []byte("hi"), 0644); err != nil {
					t.Fatal(err)
				}
				if err := os.Chtimes(srcPath, fileTime, fileTime); err != nil {
					t.Fatal(err)
				}
			}
			if err := CopyFile(srcPath, dst); err != nil {
				t.Fatal(err)
			}
			for rel, want := range tt.checkPath {
				p := dst
				if rel != "" {
					p = filepath.Join(dst, rel)
				}
				got, err := os.Stat(p)
				if err != nil {
					t.Fatal(err)
				}
				if !got.ModTime().Equal(want) {
					t.Errorf("%s: got mtime = %v, want %v", p, got.ModTime(), want)
				}
			}
		})
	}
}

// moveViaCrossDeviceFallback mirrors MoveFile's EXDEV fallback (CopyFile + RemoveAll).
func moveViaCrossDeviceFallback(t *testing.T, src, dst string) {
	t.Helper()
	if err := CopyFile(src, dst); err != nil {
		t.Fatal(err)
	}
	if err := os.RemoveAll(src); err != nil {
		t.Fatal(err)
	}
}

func TestMoveFileDoesNotFallbackOnNonCrossDeviceError(t *testing.T) {
	srcDir := t.TempDir()
	src := filepath.Join(srcDir, "file.txt")
	if err := os.WriteFile(src, []byte("data"), 0o644); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(srcDir, "existing-dir")
	if err := os.Mkdir(dst, 0o755); err != nil {
		t.Fatal(err)
	}

	err := MoveFile(src, dst)
	if err == nil {
		t.Fatal("expected rename error")
	}
	if _, statErr := os.Stat(src); statErr != nil {
		t.Fatalf("source file should remain after rename failure: %v", statErr)
	}
	entries, err := os.ReadDir(dst)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 0 {
		t.Fatalf("destination directory should be unchanged, got %d entries", len(entries))
	}
}

func TestMoveFileCrossDevicePreservesFilePermissions(t *testing.T) {
	srcDir := t.TempDir()
	dstDir := t.TempDir()
	src := filepath.Join(srcDir, "secret.txt")
	if err := os.WriteFile(src, []byte("data"), 0o640); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(dstDir, "secret.txt")

	moveViaCrossDeviceFallback(t, src, dst)
	got, err := os.Stat(dst)
	if err != nil {
		t.Fatal(err)
	}
	if got.Mode().Perm() != 0o640 {
		t.Fatalf("dst perm = %#o, want 0640", got.Mode().Perm())
	}
	if _, err := os.Stat(src); !os.IsNotExist(err) {
		t.Fatalf("src should be removed, stat err = %v", err)
	}
}

func TestMoveFileCrossDeviceMovesDirectory(t *testing.T) {
	srcDir := t.TempDir()
	dstParent := t.TempDir()
	nested := filepath.Join(srcDir, "nested.txt")
	if err := os.WriteFile(nested, []byte("nested"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(srcDir, 0o755); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(dstParent, "moved-dir")

	moveViaCrossDeviceFallback(t, srcDir, dst)
	movedNested := filepath.Join(dst, "nested.txt")
	if _, err := os.Stat(movedNested); err != nil {
		t.Fatalf("expected nested file at destination: %v", err)
	}
	got, err := os.Stat(dst)
	if err != nil {
		t.Fatal(err)
	}
	if got.Mode().Perm() != 0o755 {
		t.Fatalf("dst dir perm = %#o, want 0755", got.Mode().Perm())
	}
	if _, err := os.Stat(srcDir); !os.IsNotExist(err) {
		t.Fatalf("source directory should be removed, stat err = %v", err)
	}
}

func TestMoveFileCrossDevicePreservesSymlinkToFile(t *testing.T) {
	targetDir := t.TempDir()
	target := filepath.Join(targetDir, "target.txt")
	if err := os.WriteFile(target, []byte("data"), 0o644); err != nil {
		t.Fatal(err)
	}
	srcDir := t.TempDir()
	dstDir := t.TempDir()
	link := filepath.Join(srcDir, "link")
	if err := os.Symlink(target, link); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(dstDir, "link")

	moveViaCrossDeviceFallback(t, link, dst)
	gotTarget, err := os.Readlink(dst)
	if err != nil {
		t.Fatal(err)
	}
	if gotTarget != target {
		t.Fatalf("link target = %q, want %q", gotTarget, target)
	}
	info, err := os.Lstat(dst)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode()&os.ModeSymlink == 0 {
		t.Fatal("expected destination to remain a symlink")
	}
	if _, err := os.Stat(link); !os.IsNotExist(err) {
		t.Fatalf("source symlink should be removed, stat err = %v", err)
	}
}

func TestMoveFileCrossDevicePreservesSymlinkToDirectory(t *testing.T) {
	targetDir := t.TempDir()
	if err := os.Mkdir(filepath.Join(targetDir, "inside"), 0o755); err != nil {
		t.Fatal(err)
	}
	srcDir := t.TempDir()
	dstDir := t.TempDir()
	link := filepath.Join(srcDir, "dirlink")
	if err := os.Symlink(targetDir, link); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(dstDir, "dirlink")

	moveViaCrossDeviceFallback(t, link, dst)
	gotTarget, err := os.Readlink(dst)
	if err != nil {
		t.Fatal(err)
	}
	if gotTarget != targetDir {
		t.Fatalf("link target = %q, want %q", gotTarget, targetDir)
	}
	info, err := os.Lstat(dst)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode()&os.ModeSymlink == 0 {
		t.Fatal("expected destination to remain a symlink")
	}
}

func TestMoveFileCrossDeviceMovesDirectoryWithNestedSymlink(t *testing.T) {
	target := filepath.Join(t.TempDir(), "target.txt")
	if err := os.WriteFile(target, []byte("linked"), 0o644); err != nil {
		t.Fatal(err)
	}
	srcDir := t.TempDir()
	if err := os.Symlink(target, filepath.Join(srcDir, "nested-link")); err != nil {
		t.Fatal(err)
	}
	dstParent := t.TempDir()
	dst := filepath.Join(dstParent, "moved-dir")

	moveViaCrossDeviceFallback(t, srcDir, dst)
	movedLink := filepath.Join(dst, "nested-link")
	gotTarget, err := os.Readlink(movedLink)
	if err != nil {
		t.Fatal(err)
	}
	if gotTarget != target {
		t.Fatalf("nested link target = %q, want %q", gotTarget, target)
	}
	info, err := os.Lstat(movedLink)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode()&os.ModeSymlink == 0 {
		t.Fatal("expected nested entry to remain a symlink")
	}
}

func TestCopySymlinkReplacesExistingDestination(t *testing.T) {
	target := filepath.Join(t.TempDir(), "target.txt")
	if err := os.WriteFile(target, []byte("data"), 0o644); err != nil {
		t.Fatal(err)
	}
	workDir := t.TempDir()
	src := filepath.Join(workDir, "link")
	if err := os.Symlink(target, src); err != nil {
		t.Fatal(err)
	}
	dst := filepath.Join(workDir, "existing")
	if err := os.WriteFile(dst, []byte("old"), 0o644); err != nil {
		t.Fatal(err)
	}

	if err := copySymlink(src, dst); err != nil {
		t.Fatal(err)
	}
	gotTarget, err := os.Readlink(dst)
	if err != nil {
		t.Fatal(err)
	}
	if gotTarget != target {
		t.Fatalf("link target = %q, want %q", gotTarget, target)
	}
	info, err := os.Lstat(dst)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode()&os.ModeSymlink == 0 {
		t.Fatal("expected destination to be a symlink")
	}
}

func TestCopyFileContentsFallsBackAfterCopyFileRangeBadFileDescriptor(t *testing.T) {
	const content = "complete file contents"
	src := struct{ io.Reader }{bytes.NewBufferString(content)}
	dst := &copyFileRangeRejectingWriter{}

	if err := copyFileContents(dst, src); err != nil {
		t.Fatal(err)
	}
	if got := dst.String(); got != content {
		t.Fatalf("copied contents = %q, want %q", got, content)
	}
	if dst.readFromCalls != 1 {
		t.Fatalf("ReadFrom calls = %d, want 1", dst.readFromCalls)
	}
}

package files

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/dhowden/tag"
	"github.com/gtsteffaniak/filebrowser/backend/internal/adapters/fs/fileutils"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
	"github.com/gtsteffaniak/filebrowser/backend/internal/ffmpeg"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing/iteminfo"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/go-logger/logger"
)

// CheckPermissionsFunc allows tests to override CheckPermissions behavior
var CheckPermissionsFunc = func(opts utils.FileOptions, user *users.User) (string, string, error) {
	return checkPermissionsImpl(opts, user, svc())
}

// addMetadataToChildren runs concurrent ffmpeg/tag extraction for audio/video children.
// Each goroutine is registered on wg. Caller must invoke wg.Wait() after scheduling.
func addMetadataToChildren(response *iteminfo.ExtendedFileInfo, opts utils.FileOptions, wg *sync.WaitGroup) {
	sharedFFmpegService := ffmpeg.Get()
	if sharedFFmpegService == nil {
		return
	}
	for i := range response.Files {
		fileItem := &response.Files[i]
		isItemAudio := strings.HasPrefix(fileItem.Type, "audio")
		isItemVideo := strings.HasPrefix(fileItem.Type, "video")
		if !isItemAudio && !isItemVideo {
			continue
		}
		isAudio := isItemAudio
		wg.Go(func() {
			fullPath := response.RealPath + "/" + fileItem.Name
			if isAudio {
				if err := extractAudioMetadata(context.Background(), fileItem, fullPath, opts.AlbumArt, opts.Metadata, sharedFFmpegService); err != nil {
					logger.Debugf("failed to extract metadata for file: %s, error: %v", fileItem.Name, err)
				}
			} else {
				if err := extractVideoMetadata(context.Background(), fileItem, fullPath, sharedFFmpegService); err != nil {
					logger.Debugf("failed to extract video metadata for file: %s, error: %v", fileItem.Name, err)
				}
			}
		})
	}
}

// processDirectoryMetadata extracts metadata for audio/video files in directories
func processDirectoryMetadata(response *iteminfo.ExtendedFileInfo, idx *indexing.Index, opts utils.FileOptions) {
	metadataCount := 0
	for i := range response.Files {
		fileItem := &response.Files[i]
		isItemAudio := strings.HasPrefix(fileItem.Type, "audio")
		isItemVideo := strings.HasPrefix(fileItem.Type, "video")
		if isItemAudio || isItemVideo {
			metadataCount++
		}
	}
	var wg sync.WaitGroup

	wg.Go(func() {
		indexPath := idx.MakeIndexPath(response.Path, true).String()
		err := idx.RefreshDirectory(indexPath, false)
		if err != nil {
			logger.Debugf("Failed to refresh directory for folder size update: %v", err)
		}
	})

	if opts.Metadata && metadataCount > 0 {
		addMetadataToChildren(response, opts, &wg)
	}
	wg.Wait()
}

// finalizeResponse handles final response adjustments (OnlyOffice ID, scope stripping).
func finalizeResponse(response *iteminfo.ExtendedFileInfo, info *iteminfo.FileInfo, realPath string, user *users.User, userScope string) {
	// Add OnlyOffice ID if applicable
	if settings.Config.Integrations.OnlyOffice.Secret != "" && info.Type != "directory" && iteminfo.IsOnlyOffice(info.Name) {
		response.OnlyOfficeId = generateOfficeId(realPath)
	}

	// Strip user scope from response path to return path relative to user's context
	if user != nil && userScope != "" && userScope != "/" {
		response.Path = strings.TrimPrefix(response.Path, userScope)
		if response.Path == "" {
			response.Path = "/"
		}
	}
}

// normalizeFileInfoListing shapes files/folders for FileInfoFaster JSON:
// non-directories omit children (nil + omitempty); directories use empty slices instead of null.
func normalizeFileInfoListing(info *iteminfo.ExtendedFileInfo) {
	if info == nil {
		return
	}
	if info.Type == "directory" {
		info.Files = utils.NonNilSlice(info.Files)
		info.Folders = utils.NonNilSlice(info.Folders)
		return
	}
	info.Files = nil
	info.Folders = nil
}

// CheckPermissions validates user access and returns the resolved index path and user scope
func CheckPermissions(opts utils.FileOptions, user *users.User) (string, string, error) {
	return CheckPermissionsFunc(opts, user)
}

// checkPermissionsImpl is the actual implementation of CheckPermissions
func checkPermissionsImpl(opts utils.FileOptions, user *users.User, s *Service) (string, string, error) {
	if user == nil {
		return "", "", fmt.Errorf("user not provided")
	}
	if opts.Path == "" {
		return "", "", fmt.Errorf("%w: path not provided", errors.ErrInvalidRequestParams)
	}
	if opts.Source == "" {
		return "", "", fmt.Errorf("%w: source not provided", errors.ErrInvalidRequestParams)
	}

	// Get index
	idx := indexing.GetIndex(opts.Source)
	if idx == nil {
		return "", "", fmt.Errorf("could not get index: %v ", opts.Source)
	}

	// Resolve user scope
	userScope, scopeErr := user.GetScopeForSourcePath(idx.Path)
	if scopeErr != nil || userScope == "" {
		return "", "", fmt.Errorf("user has no access to source: %v", opts.Source)
	}

	safePath, err := utils.SanitizePath(opts.Path)
	if err != nil {
		return "", "", errors.ErrAccessDenied
	}

	indexPath := utils.JoinScopedIndexPath(userScope, safePath)
	parsedPath, err := utils.ParseSanitizedIndexPath(indexPath, true)
	if err != nil {
		return "", "", errors.ErrAccessDenied
	}
	if !s.accessPermitted(idx.Path, parsedPath, user.Username) {
		return indexPath, "", errors.ErrAccessDenied
	}
	return indexPath, userScope, nil
}

type Items struct {
	Files   []string `json:"files,omitempty"`
	Folders []string `json:"folders,omitempty"`
}

// This removes files whose names match any extension in hideFileExt.
func filterFilesByExt(files []iteminfo.ExtendedItemInfo, hideFileExt string) []iteminfo.ExtendedItemInfo {
	if hideFileExt == "" {
		return files
	}
	filtered := files[:0]
	for _, f := range files {
		if !utils.HideFileByExt(f.Name, hideFileExt) {
			filtered = append(filtered, f)
		}
	}
	return filtered
}

func GetDirItems(opts utils.FileOptions, user *users.User) (Items, error) {
	return getDirItemsImpl(opts, user, svc())
}

func getDirItemsImpl(opts utils.FileOptions, user *users.User, s *Service) (Items, error) {
	items := Items{}
	indexPath, userScope, topLevelErr := checkPermissionsImpl(opts, user, s)
	accessRulesErr := topLevelErr != nil && topLevelErr == errors.ErrAccessDenied && indexPath != ""
	if topLevelErr != nil && !accessRulesErr {
		return items, topLevelErr
	}
	// Get index
	idx := indexing.GetIndex(opts.Source)
	if idx == nil {
		return items, fmt.Errorf("could not get index: %v ", opts.Source)
	}
	infoReq := indexing.FileInfoRequest{
		IndexPath:         indexPath,
		FollowSymlinks:    opts.FollowSymlinks,
		ShowHidden:        opts.ShowHidden,
		HideFileExt:       opts.HideFileExt,
		Expand:            true,
		SkipExtendedAttrs: true,
	}
	if opts.FollowSymlinks {
		infoReq.BoundIndexPath = userScope
	}
	info, err := idx.GetFileInfo(infoReq)
	if err != nil {
		return items, err // Path excluded by index rules OR doesn't exist
	}
	if info.Type != "directory" {
		return items, fmt.Errorf("path is not a directory: %v ", indexPath)
	}
	if err := s.checkChildItemAccess(info, idx, user.Username); err != nil {
		return items, err
	}
	hasAccessibleItems := len(info.Files) > 0 || len(info.Folders) > 0
	if accessRulesErr && !hasAccessibleItems {
		return items, errors.ErrAccessDenied
	}
	if opts.Only == "files" || opts.Only == "" {
		for _, file := range info.Files {
			if opts.HideFileExt != "" && utils.HideFileByExt(file.Name, opts.HideFileExt) {
				continue
			}
			items.Files = append(items.Files, file.Name)
		}
	}
	if opts.Only == "folders" || opts.Only == "" {
		for _, folder := range info.Folders {
			items.Folders = append(items.Folders, folder.Name)
		}
	}
	return items, nil
}

// FileInfoFasterFunc is a variable that can be mocked in tests
var FileInfoFasterFunc = func(opts utils.FileOptions, user *users.User) (*iteminfo.ExtendedFileInfo, error) {
	return fileInfoFasterImpl(opts, user, svc())
}

func FileInfoFaster(opts utils.FileOptions, user *users.User) (*iteminfo.ExtendedFileInfo, error) {
	return FileInfoFasterFunc(opts, user)
}

// fileInfoFasterImpl is the actual implementation of FileInfoFaster
func fileInfoFasterImpl(opts utils.FileOptions, user *users.User, s *Service) (*iteminfo.ExtendedFileInfo, error) {
	response := &iteminfo.ExtendedFileInfo{}
	indexPath, userScope, topLevelErr := checkPermissionsImpl(opts, user, s)
	accessRulesErr := topLevelErr != nil && topLevelErr == errors.ErrAccessDenied && indexPath != ""
	if topLevelErr != nil && !accessRulesErr {
		return response, topLevelErr
	}
	// Get index
	idx := indexing.GetIndex(opts.Source)
	if idx == nil {
		return response, fmt.Errorf("could not get index: %v ", opts.Source)
	}
	// Layer 2: INDEX RULES (global)
	// Get file info using unified entry point (applies IsViewable/ShouldSkip)
	fileInfoReq := indexing.FileInfoRequest{
		IndexPath:         indexPath,
		FollowSymlinks:    opts.FollowSymlinks,
		ShowHidden:        opts.ShowHidden,
		HideFileExt:       opts.HideFileExt,
		Expand:            opts.Expand,
		SkipExtendedAttrs: opts.SkipExtendedAttrs,
	}
	if opts.FollowSymlinks {
		fileInfoReq.BoundIndexPath = userScope
	}
	info, err := idx.GetFileInfo(fileInfoReq)
	if err != nil {
		return response, err // Path excluded by index rules OR doesn't exist
	}
	// otherwise response keeps unfiltered Folders/Files while CheckChildItemAccess only mutates info.
	if info.Type == "directory" {
		if err := s.checkChildItemAccess(info, idx, user.Username); err != nil {
			return response, err
		}
	}
	hasAccessibleItems := len(info.Files) > 0 || len(info.Folders) > 0
	if accessRulesErr && !hasAccessibleItems {
		return response, errors.ErrAccessDenied
	}

	// Build response
	response.FileInfo = *info
	if opts.FollowSymlinks && info.Type != "directory" {
		realPath, _, err := idx.GetRealPathScoped(userScope, indexPath)
		if err != nil {
			return response, err
		}
		response.RealPath = realPath
	} else {
		response.RealPath = utils.JoinUnderSourceRoot(idx.Path, indexPath)
	}
	response.Source = opts.Source
	if user.Permissions.Share && opts.ShowSharedAttr {
		for i := range response.Files {
			file := &response.Files[i]
			file.IsShared = s.pathIsShared(response.Path+file.Name, idx.Path, user.ID)
		}
		for i := range response.Folders {
			folder := &response.Folders[i]
			folder.IsShared = s.pathIsShared(response.Path+folder.Name, idx.Path, user.ID)
		}
		response.IsShared = s.pathIsShared(response.Path, idx.Path, user.ID)
	}
	if info.Type == "directory" && opts.ShowPinnedItems {
		if opts.ShareHash != "" {
			if link, ok := s.shareByHash(opts.ShareHash); ok {
				if shareRelDir, err := link.ShareRelativeDir(response.Path); err == nil {
					response.PinnedItems = link.PinnedItems.NamesForDirectory(shareRelDir)
				}
			}
		} else if source, ok := users.ResolveSourceKey(response.Source); ok {
			response.PinnedItems = user.PinnedNamesForDirectory(source.Path, response.Path)
		}
	}

	defer func() {
		finalizeResponse(response, info, response.RealPath, user, userScope)
		normalizeFileInfoListing(response)
	}()
	if opts.SkipExtendedAttrs {
		if info.Type == "directory" && opts.HideFileExt != "" {
			response.Files = filterFilesByExt(response.Files, opts.HideFileExt)
		}
		return response, nil
	}
	// Process directory metadata if requested
	if info.Type == "directory" {
		processDirectoryMetadata(response, idx, opts)
		if opts.HideFileExt != "" {
			response.Files = filterFilesByExt(response.Files, opts.HideFileExt)
		}
	}
	// Process single file content/metadata
	isAudioVideo := strings.HasPrefix(info.Type, "audio") || strings.HasPrefix(info.Type, "video")
	if opts.Content || opts.Metadata || isAudioVideo {
		processContent(response, idx, opts)
	}
	return response, nil
}

func processContent(info *iteminfo.ExtendedFileInfo, idx *indexing.Index, opts utils.FileOptions) {
	isVideo := strings.HasPrefix(info.Type, "video")
	isAudio := strings.HasPrefix(info.Type, "audio")
	isFolder := info.Type == "directory"
	if isFolder {
		return
	}
	if isVideo && !opts.Metadata {
		return
	}
	if isAudio && !(opts.Metadata || opts.AlbumArt) {
		return
	}
	if isVideo {
		extItem := &iteminfo.ExtendedItemInfo{
			ItemInfo: info.ItemInfo,
		}
		err := extractVideoMetadata(context.Background(), extItem, info.RealPath, nil)
		if err != nil {
			logger.Debugf("failed to extract video metadata for file: "+info.RealPath, info.Name, err)
		} else {
			info.Metadata = extItem.Metadata
		}

		parentPath := filepath.Dir(info.Path)
		parentInfo, exists := idx.GetMetadataInfo(parentPath, true, false)
		if exists {
			info.GetSubtitles(parentInfo)
		}
		if opts.ExtractEmbeddedSubtitles {
			subtitles := ffmpeg.DetectEmbeddedSubtitles(info.RealPath, info.ModTime)
			info.Subtitles = append(info.Subtitles, subtitles...)
		}
		return
	}

	// Audio: run tag/album-art extraction when full metadata or preview (AlbumArt) is requested.
	// Preview uses AlbumArt without Metadata so we do not load arbitrary files as text content.
	if isAudio {
		extItem := &iteminfo.ExtendedItemInfo{
			ItemInfo: info.ItemInfo,
		}
		err := extractAudioMetadata(context.Background(), extItem, info.RealPath, opts.AlbumArt || opts.Content, opts.Metadata || opts.Content, nil)
		if err != nil {
			logger.Debugf("failed to extract audio metadata for file: "+info.RealPath, info.Name, err)
		} else {
			info.Metadata = extItem.Metadata
			info.HasPreview = extItem.Metadata != nil && len(extItem.Metadata.AlbumArt) > 0
		}
		return
	}

	if !opts.Content {
		return
	}

	// Process text content for non-video, non-audio files
	if info.Size < 20*1024*1024 { // 20 megabytes in bytes
		content, err := getContent(info.RealPath)
		if err != nil {
			logger.Debugf("could not get content for file: "+info.RealPath, info.Name, err)
			return
		}
		info.Content = content
	} else {
		logger.Debug("skipping large text file contents (20MB limit): "+info.Path, info.Name, info.Type)
	}
}

func generateOfficeId(realPath string) string {
	key, ok := utils.OnlyOfficeCache.Get(realPath)
	if !ok {
		timestamp := strconv.FormatInt(time.Now().UnixMilli(), 10)
		documentKey := utils.HashSHA256(realPath + timestamp)
		utils.OnlyOfficeCache.Set(realPath, documentKey)
		return documentKey
	}
	return key
}

// extractAudioMetadata extracts metadata from an audio file using dhowden/tag
// and optionally extracts duration using the ffmpeg service with concurrency control
// If ffmpegService is nil, a new service will be created (for backward compatibility)
func extractAudioMetadata(ctx context.Context, item *iteminfo.ExtendedItemInfo, realPath string, getArt bool, getDuration bool, ffmpegService *ffmpeg.FFmpegService) error {
	file, err := os.Open(realPath)
	if err != nil {
		return err
	}
	defer file.Close()

	// Check file size first to prevent reading extremely large files
	fileInfo, err := file.Stat()
	if err != nil {
		return err
	}

	// Skip files larger than 300MB to prevent memory issues
	maxSize := int64(300)
	if fileInfo.Size() > maxSize*1024*1024 {
		return fmt.Errorf("file with size %d MB exceeds metadata check limit: %d MB", fileInfo.Size()/1024/1024, maxSize)
	}

	m, err := tag.ReadFrom(file)
	if err != nil {
		return err
	}

	item.Metadata = &iteminfo.MediaMetadata{
		Title:  m.Title(),
		Artist: m.Artist(),
		Album:  m.Album(),
		Year:   m.Year(),
		Genre:  m.Genre(),
	}

	// Extract track number
	track, _ := m.Track()
	item.Metadata.Track = track

	// Check if lyrics are available without extract them
	item.Metadata.HasLyrics = hasLyricsSidecar(realPath) || m.Lyrics() != ""

	// Extract duration ONLY if explicitly requested using the ffmpeg VideoService
	// This respects concurrency limits and gracefully handles missing ffmpeg
	if getDuration {
		service := ffmpegService
		if service == nil {
			service = ffmpeg.Get()
		}
		if service != nil {
			if duration, err := service.GetMediaDuration(ctx, realPath); err == nil {
				item.Metadata.Duration = int(duration)
			}
		}
	}

	if !getArt {
		return nil
	}

	// Extract album art if available (stored as raw bytes, auto-encoded to base64 in JSON)
	if picture := m.Picture(); picture != nil && picture.Data != nil {
		// Size limit to prevent memory issues (max 5MB)
		if len(picture.Data) <= 5*1024*1024 {
			item.Metadata.AlbumArt = picture.Data
		} else {
			logger.Debugf("Skipping album art for %s: too large (%d bytes)", realPath, len(picture.Data))
		}
	}

	return nil
}

var lyricsSidecarExts = []string{".elrc", ".lrc", ".srt", ".vtt"}

func lyricsSidecar(dir, nameWithoutExt, ext string) (path string, ok bool) {
	sidecarPath := filepath.Join(dir, nameWithoutExt+ext)
	info, err := os.Lstat(sidecarPath)
	if err != nil {
		return "", false
	}
	if !info.Mode().IsRegular() {
		return "", false
	}
	if info.Size() > 15*1024*1024 { // 15MB
		return "", false
	}
	return sidecarPath, true
}

func findLyricsSidecar(realPath string) (data []byte, ext string, ok bool) {
	dir := filepath.Dir(realPath)
	base := filepath.Base(realPath)
	nameWithoutExt := strings.TrimSuffix(base, filepath.Ext(base))
	for _, ext = range lyricsSidecarExts {
		sidecarPath, candOk := lyricsSidecar(dir, nameWithoutExt, ext)
		if !candOk {
			continue
		}
		data, err := os.ReadFile(sidecarPath)
		if err != nil {
			continue
		}
		if strings.TrimSpace(string(data)) == "" {
			continue
		}
		return data, strings.TrimPrefix(ext, "."), true
	}
	return nil, "", false
}

func hasLyricsSidecar(realPath string) bool {
	dir := filepath.Dir(realPath)
	base := filepath.Base(realPath)
	nameWithoutExt := strings.TrimSuffix(base, filepath.Ext(base))
	for _, ext := range lyricsSidecarExts {
		sidecarPath, ok := lyricsSidecar(dir, nameWithoutExt, ext)
		if !ok {
			continue
		}
		f, err := os.Open(sidecarPath)
		if err != nil {
			continue
		}
		buf := make([]byte, 4096)
		for {
			n, readErr := f.Read(buf)
			if n > 0 && strings.TrimSpace(string(buf[:n])) != "" {
				f.Close()
				return true
			}
			if readErr != nil {
				break
			}
		}
		f.Close()
	}
	return false
}

// Returns raw lyrics from an audio file (from embedded tags or from sidecar files with the same name).
func ExtractLyrics(realPath string) (string, string, error) {
	if data, ext, ok := findLyricsSidecar(realPath); ok {
		return string(data), ext, nil
	}
	file, err := os.Open(realPath)
	if err != nil {
		return "", "", err
	}
	defer file.Close()
	m, err := tag.ReadFrom(file)
	if err != nil {
		return "", "", err
	}
	if raw := m.Lyrics(); raw != "" {
		return raw, "embedded", nil
	}
	return "", "", nil
}

// extractVideoMetadata extracts duration and codec info from video files using ffprobe.
// If ffmpegService is nil, a new service will be created (for backward compatibility)
func extractVideoMetadata(ctx context.Context, item *iteminfo.ExtendedItemInfo, realPath string, ffmpegService *ffmpeg.FFmpegService) error {
	service := ffmpegService
	if service == nil {
		service = ffmpeg.Get()
	}
	if service == nil {
		return nil
	}

	info, err := service.ProbeFile(ctx, realPath)
	if err != nil {
		duration, durErr := service.GetMediaDuration(ctx, realPath)
		if durErr != nil {
			return err
		}
		if duration > 0 {
			item.Metadata = &iteminfo.MediaMetadata{Duration: int(duration)}
		}
		return nil
	}

	meta := &iteminfo.MediaMetadata{}
	if info.Duration > 0 {
		meta.Duration = int(info.Duration)
	}
	if info.VideoCodec != "" {
		meta.VideoCodec = info.VideoCodec
	}
	if info.AudioCodec != "" {
		meta.AudioCodec = info.AudioCodec
	}
	if info.FormatName != "" {
		meta.Container = info.FormatName
	}
	if meta.Duration > 0 || meta.VideoCodec != "" || meta.AudioCodec != "" || meta.Container != "" {
		item.Metadata = meta
	}
	return nil
}

func DeleteFiles(source, absPath string, isDir bool) error {
	index := indexing.GetIndex(source)
	if index == nil {
		return fmt.Errorf("could not get index: %v ", source)
	}
	// Safety guard: never allow deletion of the source root directory itself
	cleanAbs := filepath.Clean(absPath)
	if cleanAbs == filepath.Clean(index.Path) {
		return fmt.Errorf("refusing to delete source root directory: %s", absPath)
	}

	if !index.Config.ResolvedRules.IndexingDisabled {
		indexPath := index.MakeIndexPath(absPath, isDir).String()

		// Perform the physical deletion
		err := os.RemoveAll(absPath)
		if err != nil {
			return err
		}

		// Clear cache entries
		indexing.RealPathCache.Delete(absPath)
		indexing.IsDirCache.Delete(absPath + ":isdir")

		// Remove metadata from index
		deleteSuccess := index.DeleteMetadata(indexPath, isDir, isDir)
		if !deleteSuccess {
			logger.Errorf("Failed to delete metadata from index for %s, but filesystem deletion succeeded", indexPath)
		}

		// Refresh the parent directory to recalculate sizes and update counts
		refreshConfig := utils.FileOptions{
			Path:  index.MakeIndexPath(filepath.Dir(absPath), true).String(),
			IsDir: true,
		}
		err = index.RefreshFileInfo(refreshConfig)
		return err
	}

	// Indexing disabled, just delete the file
	return os.RemoveAll(absPath)
}

func RefreshIndex(source string, path string, isDir bool, recursive bool) error {
	idx := indexing.GetIndex(source)
	if idx == nil {
		return fmt.Errorf("could not get index: %v ", source)
	}
	if idx.Config.ResolvedRules.IndexingDisabled {
		return nil
	}
	// Always normalize path using MakeIndexPath
	path = idx.MakeIndexPath(path, isDir).String()

	// Check if path is a symlink
	realPath, _, _ := idx.GetRealPath(path)
	isSymlink := false
	if realPath != "" {
		if fileInfo, err := os.Lstat(realPath); err == nil {
			isSymlink = fileInfo.Mode()&os.ModeSymlink != 0
		}
	}

	// Skip indexing only for paths that are explicitly excluded (not viewable and should be skipped)
	hidden := indexing.IsHidden(filepath.Join(idx.Path, path))
	if idx.ShouldSkip(isDir, path, hidden, isSymlink, false) {
		return nil
	}

	// For directories, check if the path exists on disk
	// If it doesn't exist, remove it from the index
	if isDir {
		realPath, _, err := idx.GetRealPath(path)
		if err == nil {
			// Check if the directory exists on disk
			if !Exists(realPath) {
				// Directory no longer exists, remove it from the index
				// This clears both Directories and DirectoriesLedger maps
				indexing.RealPathCache.Delete(realPath)
				indexing.IsDirCache.Delete(realPath + ":isdir")
				idx.DeleteMetadata(path, true, false)
				return nil
			}
		}
	}

	err := idx.RefreshFileInfo(utils.FileOptions{Path: path, IsDir: isDir, Recursive: recursive})
	if err != nil {
		logger.Errorf("RefreshFileInfo failed: %v", err)
		return err
	}
	return err
}

// validateMoveDestination checks if a move/rename operation is valid
// It prevents moving a directory into itself or its subdirectories
func validateMoveDestination(src, dst string, isSrcDir bool) error {
	// Clean and normalize paths
	src = filepath.Clean(src)
	dst = filepath.Clean(dst)

	// If source is a directory, check if destination is within source
	if isSrcDir {
		// Get the parent directory of the destination
		dstParent := filepath.Dir(dst)

		// Check if destination parent is the source directory or a subdirectory of it
		if strings.HasPrefix(dstParent+string(filepath.Separator), src+string(filepath.Separator)) || dstParent == src {
			return fmt.Errorf("cannot move directory '%s' to a location within itself: '%s'", src, dst)
		}
	}

	// Check if destination parent directory exists
	dstParent := filepath.Dir(dst)
	if dstParent != "." && dstParent != "/" {
		if _, err := os.Stat(dstParent); os.IsNotExist(err) {
			return fmt.Errorf("destination directory does not exist: '%s'", dstParent)
		}
	}

	return nil
}

func MoveResource(isSrcDir bool, sourceIndex, destIndex, realsrc, realdst string) error {
	return moveResourceImpl(isSrcDir, sourceIndex, destIndex, realsrc, realdst, svc())
}

func moveResourceImpl(isSrcDir bool, sourceIndex, destIndex, realsrc, realdst string, s *Service) error {
	// Check if source and destination are the same file
	if realsrc == realdst {
		return fmt.Errorf("cannot move a file to itself: %s", realsrc)
	}

	// Validate the move operation before executing
	if err := validateMoveDestination(realsrc, realdst, isSrcDir); err != nil {
		return err
	}

	// Get indexes for deletion and refresh operations
	srcIdx := indexing.GetIndex(sourceIndex)
	if srcIdx == nil {
		return fmt.Errorf("could not get source index: %v", sourceIndex)
	}
	dstIdx := indexing.GetIndex(destIndex)
	if dstIdx == nil {
		return fmt.Errorf("could not get destination index: %v", destIndex)
	}

	// Prepare paths for index operations
	srcIndexPath := srcIdx.MakeIndexPath(realsrc, isSrcDir).String()
	srcParentPath := filepath.Dir(realsrc)

	// Perform the physical move
	err := fileutils.MoveFile(realsrc, realdst)
	if err != nil {
		return err
	}

	// Handle SOURCE cleanup (treat as deletion)
	// Run async to avoid blocking the HTTP response
	if !srcIdx.Config.ResolvedRules.IndexingDisabled {
		go func() {
			if isSrcDir {
				srcIdx.DeleteMetadata(srcIndexPath, true, true)
			} else {
				srcIdx.DeleteMetadata(srcIndexPath, false, false)
			}
			if err := RefreshIndex(sourceIndex, srcParentPath, true, false); err != nil {
				logger.Errorf("Failed to refresh source parent directory %s after move: %v", srcParentPath, err)
			}
		}()
	}

	// Handle DESTINATION indexing
	// Run async to avoid blocking the HTTP response
	if !dstIdx.Config.ResolvedRules.IndexingDisabled {
		if isSrcDir {
			go func() {
				// Recursively index the moved directory tree
				if err := RefreshIndex(destIndex, realdst, true, true); err != nil {
					logger.Errorf("Failed to index moved directory %s: %v", realdst, err)
					return
				}

				// Refresh parent to update its size
				parentDir := filepath.Dir(realdst)
				if err := RefreshIndex(destIndex, parentDir, true, false); err != nil {
					logger.Errorf("Failed to refresh destination parent %s: %v", parentDir, err)
				}
			}()
		} else {
			// For files, refresh parent directory
			parentDir := filepath.Dir(realdst)
			go RefreshIndex(destIndex, parentDir, true, false) //nolint:errcheck
		}
	}

	// Share path reconciliation is handled by state.UpdateSharesForMovedResource (see http/resource.go).

	// Update access rules for the moved path
	if srcIdx.Path == dstIdx.Path {
		go s.updateAccessRulesOnMove(
			srcIdx.Path,
			srcIdx.MakeIndexPath(realsrc, isSrcDir),
			dstIdx.MakeIndexPath(realdst, isSrcDir),
		)
	}

	return nil
}

func CopyResource(isSrcDir bool, sourceIndex, destIndex, realsrc, realdst string) error {
	// Check if source and destination are the same file
	if realsrc == realdst {
		return fmt.Errorf("cannot copy a file to itself: %s", realsrc)
	}

	// Validate the copy operation before executing
	if err := validateMoveDestination(realsrc, realdst, isSrcDir); err != nil {
		logger.Errorf("[COPY] Copy validation failed: %v", err)
		return err
	}

	// Perform the physical copy
	err := fileutils.CopyFile(realsrc, realdst)
	if err != nil {
		logger.Errorf("[COPY] Physical copy failed: %v", err)
		return err
	}

	// Refresh source (non-recursive, just metadata)
	srcIdx := indexing.GetIndex(sourceIndex)
	if srcIdx != nil && !srcIdx.Config.ResolvedRules.IndexingDisabled {
		srcRefreshPath := realsrc
		if !isSrcDir {
			srcRefreshPath = filepath.Dir(realsrc)
		}
		go RefreshIndex(sourceIndex, srcRefreshPath, true, false) //nolint:errcheck
	}

	// Refresh destination (RECURSIVE for directories to capture full tree)
	// Run async to avoid blocking the HTTP response
	dstIdx := indexing.GetIndex(destIndex)
	if dstIdx != nil && !dstIdx.Config.ResolvedRules.IndexingDisabled {
		if isSrcDir {
			go func() {
				// Recursively index the copied directory tree
				if err := RefreshIndex(destIndex, realdst, true, true); err != nil {
					logger.Errorf("[COPY] Failed to index copied directory %s: %v", realdst, err)
					return
				}

				// Refresh parent to update its size
				parentDir := filepath.Dir(realdst)
				if err := RefreshIndex(destIndex, parentDir, true, false); err != nil {
					logger.Errorf("[COPY] Failed to refresh parent %s: %v", parentDir, err)
				}
			}()
		} else {
			// For files, refresh parent directory
			dstParent := filepath.Dir(realdst)
			go RefreshIndex(destIndex, dstParent, true, false) //nolint:errcheck
		}
	}
	return nil
}

func WriteDirectory(opts utils.FileOptions) error {
	idx := indexing.GetIndex(opts.Source)
	if idx == nil {
		return fmt.Errorf("could not get index: %v ", opts.Source)
	}
	realPath, _, _ := idx.GetRealPath(opts.Path)

	var stat os.FileInfo
	var err error
	// Check if the destination exists and is a file
	if stat, err = os.Stat(realPath); err == nil && !stat.IsDir() {
		// If it's a file and we're trying to create a directory, remove the file first
		err = os.Remove(realPath)
		if err != nil {
			return fmt.Errorf("could not remove existing file to create directory: %v", err)
		}
	}

	// Ensure the parent directories exist
	// Permissions are set by MkdirAll (subject to umask, which is usually acceptable)
	err = os.MkdirAll(realPath, fileutils.PermDir)
	if err != nil {
		return err
	}

	// Explicitly set directory permissions to bypass umask
	err = os.Chmod(realPath, fileutils.PermDir)
	if err != nil {
		// Handle chmod error gracefully
		logger.Debugf("Could not set file permissions for %s (this may be expected in restricted environments): %v", realPath, err)
	}

	// Refresh the directory itself recursively
	err = RefreshIndex(idx.Name, opts.Path, true, true)
	if err != nil {
		return err
	}

	// Refresh parent directory to update its size
	parentPath := filepath.Dir(opts.Path)
	if parentPath != "." && parentPath != "/" && parentPath != opts.Path {
		if err := RefreshIndex(idx.Name, parentPath, true, false); err != nil {
			logger.Debugf("Could not refresh parent directory %s: %v", parentPath, err)
		}
	}

	return nil
}

// WriteFileFunc is a variable that can be mocked in tests
var WriteFileFunc = writeFile

func WriteFile(source, path string, in io.Reader) error {
	return WriteFileFunc(source, path, in)
}

func writeFile(source, path string, in io.Reader) error {
	idx := indexing.GetIndex(source)
	if idx == nil {
		return fmt.Errorf("could not get index: %v ", source)
	}
	realPath, _, _ := idx.GetRealPath(path)
	// Strip trailing slash from realPath if it's meant to be a file
	realPath = strings.TrimRight(realPath, "/")
	// Ensure the parent directories exist
	parentDir := filepath.Dir(realPath)
	err := os.MkdirAll(parentDir, fileutils.PermDir)
	if err != nil {
		return err
	}
	applyDefaultFilePerm := false
	var stat os.FileInfo
	stat, err = os.Stat(realPath)
	if err != nil {
		if !os.IsNotExist(err) {
			return fmt.Errorf("stat file: %w", err)
		}
		applyDefaultFilePerm = true
	} else if stat.IsDir() {
		return fmt.Errorf("%w: %q", errors.ErrIsDirectory, path)
	}

	// Open the file for writing (create if it doesn't exist, truncate if it does)
	// For new files: permissions are set to fileutils.PermFile (subject to umask, then Chmod bypasses umask)
	// For existing regular files: do not Chmod so saves preserve mode and special bits
	file, err := os.OpenFile(realPath, os.O_RDWR|os.O_CREATE|os.O_TRUNC, fileutils.PermFile)
	if err != nil {
		return err
	}
	defer file.Close()

	// Copy the contents from the reader to the file
	_, err = io.Copy(file, in)
	if err != nil {
		return err
	}

	if applyDefaultFilePerm {
		err = os.Chmod(realPath, fileutils.PermFile)
		if err != nil {
			logger.Debugf("Could not set file permissions for %s (this may be expected in restricted environments): %v", realPath, err)
		}
	}

	// Refresh the file itself
	err = RefreshIndex(source, path, false, false)
	if err != nil {
		return err
	}

	// Refresh parent directory to update its size
	parentPath := filepath.Dir(path)
	if parentPath != "." && parentPath != "/" && parentPath != path {
		if err := RefreshIndex(source, parentPath, true, false); err != nil {
			logger.Debugf("Could not refresh parent directory %s: %v", parentPath, err)
		}
	}

	return nil
}

// getContent reads and returns the file content if it's considered an editable text file.
// This is a wrapper around utils.IsTextFile that also returns the file content.
func getContent(realPath string) (string, error) {
	// First check if it's a text file using the consolidated validation logic
	isText, err := utils.IsTextFile(realPath)
	if err != nil {
		return "", err
	}
	if !isText {
		// Not a text file, return empty string (no error, just not text)
		return "", nil
	}

	// It's a text file, read and return the content
	content, err := os.ReadFile(realPath)
	if err != nil {
		return "", err
	}

	// Handle empty file (return specific marker string)
	if len(content) == 0 {
		return "empty-file-x6OlSil", nil
	}

	return string(content), nil
}

func IsNamedPipe(mode os.FileMode) bool {
	return mode&os.ModeNamedPipe != 0
}

func IsSymlink(mode os.FileMode) bool {
	return mode&os.ModeSymlink != 0
}

func Exists(path string) bool {
	_, err := os.Stat(path)
	if err == nil {
		return true
	}
	if os.IsNotExist(err) {
		return false
	}
	return false
}

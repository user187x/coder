package share

import (
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"

	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
)

// IsSingleFileShare determines if this share is for a single file (not a directory).
// It checks both the file extension and filesystem to determine if the path points to a file.
func (l *Share) IsSingleFileShare() bool {
	if l.Path == "" {
		return false
	}

	// First, check if the path has a file extension (common indicator of a file)
	ext := filepath.Ext(l.Path)
	if ext != "" {
		// If it has an extension, it's likely a file, but let's verify with filesystem
		return l.isFileOnFilesystem()
	}

	// If no extension, check if it's a directory by looking at the filesystem
	return !l.isDirectoryOnFilesystem()
}

// isFileOnFilesystem checks if the path exists and is a file on the filesystem
func (l *Share) isFileOnFilesystem() bool {
	// Construct the full path using Source and Path
	fullPath := l.Path
	if l.SourcePath != "" {
		// If SourcePath is provided, it might be a relative path from the source
		fullPath = filepath.Join(l.SourcePath, l.Path)
	}

	info, err := os.Stat(fullPath)
	if err != nil {
		// If we can't stat the file, fall back to extension check
		return filepath.Ext(l.Path) != ""
	}

	return !info.IsDir()
}

// isDirectoryOnFilesystem checks if the path exists and is a directory on the filesystem
func (l *Share) isDirectoryOnFilesystem() bool {
	// Construct the full path using Source and Path
	fullPath := l.Path
	if l.SourcePath != "" {
		// If SourcePath is provided, it might be a relative path from the source
		fullPath = filepath.Join(l.SourcePath, l.Path)
	}

	info, err := os.Stat(fullPath)
	if err != nil {
		// If we can't stat the file, assume it's a file if it has an extension
		return filepath.Ext(l.Path) == ""
	}

	return info.IsDir()
}

// IsExpired checks if the share has expired based on the Expire timestamp
func (l *Share) IsExpired() bool {
	if l.Expire == 0 {
		return false // No expiration set
	}
	// This would need time.Now().Unix() but we avoid importing time here
	// The actual expiration check is handled in the storage layer
	return false // Placeholder - actual implementation would check current time
}

// HasPassword checks if the share is password protected
func (l *Share) HasPassword() bool {
	return l.PasswordHash != ""
}

// IsPermanent checks if the share is permanent (no expiration)
func (l *Share) IsPermanent() bool {
	return l.Expire == 0
}

// GetFileExtension returns the file extension of the shared file
func (l *Share) GetFileExtension() string {
	if l.Path == "" {
		return ""
	}
	return filepath.Ext(l.Path)
}

// GetFileName returns just the filename (without path) of the shared item
func (l *Share) GetFileName() string {
	if l.Path == "" {
		return ""
	}
	return filepath.Base(l.Path)
}

// InitUserDownloads initializes the user downloads map if needed
func (l *Share) InitUserDownloads() {
	// Note: This should be called within a lock at the state package level
	if l.UserDownloads == nil {
		l.UserDownloads = make(map[string]int)
	}
}

// IncrementUserDownload increments the download count for a specific user
func (l *Share) IncrementUserDownload(username string) {
	// Note: This should be called within a lock at the state package level
	if l.UserDownloads == nil {
		l.UserDownloads = make(map[string]int)
	}
	l.UserDownloads[username]++
}

// GetUserDownloadCount returns the download count for a specific user
func (l *Share) GetUserDownloadCount(username string) int {
	// Note: This should be called within a lock at the state package level
	if l.UserDownloads == nil {
		return 0
	}
	return l.UserDownloads[username]
}

// ResetDownloadCounts resets both global and per-user download counts
func (l *Share) ResetDownloadCounts() {
	// Note: This should be called within a lock at the state package level
	l.Downloads = 0
	l.UserDownloads = make(map[string]int)
}

// HasReachedUserLimit checks if a user has reached their download limit
func (l *Share) HasReachedUserLimit(username string) bool {
	if !l.PerUserDownloadLimit || l.DownloadsLimit == 0 {
		return false
	}
	count := l.GetUserDownloadCount(username)
	return count >= l.DownloadsLimit
}

func resolveSource(sourcePath string) (*settings.Source, bool) {
	if sourceInfo, ok := settings.Config.Server.SourceMap[sourcePath]; ok {
		return sourceInfo, true
	}
	if sourceInfo, ok := settings.Config.Server.NameToSource[sourcePath]; ok {
		return sourceInfo, true
	}
	return nil, false
}

func (l *Share) GetSourceName() string {
	if sourceInfo, ok := resolveSource(l.SourcePath); ok {
		return sourceInfo.Name
	}
	return ""
}

func (l *Share) UserCanEdit(user *users.User) bool {
	if user.Permissions.Admin {
		return true
	}
	return l.UserID != 0 && l.UserID == user.ID
}

func (l *Share) SourceURL(user *users.User) string {
	sourceName := l.GetSourceName()
	// get user scope path from share
	userScope, err := user.GetScopeForSourceName(sourceName)
	if err != nil {
		return ""
	}
	if !strings.HasPrefix(l.Path, userScope) {
		return ""
	}
	scopedPath := strings.TrimPrefix(l.Path, userScope)
	return "/" + filepath.Join("files", sourceName, scopedPath)
}

func (l *Share) BannerURL() string {
	_, _, err := l.GetShareImagePartsHelper(true)
	if err == nil {
		return fmt.Sprintf("%s%spublic/api/share/image?banner=true&hash=%s", settings.Config.Http.ExternalUrl, settings.Config.Http.BaseURL, l.Hash)
	}
	return l.Banner
}

func (l *Share) FaviconURL() string {
	_, _, err := l.GetShareImagePartsHelper(false)
	if err == nil {
		return fmt.Sprintf("%s%spublic/api/share/image?favicon=true&hash=%s", settings.Config.Http.ExternalUrl, settings.Config.Http.BaseURL, l.Hash)
	}
	return l.Favicon
}

func (l *Share) GetShareImagePartsHelper(isBanner bool) (string, string, error) {
	// Get the asset query string from share
	var assetQueryString string
	if isBanner {
		assetQueryString = l.Banner
	} else {
		assetQueryString = l.Favicon
	}

	if assetQueryString == "" {
		return "", "", fmt.Errorf("asset not configured for this share")
	}

	// Parse the query string to extract source and path
	assetParams, err := url.ParseQuery(assetQueryString)
	if err != nil {
		return "", "", fmt.Errorf("invalid asset configuration: %v", err)
	}

	sourceName := assetParams.Get("source")
	assetPath := assetParams.Get("path")

	if sourceName == "" || assetPath == "" {
		return "", "", fmt.Errorf("source or path not found in asset configuration")
	}

	return sourceName, assetPath, nil
}

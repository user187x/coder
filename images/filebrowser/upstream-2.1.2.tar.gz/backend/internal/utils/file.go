package utils

import (
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/hex"
	"fmt"
	"hash"
	"io"
	"os"
	"path"
	"strings"

	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
)

// GetChecksum calculates the checksum of a file using the specified algorithm.
// Returns the checksum as a hex-encoded string.
func GetChecksum(fullPath, algo string) (string, error) {
	reader, err := os.Open(fullPath)
	if err != nil {
		return "", err
	}
	defer reader.Close()

	hashFuncs := map[string]hash.Hash{
		"md5":    md5.New(),
		"sha1":   sha1.New(),
		"sha256": sha256.New(),
		"sha512": sha512.New(),
	}

	h, ok := hashFuncs[algo]
	if !ok {
		return "", errors.ErrInvalidOption
	}

	_, err = io.Copy(h, reader)
	if err != nil {
		return "", err
	}

	return hex.EncodeToString(h.Sum(nil)), nil
}

// FileOptions are the options when getting a file info.
type FileOptions struct {
	Path                     string // realpath
	Source                   string
	IsDir                    bool
	Expand                   bool
	Content                  bool
	Recursive                bool   // whether to recursively index directories
	Metadata                 bool   // whether to get metadata
	ExtractEmbeddedSubtitles bool   // whether to extract embedded subtitles from media files
	AlbumArt                 bool   // whether to get album art from media files
	ShowHidden               bool   // whether to show hidden files (true = show, false = hide)
	ShowPinnedItems          bool   // whether to show pinned items
	ShareHash                string // when set, pinned items are loaded from this share link
	HideFileExt              string // Hide files based on extensions (eg: '.lrc' or '.srt')
	FollowSymlinks           bool   // whether to follow symlinks
	Only                     string // whether to only get files or folders
	SkipExtendedAttrs        bool   // whether to skip extended attributes
	ShowSharedAttr           bool   // whether to show share attributes
}

// SanitizePath cleans and validates a path or path-like filter (index paths, globs, etc.)
// to block traversal. Rule 1: Do Not Use Untrusted Input in File Paths (without validation).
func SanitizePath(inputPath string) (string, error) {
	inputPath = strings.ReplaceAll(inputPath, `\`, `/`)
	clean := path.Clean(inputPath)

	// Split the path into segments to check for path traversal attempts.
	// We check if ".." appears as a complete path segment (not just in a filename).
	segments := strings.Split(clean, "/")

	for _, segment := range segments {
		// Check if any segment is exactly ".." (path traversal attempt).
		// This catches any ".." that path.Clean couldn't resolve (i.e., escape attempts).
		if segment == ".." {
			return "", fmt.Errorf("invalid path: path traversal detected")
		}
	}

	if clean == "." {
		return "", fmt.Errorf("invalid path: path must be a standard index path")
	}

	return clean, nil
}

// HideFileByExt will check if a filename matches any of the hidden extensions
func HideFileByExt(filename, hideExt string) bool {
	if hideExt == "" {
		return false
	}
	exts := strings.Fields(hideExt)
	nameLower := strings.ToLower(filename)
	for _, ext := range exts {
		ext = strings.TrimSpace(ext)
		if ext == "" {
			continue
		}
		if !strings.HasPrefix(ext, ".") {
			ext = "." + ext
		}
		if strings.HasSuffix(nameLower, strings.ToLower(ext)) {
			return true
		}
	}
	return false
}

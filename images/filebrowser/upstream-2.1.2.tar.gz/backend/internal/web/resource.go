package web

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/gtsteffaniak/filebrowser/backend/internal/activity"
	"github.com/gtsteffaniak/filebrowser/backend/internal/adapters/fs/files"
	"github.com/gtsteffaniak/filebrowser/backend/internal/adapters/fs/fileutils"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
	"github.com/gtsteffaniak/filebrowser/backend/internal/preview"
	"github.com/gtsteffaniak/filebrowser/backend/internal/quota"
	"github.com/gtsteffaniak/filebrowser/backend/internal/state"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing/iteminfo"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/go-cache/cache"
	"github.com/gtsteffaniak/go-logger/logger"
)

var pauseCache = cache.NewCache[string](1 * time.Minute)
var publicPauseCache = cache.NewCache[string](1 * time.Minute)

// pauseCacheKeySep separates segments in pause cache keys (not used in source names/paths).
const pauseCacheKeySep = "\x1e"

func pauseUploadCacheKey(source, path string) string {
	return source + pauseCacheKeySep + path
}

func publicPauseUploadCacheKey(shareHash, source, indexPath string) string {
	return shareHash + pauseCacheKeySep + source + pauseCacheKeySep + indexPath
}

// resourcePostPermCheck validates create vs overwrite permissions for ResourcePostHandler.
func resourcePostPermCheck(exists bool, override bool, perms users.SourceFilePermissions) (int, error) {
	if exists {
		if override && !perms.Modify {
			return http.StatusForbidden, fmt.Errorf("user is not allowed to modify")
		}
		return 0, nil
	}
	if !perms.Create {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to create")
	}
	return 0, nil
}

// resourcePatchPermCheck validates move/copy/rename permissions. Returns a failure message when denied.
func resourcePatchPermCheck(action, fromSource, toSource string, fromPerms, toPerms users.SourceFilePermissions) string {
	switch action {
	case "copy":
		if !fromPerms.Download || !toPerms.Create {
			return "user is not allowed to copy"
		}
	case "move", "rename":
		if !fromPerms.Modify {
			return "user is not allowed to modify"
		}
		if toSource != fromSource && !toPerms.Modify {
			return "user is not allowed to modify destination source"
		}
	}
	return ""
}

// reconcileSharesAfterMove updates authoritative share rows in state after a filesystem move.
func reconcileSharesAfterMove(isSrcDir bool, sourceIndex, destIndex, realsrc, realdst string) {
	srcIdx := indexing.GetIndex(sourceIndex)
	dstIdx := indexing.GetIndex(destIndex)
	if srcIdx == nil || dstIdx == nil {
		logger.Errorf("reconcile shares after move: missing index src=%s dst=%s", sourceIndex, destIndex)
		return
	}
	_, err := state.UpdateSharesForMovedResource(
		srcIdx.Path,
		srcIdx.MakeIndexPath(realsrc, isSrcDir).String(),
		dstIdx.Path,
		dstIdx.MakeIndexPath(realdst, isSrcDir).String(),
	)
	if err != nil {
		logger.Errorf("reconcile shares after move: %v", err)
	}
}

// validateMoveOperation checks if a move/rename operation is valid at the HTTP level
// It prevents moving a directory into itself or its subdirectories
func validateMoveOperation(src, dst string, isSrcDir bool) error {
	// Clean and normalize paths
	src = filepath.Clean(src)
	dst = filepath.Clean(dst)

	// If source is a directory, check if destination is within source
	if isSrcDir {
		// Get the parent directory of the destination
		dstParent := filepath.Dir(dst)

		// Check if destination parent is the source directory or a subdirectory of it
		if strings.HasPrefix(dstParent+string(filepath.Separator), src+string(filepath.Separator)) || dstParent == src {
			return fmt.Errorf("cannot move directory '%s' to a location within itself: '%s'", src, dst)
		}
	}

	// Check if destination parent directory exists
	dstParent := filepath.Dir(dst)
	if dstParent != "." && dstParent != "/" {
		if _, err := os.Stat(dstParent); os.IsNotExist(err) {
			return fmt.Errorf("destination directory does not exist: '%s'", dstParent)
		}
	}

	return nil
}

// resourceGetHandler retrieves information about a resource.
// @Summary Get resource information
// @Description Returns metadata and optionally file contents for a specified resource path.
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "Path to the resource"
// @Param skipExtendedAttrs query string false "When true, omit index-level extended fields (e.g. hasPreview); does not disable ffmpeg/media extraction"
// @Param source query string true "Source name for the desired source, default is used if not provided"
// @Param content query string false "Include file content if true"
// @Param metadata query string false "When true, run audio/video metadata extraction, subtitles, and directory media batch processing"
// @Param checksum query string false "Optional checksum validation"
// @Success 200 {object} iteminfo.FileInfo "Resource metadata"
// @Failure 400 {object} map[string]string "Missing or invalid path query parameter"
// @Failure 404 {object} map[string]string "Resource not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/resources [get]
func resourceGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if _, ok := r.URL.Query()["path"]; !ok {
		return http.StatusBadRequest, fmt.Errorf("path query parameter is required")
	}
	path := r.URL.Query().Get("path")
	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, err
	}
	path = cleanPath
	source := r.URL.Query().Get("source")
	filePerms, err := effectiveFilePerms(d, source)
	if err != nil {
		return http.StatusForbidden, err
	}
	if !filePerms.View {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to view files in this source")
	}
	getContent := r.URL.Query().Get("content") == "true"
	getMetadata := r.URL.Query().Get("metadata") == "true"
	skipExtendedAttrs := r.URL.Query().Get("skipExtendedAttrs") == "true"
	fileInfo, err := files.FileInfoFaster(utils.FileOptions{
		FollowSymlinks:           true,
		Path:                     path,
		Source:                   source,
		Expand:                   true,
		Content:                  getContent,
		Metadata:                 getMetadata,
		ExtractEmbeddedSubtitles: settings.Config.Integrations.Media.ExtractEmbeddedSubtitles,
		ShowHidden:               d.User.ShowHidden,
		HideFileExt:              d.User.HideFileExt,
		SkipExtendedAttrs:        skipExtendedAttrs,
		ShowSharedAttr:           true,
		ShowPinnedItems:          true,
	}, d.User)
	if err != nil {
		return ErrToStatus(err), err
	}
	if !filePerms.Download && fileInfo.Content != "" {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to get content, requires download permission")
	}
	if fileInfo.Type == "directory" {
		AttachViewTokensForDirectory(d, source, fileInfo)
		return RenderJSON(w, r, fileInfo)
	}
	if algo := r.URL.Query().Get("checksum"); algo != "" {
		checksum, err := utils.GetChecksum(fileInfo.RealPath, algo)
		if err == errors.ErrInvalidOption {
			return http.StatusBadRequest, nil
		} else if err != nil {
			return http.StatusInternalServerError, err
		}
		fileInfo.Checksums = make(map[string]string)
		fileInfo.Checksums[algo] = checksum
	}
	AttachViewToken(d, source, fileInfo)
	return RenderJSON(w, r, fileInfo)
}

// publicGetResourceHandler returns file or directory information from a public share.
// @Summary Get file/directory information from a public share
// @Description Returns metadata for files or directories accessible via a public share link. Browsing is disabled for upload-only shares.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param path query string false "Path within the share to retrieve information for. Defaults to share root."
// @Param content query string false "Include file content if true"
// @Param metadata query string false "Extract audio/video metadata if true"
// @Success 200 {object} iteminfo.FileInfo "File or directory metadata"
// @Failure 403 {object} map[string]string "Share unavailable or access denied"
// @Failure 404 {object} map[string]string "Share not found or file not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Failure 501 {object} map[string]string "Browsing disabled for upload shares"
// @Router /public/api/resources [get]
func publicGetResourceHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if d.Share.ShareType == "upload" {
		return http.StatusNotImplemented, fmt.Errorf("browsing is disabled for upload shares")
	}
	return RenderJSON(w, r, d.FileInfo)
}

// resourceDeleteHandler deletes a resource at a specified path.
// @Summary Delete a resource
// @Description Deletes a resource located at the specified path.
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "Path to the resource"
// @Param source query string true "Source name for the desired source, default is used if not provided"
// @Success 200 "Resource deleted successfully"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Resource not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/resources [delete]
func resourceDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	path := r.URL.Query().Get("path")
	source := r.URL.Query().Get("source")
	filePerms, err := effectiveFilePerms(d, source)
	if err != nil {
		return http.StatusForbidden, err
	}
	if d.Share.Hash == "" && !filePerms.Delete {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to delete")
	}

	if path == "/" {
		return http.StatusForbidden, fmt.Errorf("cannot delete your user's root directory")
	}

	idx := indexing.GetIndex(source)
	if idx == nil {
		return http.StatusNotFound, fmt.Errorf("source %s not found", source)
	}

	if idx.Config.ReadOnly {
		return http.StatusForbidden, fmt.Errorf("source is read-only")
	}

	fileInfo, err := files.FileInfoFaster(utils.FileOptions{
		Path:        path,
		Source:      source,
		Expand:      false,
		ShowHidden:  d.User.ShowHidden,
		HideFileExt: d.User.HideFileExt,
	}, d.User)
	if err != nil {
		return ErrToStatus(err), err
	}

	// delete thumbnails
	preview.DelThumbs(r.Context(), *fileInfo)

	principal := quota.PrincipalForUpload(d.User, d.Share.UserID, d.Share.Hash)
	sourceInfo, ok := settings.Config.Server.NameToSource[source]
	if !ok {
		return http.StatusNotFound, fmt.Errorf("source %s not found", source)
	}
	var deleteBytes int64
	if fileInfo.Type == "directory" {
		deleteBytes, _ = state.IndexedPathBytes(source, fileInfo.Path, true)
	} else {
		deleteBytes = fileInfo.Size
	}

	err = files.DeleteFiles(source, fileInfo.RealPath, fileInfo.Type == "directory")
	if err != nil {
		return ErrToStatus(err), err
	}
	if deleteBytes > 0 {
		if adjErr := state.ApplyAccountedUsageDelta(principal, source, sourceInfo.Path, fileInfo.Path, d.Share.Hash, -deleteBytes); adjErr != nil {
			logger.Warningf("quota adjust after delete failed: %v", adjErr)
		}
	}
	activity.RecordDelete(r, toActor(d), source, path)
	return http.StatusOK, nil

}

// deprecated -- see publicBulkDeleteHandler
func publicDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.Share.AllowDelete {
		return http.StatusForbidden, fmt.Errorf("delete is not allowed for this share")
	}
	fileInfo, err := files.FileInfoFaster(utils.FileOptions{
		FollowSymlinks: true,
		Path:           d.IndexPath,
		Source:         d.Share.SourcePath,
	}, d.ShareUser)
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("resource not available")
	}
	err = files.DeleteFiles(d.Share.SourcePath, fileInfo.RealPath, fileInfo.Type == "directory")
	if err != nil {
		logger.Errorf("public delete handler: error deleting resource with error %v", err)
		return http.StatusInternalServerError, fmt.Errorf("an error occured while deleting the resource")
	}
	preview.DelThumbs(r.Context(), *fileInfo)
	return http.StatusOK, nil
}

// BulkDeleteItem represents a single item in a bulk delete request
type BulkDeleteItem struct {
	Source  string `json:"source"`
	Path    string `json:"path"`
	Message string `json:"message,omitempty"`
}

// BulkDeleteResponse represents the response from a bulk delete operation
type BulkDeleteResponse struct {
	Succeeded []BulkDeleteItem `json:"succeeded"`
	Failed    []BulkDeleteItem `json:"failed"`
}

// MoveCopyItem represents a single item in a move/copy request
type MoveCopyItem struct {
	FromSource string `json:"fromSource,omitempty"`
	FromPath   string `json:"fromPath,omitempty"`
	ToSource   string `json:"toSource,omitempty"`
	ToPath     string `json:"toPath,omitempty"`
	Message    string `json:"message,omitempty"`
}

// MoveCopyRequest represents a move/copy operation request
type MoveCopyRequest struct {
	Items     []MoveCopyItem `json:"items"`
	Action    string         `json:"action"`    // "copy", "move", or "rename"
	Overwrite bool           `json:"overwrite"` // Overwrite if destination exists
	Rename    bool           `json:"rename"`    // Auto-rename if destination exists
}

// MoveCopyResponse represents the response from a move/copy operation
type MoveCopyResponse struct {
	Succeeded []MoveCopyItem `json:"succeeded"`
	Failed    []MoveCopyItem `json:"failed"`
}

// resourceBulkDeleteHandler deletes multiple resources in a single request.
// @Summary Bulk delete resources
// @Description Deletes multiple resources specified in the request body. Returns a list of succeeded and failed deletions.
// @Tags Resources
// @Accept json
// @Produce json
// @Param items body []BulkDeleteItem true "Array of items to delete, each with source and path"
// @Success 200 {object} BulkDeleteResponse "All resources deleted successfully"
// @Success 207 {object} BulkDeleteResponse "Partial success - some resources deleted, some failed"
// @Failure 400 {object} map[string]string "Bad request - invalid JSON or empty items array"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 500 {object} map[string]string "Internal server error - all deletions failed"
// @Router /api/resources/bulk [delete]
func ResourceBulkDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	filePermUser := d.User
	if d.Share.Hash != "" {
		filePermUser = d.ShareUser
	}

	// Parse request body
	var items []BulkDeleteItem
	if err := json.NewDecoder(r.Body).Decode(&items); err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid JSON body: %v", err)
	}

	if len(items) == 0 {
		return http.StatusBadRequest, fmt.Errorf("items array cannot be empty")
	}

	response := BulkDeleteResponse{
		Succeeded: make([]BulkDeleteItem, 0),
		Failed:    make([]BulkDeleteItem, 0),
	}

	// Process each item one at a time
	for _, item := range items {
		rawPath := item.Path
		// Validate item
		if rawPath == "" {
			response.Failed = append(response.Failed, BulkDeleteItem{
				Source:  item.Source,
				Path:    rawPath,
				Message: "path was empty",
			})
			continue
		}

		// Prevent deletion of root
		if rawPath == "/" {
			response.Failed = append(response.Failed, BulkDeleteItem{
				Source:  item.Source,
				Path:    rawPath,
				Message: "cannot delete root directory",
			})
			continue
		}
		sanitizedPath, err := utils.SanitizePath(rawPath)
		if err != nil {
			response.Failed = append(response.Failed, BulkDeleteItem{
				Source:  item.Source,
				Path:    rawPath,
				Message: err.Error(),
			})
			continue
		}

		if d.Share.Hash != "" {
			sourceName := d.Share.GetSourceName()
			if sourceName == "" {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source name is empty",
				})
				continue
			}

			idx := indexing.GetIndex(sourceName)
			if idx == nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source not found",
				})
				continue
			}

			if idx.Config.ReadOnly {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source is read-only",
				})
				continue
			}

			// get user scope path from share
			userScope, err := d.ShareUser.GetScopeForSourceName(sourceName)
			if err != nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "user does not have access",
				})
				continue
			}
			withoutUserScope := strings.TrimPrefix(d.Share.Path, userScope)
			indexPath := utils.JoinScopedIndexPath(withoutUserScope, sanitizedPath)

			fileInfo, err := files.FileInfoFaster(utils.FileOptions{
				FollowSymlinks: true,
				Path:           indexPath,
				Source:         sourceName,
				ShowHidden:     true,
			}, filePermUser)
			if err != nil {
				return http.StatusNotFound, fmt.Errorf("resource not available")
			}

			// Delete the file/directory
			err = files.DeleteFiles(sourceName, fileInfo.RealPath, fileInfo.Type == "directory")
			if err != nil {
				logger.Errorf("resource bulk delete handler: error deleting file/directory: %v", err)
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "error deleting file/directory, admin must check the logs",
				})
				continue
			}
			// Delete thumbnails
			preview.DelThumbs(r.Context(), *fileInfo)
		} else {
			// Regular user context - validate source and check user scope
			if item.Source == "" {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source was empty, source is required",
				})
				continue
			}

			// Check user scope for this source
			_, err := filePermUser.GetScopeForSourceName(item.Source)
			if err != nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: fmt.Sprintf("user does not have access: %v", err),
				})
				continue
			}
			filePerms, permErr := effectiveFilePerms(d, item.Source)
			if permErr != nil || !filePerms.Delete {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "user is not allowed to delete",
				})
				continue
			}

			idx := indexing.GetIndex(item.Source)
			if idx == nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source not found",
				})
				continue
			}

			if idx.Config.ReadOnly {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: "source is read-only",
				})
				continue
			}

			// Get file info
			fileInfo, err := files.FileInfoFaster(utils.FileOptions{
				FollowSymlinks: true,
				Path:           sanitizedPath,
				Source:         item.Source,
				ShowHidden:     true,
			}, filePermUser)
			if err != nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: err.Error(),
				})
				continue
			}
			err = files.DeleteFiles(item.Source, fileInfo.RealPath, fileInfo.Type == "directory")
			if err != nil {
				response.Failed = append(response.Failed, BulkDeleteItem{
					Source:  item.Source,
					Path:    rawPath,
					Message: err.Error(),
				})
				continue
			}
			preview.DelThumbs(r.Context(), *fileInfo)
		}
		// Success — echo the client path in the response
		loggedItem := BulkDeleteItem{
			Source: item.Source,
			Path:   rawPath,
		}
		if d.Share.Hash != "" {
			loggedItem.Source = d.Share.GetSourceName()
		}
		response.Succeeded = append(response.Succeeded, loggedItem)
	}

	// Determine status code based on results
	statusCode := http.StatusOK
	if len(response.Failed) > 0 {
		statusCode = http.StatusMultiStatus
	}

	if len(response.Succeeded) > 0 {
		activity.RecordBulkDelete(r, toActor(d), bulkDeleteActivityItems(response.Succeeded))
	}

	return RenderJSON(w, r, response, statusCode)
}

// publicBulkDeleteHandler deletes multiple resources from a public share in a single request.
// @Summary Bulk delete resources from public share
// @Description Deletes multiple resources specified in the request body. Returns a list of succeeded and failed deletions.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param items body []BulkDeleteItem true "Array of items to delete, each with source and path"
// @Success 200 {object} BulkDeleteResponse "All resources deleted successfully"
// @Success 207 {object} BulkDeleteResponse "Partial success - some resources deleted, some failed"
// @Failure 400 {object} map[string]string "Bad request - invalid JSON or empty items array"
// @Failure 403 {object} map[string]string "Forbidden - delete not allowed for this share"
// @Failure 500 {object} map[string]string "Internal server error - all deletions failed"
// @Router /public/api/resources/bulk [delete]
func publicBulkDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.Share.AllowDelete {
		return http.StatusForbidden, fmt.Errorf("delete is not allowed for this share")
	}
	status, err := ResourceBulkDeleteHandler(w, r, d)
	if err != nil {
		logger.Errorf("public bulk delete handler: error deleting resources with error %v", err)
		return http.StatusInternalServerError, fmt.Errorf("an error occurred while processing the request")
	}
	return status, nil
}

// resourcePauseHandler registers a graceful pause for an in-flight chunked upload.
// Call immediately before aborting the chunk POST so the server keeps partial data.
// @Summary Register graceful chunked upload pause
// @Description Sets a short-lived server flag for the given source and path. When the active chunk POST then fails (e.g. client abort), the server trims the incomplete chunk but keeps the temp partial file for resume.
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "Destination path (same as upload)"
// @Param source query string true "Source name (same as upload)"
// @Success 200 "Pause registered"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Source not found"
// @Router /api/resources/pause [post]
func resourcePauseHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if d.Share.Hash != "" {
		return http.StatusBadRequest, fmt.Errorf("use public pause endpoint for share uploads")
	}
	source := r.URL.Query().Get("source")
	filePerms, err := effectiveFilePerms(d, source)
	if err != nil {
		return http.StatusForbidden, err
	}
	if !filePerms.Create {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to pause uploads")
	}
	path := r.URL.Query().Get("path")
	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, err
	}
	idx := indexing.GetIndex(source)
	if idx == nil {
		logger.Debugf("source %s not found", source)
		return http.StatusNotFound, fmt.Errorf("source %s not found", source)
	}
	userscope, err := d.User.GetScopeForSourceName(source)
	if err != nil {
		return http.StatusForbidden, err
	}
	fullIndexPath := utils.JoinScopedIndexPath(userscope, cleanPath)
	if !state.AccessPermitted(idx.Path, utils.IndexPathFromNormalized(fullIndexPath, true), d.User.Username) {
		return http.StatusForbidden, fmt.Errorf("access denied to path %s", fullIndexPath)
	}
	pauseCache.Set(pauseUploadCacheKey(source, fullIndexPath), "1")
	return http.StatusOK, nil
}

// publicPauseHandler registers a graceful pause for a public share chunked upload.
// @Summary Register graceful chunked upload pause (public share)
// @Description Same as authenticated pause, for upload shares. Uses hash and path query parameters like other public resource APIs.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash"
// @Param path query string true "Path within the share (same as upload)"
// @Success 200 "Pause registered"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Source not found"
// @Router /public/api/resources/pause [post]
func PublicPauseHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if d.Share.ShareType != "upload" && !d.Share.AllowCreate {
		return http.StatusForbidden, fmt.Errorf("pausing uploads is not allowed for this share")
	}
	src, ok := settings.Config.Server.SourceMap[d.Share.SourcePath]
	if !ok {
		return http.StatusNotFound, fmt.Errorf("source not found")
	}
	sourceName := src.Name
	publicPauseCache.Set(publicPauseUploadCacheKey(d.Share.Hash, sourceName, d.IndexPath), "1")
	return http.StatusOK, nil
}

// resourcePostHandler creates or uploads a new resource.
// @Summary Create or upload a resource
// @Description Creates a new resource or uploads a file at the specified path. Supports file uploads and directory creation.
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "url encoded destination path where to place the files inside the destination source"
// @Param source query string true "Name for the desired filebrowser destination source name, default is used if not provided"
// @Param override query bool false "Override existing file if true"
// @Param isDir query bool false "Explicitly specify if the resource is a directory"
// @Success 200 "Resource created successfully"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Resource not found"
// @Failure 409 {object} map[string]string "Conflict - Resource already exists"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/resources [post]
func ResourcePostHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	path := r.URL.Query().Get("path")
	source := r.URL.Query().Get("source")

	// Rule 1: Validate user-provided path to prevent path traversal
	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, err
	}
	path = cleanPath

	idx := indexing.GetIndex(source)
	if idx == nil {
		logger.Debugf("source %s not found", source)
		return http.StatusNotFound, fmt.Errorf("source %s not found", source)
	}

	if idx.Config.ReadOnly {
		return http.StatusForbidden, fmt.Errorf("source is read-only")
	}

	filePermUser := d.User
	if d.Share.Hash != "" {
		filePermUser = d.ShareUser
	}
	isDir := r.URL.Query().Get("isDir") == "true"
	fileOpts := utils.FileOptions{
		Path:           path,
		Source:         source,
		Expand:         false,
		FollowSymlinks: true,
	}

	userscope, err := filePermUser.GetScopeForSourceName(source)
	if err != nil {
		logger.Debugf("error getting scope from source name: %v", err)
		return http.StatusForbidden, err
	}
	userscope = strings.TrimRight(userscope, "/")

	fullIndexPath := utils.JoinScopedIndexPath(userscope, path)

	// get scoped path
	realPath, _, _ := idx.GetRealPath(fullIndexPath)

	if d.Share.Hash == "" {
		filePerms, permErr := effectiveFilePerms(d, source)
		if permErr != nil {
			return http.StatusForbidden, permErr
		}
		_, statErr := os.Stat(realPath)
		if status, gateErr := resourcePostPermCheck(statErr == nil, r.URL.Query().Get("override") == "true", filePerms); gateErr != nil {
			return status, gateErr
		}
	}

	if !state.AccessPermitted(idx.Path, utils.IndexPathFromNormalized(fullIndexPath, true), filePermUser.Username) {
		return http.StatusForbidden, fmt.Errorf("access denied to path %s", path)
	}

	// Check for file/folder conflicts before creation
	if stat, statErr := os.Stat(realPath); statErr == nil {
		// Path exists, check for type conflicts
		existingIsDir := stat.IsDir()
		requestingDir := isDir

		if r.URL.Query().Get("override") != "true" {
			return http.StatusConflict, nil
		}

		// If type mismatch (file vs folder or folder vs file) and not overriding
		if existingIsDir != requestingDir && r.URL.Query().Get("override") != "true" {
			logger.Debugf("Type conflict detected in chunked: existing is dir=%v, requesting dir=%v at path=%v", existingIsDir, requestingDir, realPath)
			return http.StatusConflict, nil
		}
	}

	// Directories creation on POST.
	if isDir {
		// Create a new FileOptions with the full index path
		dirOpts := fileOpts
		dirOpts.Path = fullIndexPath

		err = files.WriteDirectory(dirOpts)
		if err != nil {
			logger.Debugf("error writing directory: %v", err)
			return ErrToStatus(err), err
		}

		activity.RecordUpload(r, toActor(d), source, path, true)
		return http.StatusOK, nil
	}

	// Handle Chunked Uploads
	chunkOffsetStr := r.Header.Get("X-File-Chunk-Offset")
	if chunkOffsetStr != "" {
		var offset int64
		offset, err = strconv.ParseInt(chunkOffsetStr, 10, 64)
		if err != nil {
			logger.Debugf("invalid chunk offset: %v", err)
			return http.StatusBadRequest, fmt.Errorf("invalid chunk offset: %v", err)
		}

		var totalSize int64
		var hasTotalSize bool
		totalSize, hasTotalSize, err = parseUploadTotalSize(r)
		if err != nil {
			logger.Debugf("%v", err)
			return http.StatusBadRequest, err
		}
		if !hasTotalSize {
			return http.StatusBadRequest, fmt.Errorf("invalid total size: missing X-File-Total-Size")
		}
		if boundsErr := validateChunkBounds(offset, r.ContentLength, totalSize); boundsErr != nil {
			logger.Debugf("%v", boundsErr)
			return http.StatusBadRequest, boundsErr
		}

		sessionID, sessionErr := parseUploadSession(r)
		if sessionErr != nil {
			logger.Debugf("%v", sessionErr)
			return http.StatusBadRequest, sessionErr
		}
		if acquireErr := activeUploadSessions.acquire(realPath, sessionID); acquireErr != nil {
			if isUploadSessionConflict(acquireErr) {
				logger.Debugf("%v", acquireErr)
				abortConflictingUpload(w, r)
				return http.StatusConflict, acquireErr
			}
			logger.Debugf("%v", acquireErr)
			return http.StatusInternalServerError, acquireErr
		}
		quotaReserved := false
		quotaCtx := uploadQuotaContext(d, source, fullIndexPath, realPath, r, sessionID, totalSize, hasTotalSize)
		abandonSession := true
		defer func() {
			if abandonSession {
				activeUploadSessions.release(realPath, sessionID)
			}
			if quotaReserved && abandonSession {
				releaseUploadQuota(sessionID)
			}
		}()

		// On the first chunk, check quota and conflicts
		if offset == 0 {
			if quotaErr := checkUploadQuota(quotaCtx); quotaErr != nil {
				return renderQuotaError(w, r, quotaErr)
			}
			quotaReserved = true
			// Check for file/folder conflicts for chunked uploads
			if stat, statErr := os.Stat(realPath); statErr == nil {
				existingIsDir := stat.IsDir()
				requestingDir := false // Files are never directories

				// If type mismatch (existing dir vs requesting file) and not overriding
				if existingIsDir != requestingDir && r.URL.Query().Get("override") != "true" {
					logger.Debugf("Type conflict detected in chunked: existing is dir=%v, requesting dir=%v at path=%v", existingIsDir, requestingDir, realPath)
					abortConflictingUpload(w, r)
					return http.StatusConflict, nil
				}
			}

			var fileInfo *iteminfo.ExtendedFileInfo
			fileInfo, err = files.FileInfoFaster(fileOpts, filePermUser)
			if err == nil { // File exists
				if r.URL.Query().Get("override") != "true" {
					logger.Debugf("resource already exists: %v", fileInfo.RealPath)
					abortConflictingUpload(w, r)
					return http.StatusConflict, nil
				}
				// If overriding, delete existing thumbnails
				preview.DelThumbs(r.Context(), *fileInfo)
			}
		}

		// Use a temporary file for chunks.
		tempFilePath := uploadTempPath(realPath, sessionID)
		// Create or open the temporary file
		var outFile *os.File
		outFile, err = os.OpenFile(tempFilePath, os.O_CREATE|os.O_WRONLY, fileutils.PermFile)
		if err != nil {
			logger.Debugf("could not open temp file: %v", err)
			return http.StatusInternalServerError, fmt.Errorf("could not open temp file: %v", err)
		}
		defer outFile.Close()

		// Seek to the correct offset to write the chunk
		_, err = outFile.Seek(offset, 0)
		if err != nil {
			logger.Debugf("could not seek in temp file: %v", err)
			return http.StatusInternalServerError, fmt.Errorf("could not seek in temp file: %v", err)
		}

		// Write the request body (the chunk) to the file
		var chunkSize int64
		chunkSize, err = io.Copy(outFile, r.Body)
		if err != nil {
			logger.Debugf("could not write chunk to temp file: %v", err)

			gracefulPause := false
			if d.Share.Hash != "" {
				k := publicPauseUploadCacheKey(d.Share.Hash, source, path)
				if _, ok := publicPauseCache.Get(k); ok {
					gracefulPause = true
					publicPauseCache.Delete(k)
				}
			} else {
				k := pauseUploadCacheKey(source, path)
				if _, ok := pauseCache.Get(k); ok {
					gracefulPause = true
					pauseCache.Delete(k)
				}
			}

			if gracefulPause {
				if rollbackChunkForResume(outFile, tempFilePath, offset) {
					logger.Debugf("chunk upload ended after graceful pause; keeping partial file (source=%s path=%s)", source, path)
					abandonSession = false
					return 499, nil
				}
				return http.StatusInternalServerError, fmt.Errorf("could not write chunk to temp file: %v", err)
			}
			if rollbackChunkForResume(outFile, tempFilePath, offset) {
				logger.Debugf("chunk upload failed; keeping partial file for resume (source=%s path=%s offset=%d)", source, path, offset)
				abandonSession = false
			}
			return http.StatusInternalServerError, fmt.Errorf("could not write chunk to temp file: %v", err)
		}

		if err = validateReceivedBytes(chunkSize, 0, false, r.ContentLength); err != nil {
			logger.Debugf("incomplete chunk: %v", err)
			if rollbackChunkForResume(outFile, tempFilePath, offset) {
				abandonSession = false
			}
			return http.StatusBadRequest, err
		}

		if err = validateAssembledSize(offset, chunkSize, totalSize); err != nil {
			logger.Debugf("%v", err)
			if rollbackChunkForResume(outFile, tempFilePath, offset) {
				abandonSession = false
			}
			return http.StatusBadRequest, err
		}
		assembled := offset + chunkSize

		// Finalize only when the assembled size matches the declared total exactly.
		if assembled == totalSize {
			if syncErr := outFile.Sync(); syncErr != nil {
				logger.Debugf("could not sync temp file before finalize: %v", syncErr)
				return http.StatusInternalServerError, fmt.Errorf("could not sync temp file: %v", syncErr)
			}
			var info os.FileInfo
			info, err = outFile.Stat()
			if err != nil {
				logger.Debugf("could not stat temp file before finalize: %v", err)
				return http.StatusInternalServerError, fmt.Errorf("could not stat temp file: %v", err)
			}
			if info.Size() != totalSize {
				logger.Debugf("assembled file size mismatch: got %d want %d", info.Size(), totalSize)
				_ = os.Remove(tempFilePath)
				return http.StatusBadRequest, fmt.Errorf("upload incomplete: expected %d bytes, received %d", totalSize, info.Size())
			}
			// close file before moving
			outFile.Close()
			// Move the completed file from the temp location to the final destination
			err = files.MoveResource(false, source, source, tempFilePath, realPath)
			if err != nil {
				logger.Debugf("could not move file from %v to %v: %v", tempFilePath, realPath, err)
				abandonSession = false
				return http.StatusInternalServerError, fmt.Errorf("could not move file from chunked folder to destination: %v", err)
			}
			reconcileSharesAfterMove(false, source, source, tempFilePath, realPath)
			if commitErr := commitUploadQuotaAfterMove(quotaCtx); commitErr != nil {
				quotaReserved = false
				abandonSession = false
				return renderQuotaError(w, r, commitErr)
			}
			quotaReserved = false
			activity.RecordUpload(r, toActor(d), source, path, false)
			activeUploadSessions.release(realPath, sessionID)
			abandonSession = false
		}
		if err = writeChunkUploadResponse(w, assembled, totalSize, assembled == totalSize); err != nil {
			logger.Debugf("could not write chunk upload response: %v", err)
		}
		abandonSession = false
		return http.StatusOK, nil
	}

	fileInfo, err := files.FileInfoFaster(fileOpts, filePermUser)
	if err == nil { // File exists
		if r.URL.Query().Get("override") != "true" {
			logger.Debugf("resource already exists: %v", fileInfo.RealPath)
			return http.StatusConflict, nil
		}
		// If overriding, delete existing thumbnails
		preview.DelThumbs(r.Context(), *fileInfo)
	}

	if !isContentUpload(r) {
		err = files.WriteFile(fileOpts.Source, fullIndexPath, r.Body)
		if err != nil {
			logger.Debugf("error writing file: %v", err)
			return ErrToStatus(err), err
		}
		activity.RecordUpload(r, toActor(d), source, path, false)
		return http.StatusOK, nil
	}

	totalSize, hasTotalSize, err := parseUploadTotalSize(r)
	if err != nil {
		logger.Debugf("%v", err)
		return http.StatusBadRequest, err
	}

	// Write to a temp file, verify size, then move into place so truncated
	// uploads never leave a corrupt destination file.
	if err = os.MkdirAll(filepath.Dir(realPath), fileutils.EffectiveDirPerm()); err != nil {
		logger.Debugf("could not create parent directory: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("could not create parent directory: %v", err)
	}

	sessionID, sessionErr := parseUploadSession(r)
	if sessionErr != nil {
		logger.Debugf("%v", sessionErr)
		return http.StatusBadRequest, sessionErr
	}
	if acquireErr := activeUploadSessions.acquire(realPath, sessionID); acquireErr != nil {
		if isUploadSessionConflict(acquireErr) {
			logger.Debugf("%v", acquireErr)
			abortConflictingUpload(w, r)
			return http.StatusConflict, acquireErr
		}
		logger.Debugf("%v", acquireErr)
		return http.StatusInternalServerError, acquireErr
	}

	quotaCtx := uploadQuotaContext(d, source, fullIndexPath, realPath, r, sessionID, totalSize, hasTotalSize)
	quotaReserved := false
	abandonSession := true
	defer func() {
		if abandonSession {
			activeUploadSessions.release(realPath, sessionID)
		}
		if quotaReserved && abandonSession {
			releaseUploadQuota(sessionID)
		}
	}()

	if quotaErr := checkUploadQuota(quotaCtx); quotaErr != nil {
		return renderQuotaError(w, r, quotaErr)
	}
	quotaReserved = true

	tempFilePath := uploadTempPath(realPath, sessionID)
	outFile, err := os.OpenFile(tempFilePath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, fileutils.PermFile)
	if err != nil {
		logger.Debugf("could not open temp file: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("could not open temp file: %v", err)
	}

	written, copyErr := io.Copy(outFile, r.Body)
	closeErr := outFile.Close()
	if copyErr != nil {
		_ = os.Remove(tempFilePath)
		logger.Debugf("error writing file: %v", copyErr)
		return ErrToStatus(copyErr), copyErr
	}
	if closeErr != nil {
		_ = os.Remove(tempFilePath)
		logger.Debugf("error closing temp file: %v", closeErr)
		return http.StatusInternalServerError, closeErr
	}

	if err = validateReceivedBytes(written, totalSize, hasTotalSize, r.ContentLength); err != nil {
		_ = os.Remove(tempFilePath)
		logger.Debugf("%v", err)
		return http.StatusBadRequest, err
	}

	err = files.MoveResource(false, source, source, tempFilePath, realPath)
	if err != nil {
		_ = os.Remove(tempFilePath)
		logger.Debugf("error writing file: %v", err)
		return ErrToStatus(err), err
	}
	reconcileSharesAfterMove(false, source, source, tempFilePath, realPath)
	if commitErr := commitUploadQuotaAfterMove(quotaCtx); commitErr != nil {
		quotaReserved = false
		abandonSession = false
		return renderQuotaError(w, r, commitErr)
	}
	quotaReserved = false
	activity.RecordUpload(r, toActor(d), source, path, false)
	abandonSession = false
	return http.StatusOK, nil
}

// publicUploadHandler processes file uploads to a public upload share.
// @Summary Upload files to a public upload share
// @Description Handles file and directory uploads to an upload-only public share. Supports chunked uploads, conflict resolution (override), and directory creation.
// @Tags Resources
// @Accept multipart/form-data
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param path query string true "path within the share to upload to. Must be relative to share root."
// @Param override query bool false "If true, overwrite existing files/folders. Defaults to false."
// @Param action query string false "Upload action: 'override' to replace files, 'rename' to auto-rename"
// @Param file formData file true "File to upload"
// @Success 200 {object} map[string]string "Upload successful"
// @Failure 400 {object} map[string]string "Invalid request or parameters"
// @Failure 403 {object} map[string]string "Share unavailable or upload not allowed"
// @Failure 404 {object} map[string]string "Share not found"
// @Failure 409 {object} map[string]string "File or directory already exists (conflict)"
// @Failure 500 {object} map[string]string "Internal server error during upload"
// @Failure 501 {object} map[string]string "Uploading disabled for non-upload shares"
// @Router /public/api/resources [post]
func publicUploadHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if d.Share.ShareType != "upload" && !d.Share.AllowCreate {
		return http.StatusForbidden, fmt.Errorf("uploading is disabled for this share")
	}
	q := r.URL.Query()
	if !d.Share.AllowReplacements && (q.Get("action") == "override" || q.Get("override") == "true") {
		return http.StatusForbidden, fmt.Errorf("cannot overwrite files for this share")
	}
	sourceInfo, ok := settings.Config.Server.SourceMap[d.Share.SourcePath]
	if !ok {
		return http.StatusNotFound, fmt.Errorf("source not found")
	}
	source := sourceInfo.Name
	q.Set("source", source)
	q.Set("path", d.IndexPath)
	r.URL.RawQuery = q.Encode()
	status, err := ResourcePostHandler(w, r, d)
	if err != nil {
		logger.Errorf("public upload handler: error uploading with error %v", err)
		if status == 0 {
			status = http.StatusInternalServerError
		}
		return status, err
	}
	return status, nil
}

// resourcePutHandler updates an existing file resource.
// @Summary Update a file resource
// @Description Updates an existing file at the specified path.
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "Destination path where to place the files inside the destination source"
// @Param source query string true "Source name for the desired source, default is used if not provided"
// @Success 200 "Resource updated successfully"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Resource not found"
// @Failure 405 {object} map[string]string "Method not allowed"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/resources [put]
func resourcePutHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	source := r.URL.Query().Get("source")
	path := r.URL.Query().Get("path")

	// Rule 1: Validate user-provided path to prevent path traversal
	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, err
	}
	path = cleanPath
	filePerms, err := effectiveFilePerms(d, source)
	if err != nil {
		return http.StatusForbidden, err
	}
	if d.Share.Hash == "" && !filePerms.Modify {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to modify files in this source")
	}
	// Get user scope to resolve full index path for write operation
	userScope, err := d.User.GetScopeForSourceName(source)
	if err != nil {
		return http.StatusForbidden, err
	}
	fullIndexPath := utils.JoinScopedIndexPath(userScope, path)
	// Check access control for the target path
	idx := indexing.GetIndex(source)
	if idx == nil {
		return http.StatusNotFound, fmt.Errorf("source %s not found", source)
	}
	if idx.Config.ReadOnly {
		return http.StatusForbidden, fmt.Errorf("source is read-only")
	}
	if !state.AccessPermitted(idx.Path, utils.IndexPathFromNormalized(fullIndexPath, true), d.User.Username) {
		logger.Debugf("user %s denied access to path %s", d.User.Username, fullIndexPath)
		return http.StatusForbidden, fmt.Errorf("access denied to path %s", path)
	}

	// check if destination is a directory
	stat, err := os.Stat(filepath.Join(idx.Path + fullIndexPath))
	if err == nil && stat.IsDir() {
		return http.StatusMethodNotAllowed, errPutPathIsDirectory
	}

	return putResourceWithQuota(w, r, d, source, fullIndexPath)
}

// publicPutHandler handles the PUT request for a public share.
// @Summary Update a file in a public share
// @Description Updates the content of a file in a public share.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param path query string true "Path to the file to update"
// @Param content body string true "New content for the file"
// @Success 200 {object} map[string]string "File updated successfully"
// @Failure 400 {object} map[string]string "Invalid request or parameters"
// @Failure 403 {object} map[string]string "Share unavailable or update not allowed"
// @Failure 404 {object} map[string]string "Share not found or file not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /public/api/resources [put]
func publicPutHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.Share.AllowModify {
		return http.StatusForbidden, fmt.Errorf("edit permission not allowed for this share")
	}
	sourceName := d.Share.GetSourceName()
	if sourceName == "" {
		return http.StatusNotFound, fmt.Errorf("source not available")
	}
	path := r.URL.Query().Get("path")

	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, err
	}

	resolvedPath := utils.JoinScopedIndexPath(d.Share.Path, cleanPath)
	idx := indexing.GetIndex(sourceName)
	if idx == nil {
		return http.StatusNotFound, fmt.Errorf("source not found")
	}
	if idx.Config.ReadOnly {
		return http.StatusForbidden, fmt.Errorf("source is read-only")
	}
	return putResourceWithQuota(w, r, d, sourceName, resolvedPath)
}

// resourcePatchHandler performs a patch operation (e.g., move, copy, rename) on resources.
// @Summary Move, copy, or rename resources
// @Description Performs move, copy, or rename operations on multiple resources. All operations are performed atomically.
// @Tags Resources
// @Accept json
// @Produce json
// @Param request body MoveCopyRequest true "Move/copy request with items and action"
// @Success 200 {object} MoveCopyResponse "All operations completed successfully"
// @Success 207 {object} MoveCopyResponse "Partial success - some operations succeeded, some failed"
// @Failure 400 {object} map[string]string "Bad request - invalid JSON or parameters"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Resource not found"
// @Failure 500 {object} MoveCopyResponse "All operations failed"
// @Router /api/resources [patch]
func ResourcePatchHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	req, ok := d.Data.(MoveCopyRequest)
	if req.Action == "" || !ok {
		// Parse request body
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			return http.StatusBadRequest, fmt.Errorf("invalid JSON body: %v", err)
		}
	}

	if len(req.Items) == 0 {
		return http.StatusBadRequest, fmt.Errorf("items array cannot be empty")
	}

	if req.Action == "" {
		return http.StatusBadRequest, fmt.Errorf("action is required (copy, move, or rename)")
	}
	switch req.Action {
	case "copy", "move", "rename":
	default:
		return http.StatusBadRequest, fmt.Errorf("invalid action: %s (must be copy, move, or rename)", req.Action)
	}

	response := MoveCopyResponse{
		Succeeded: make([]MoveCopyItem, 0),
		Failed:    make([]MoveCopyItem, 0),
	}

	// Process each item
	for _, item := range req.Items {
		clientFromPath := item.FromPath
		clientToPath := item.ToPath

		// Validate all fields are provided
		if item.FromSource == "" || clientFromPath == "" || item.ToSource == "" || clientToPath == "" {
			item.Message = "fromSource, fromPath, toSource, and toPath are required"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}
		cleanFromPath, err := utils.SanitizePath(clientFromPath)
		if err != nil {
			item.Message = fmt.Sprintf("invalid fromPath: %v", err)
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}
		cleanToPath, err := utils.SanitizePath(clientToPath)
		if err != nil {
			item.Message = fmt.Sprintf("invalid toPath: %v", err)
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Get user scopes for both sources
		// For shares, paths are already absolute, so use empty scope
		userscopeSrc := ""
		userscopeDst := ""
		if d.Share.Hash == "" {
			userscopeSrc, err = d.User.GetScopeForSourceName(item.FromSource)
			if err != nil {
				item.Message = "source not available"
				response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
				continue
			}
			userscopeDst, err = d.User.GetScopeForSourceName(item.ToSource)
			if err != nil {
				item.Message = "destination source not available"
				response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
				continue
			}
			fromPerms, permErr := effectiveFilePerms(d, item.FromSource)
			if permErr != nil {
				item.Message = "permission denied"
				response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
				continue
			}
			toPerms := fromPerms
			if item.ToSource != item.FromSource {
				var toErr error
				toPerms, toErr = effectiveFilePerms(d, item.ToSource)
				if toErr != nil {
					item.Message = "permission denied"
					response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
					continue
				}
			}
			if msg := resourcePatchPermCheck(req.Action, item.FromSource, item.ToSource, fromPerms, toPerms); msg != "" {
				item.Message = msg
				response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
				continue
			}
		}

		// Get source index
		srcIdx := indexing.GetIndex(item.FromSource)
		if srcIdx == nil {
			item.Message = "source not found"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Get destination index
		dstIdx := indexing.GetIndex(item.ToSource)
		if dstIdx == nil {
			item.Message = "destination source not found"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		if srcIdx.Config.ReadOnly && req.Action == "move" {
			item.Message = "From source is read-only and cannot be moved"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		if dstIdx.Config.ReadOnly {
			item.Message = "destination source is read-only"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Build full index paths for access control
		fullSrcIndexPath := utils.JoinScopedIndexPath(userscopeSrc, cleanFromPath)
		fullDstIndexPath := utils.JoinScopedIndexPath(userscopeDst, cleanToPath)
		if fullDstIndexPath == "/" || fullSrcIndexPath == "/" {
			item.Message = "source or destination is the root or unautharized directory"
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Check access control for both source and destination paths
		if !state.AccessPermitted(srcIdx.Path, utils.IndexPathFromNormalized(fullSrcIndexPath, true), d.User.Username) {
			item.Message = "access denied to source path"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}
		if !state.AccessPermitted(dstIdx.Path, utils.IndexPathFromNormalized(fullDstIndexPath, true), d.User.Username) {
			item.Message = "access denied to destination path"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Get real paths (fullSrcIndexPath already includes user scope)
		realSrc, isSrcDir, err := srcIdx.GetRealPath(fullSrcIndexPath)
		if err != nil {
			logger.Errorf("could not resolve source path: %v, fromPath: %v", err, clientFromPath)
			item.Message = "could not resolve source path"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Check destination parent directory exists
		dstParentPath := filepath.Dir(cleanToPath)
		fullDstParentPath := utils.JoinScopedIndexPath(userscopeDst, dstParentPath)
		parentDir, _, err := dstIdx.GetRealPath(fullDstParentPath)
		if err != nil {
			item.Message = "destination directory does not exist"
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}
		realDest := parentDir + "/" + filepath.Base(cleanToPath)

		// Auto-rename if requested
		if req.Rename {
			realDest = addVersionSuffix(realDest)
		}

		// Validate move/rename operation to prevent circular references
		if req.Action == "rename" || req.Action == "move" {
			if err = validateMoveOperation(realSrc, realDest, isSrcDir); err != nil {
				item.Message = "invalid move operation, circular reference"
				if d.Share.Hash != "" {
					response.Failed = append(response.Failed, MoveCopyItem{
						Message: item.Message,
					})
					continue
				}
				response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
				continue
			}
		}

		overwriteBytes := int64(0)
		if !req.Rename {
			overwriteBytes = quota.OverwriteBytesAtPath(item.ToSource, fullDstIndexPath, isSrcDir)
		}
		patchSessionID := newQuotaSessionID()
		quotaCtx := copyMoveQuotaContext(
			d,
			req.Action,
			item.FromSource,
			item.ToSource,
			srcIdx.Path,
			dstIdx.Path,
			fullSrcIndexPath,
			fullDstIndexPath,
			isSrcDir,
			overwriteBytes,
			patchSessionID,
		)
		if quotaErr := checkCopyMoveQuota(quotaCtx); quotaErr != nil {
			if qe, ok := quota.AsError(quotaErr); ok {
				item.Message = qe.DisplayMessage()
			} else {
				item.Message = quotaErr.Error()
			}
			if d.Share.Hash != "" {
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		// Perform the action
		err = patchAction(r.Context(), patchActionParams{
			action:   req.Action,
			srcIndex: item.FromSource,
			dstIndex: item.ToSource,
			src:      realSrc,
			dst:      realDest,
			d:        d,
			isSrcDir: isSrcDir,
		})
		if err != nil {
			releaseCopyMoveQuota(patchSessionID)
			logger.Errorf("Could not run patch action. src=%v dst=%v err=%v", realSrc, realDest, err)
			if d.Share.Hash != "" {
				item.Message = "could not run patch action"
				response.Failed = append(response.Failed, MoveCopyItem{
					Message: item.Message,
				})
				continue
			}
			item.Message = err.Error()
			response.Failed = append(response.Failed, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
			continue
		}

		if commitErr := commitCopyMoveQuota(patchSessionID); commitErr != nil {
			logger.Warningf("quota commit after patch failed, retrying: %v", commitErr)
			if retryErr := state.ForceCommitSessionQuota(patchSessionID, 0); retryErr != nil {
				logger.Warningf("quota commit after patch failed: %v", retryErr)
			}
		}

		// Success
		response.Succeeded = append(response.Succeeded, moveCopyWithClientPaths(item, clientFromPath, clientToPath))
		activity.RecordPatchItem(r, toActor(d), req.Action, activity.MoveCopyItem{FromSource: item.FromSource, FromPath: clientFromPath, ToPath: clientToPath})
	}

	if len(response.Failed) == 0 && len(response.Succeeded) == 0 {
		response.Failed = append(response.Failed, MoveCopyItem{
			Message: "no operations performed",
		})
	}

	// For shares, sanitize the response to only include messages (hide paths)
	if d.Share.Hash != "" {
		sanitizedFailed := make([]MoveCopyItem, len(response.Failed))
		for i, item := range response.Failed {
			sanitizedFailed[i] = MoveCopyItem{
				Message: item.Message,
			}
		}
		response.Failed = sanitizedFailed

		// Clear succeeded items details for shares (only keep count implicitly via array length)
		sanitizedSucceeded := make([]MoveCopyItem, len(response.Succeeded))
		response.Succeeded = sanitizedSucceeded
	}

	// Determine status code based on results
	statusCode := http.StatusOK
	if len(response.Failed) > 0 && len(response.Succeeded) == 0 {
		// All operations failed - return 500 error
		statusCode = http.StatusInternalServerError
	} else if len(response.Failed) > 0 && len(response.Succeeded) > 0 {
		// Some succeeded, some failed - return 207 multi-status
		statusCode = http.StatusMultiStatus
	}
	// If all succeeded, statusCode remains 200 OK
	return RenderJSON(w, r, response, statusCode)
}

// publicPatchHandler performs a patch operation (e.g., move, copy, rename) on resources in a public share.
// @Summary Move, copy, or rename resources in a public share
// @Description Performs move, copy, or rename operations on multiple resources within a public share. All operations are performed atomically.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param request body MoveCopyRequest true "Move/copy request with items and action"
// @Success 200 {object} MoveCopyResponse "All operations completed successfully"
// @Success 207 {object} MoveCopyResponse "Partial success - some operations succeeded, some failed"
// @Failure 400 {object} map[string]string "Bad request - invalid JSON or parameters"
// @Failure 403 {object} map[string]string "Forbidden - modify not allowed for this share"
// @Failure 404 {object} map[string]string "Share or resource not found"
// @Failure 500 {object} MoveCopyResponse "Internal server error"
// @Router /public/api/resources [patch]
func publicPatchHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.Share.AllowModify {
		return http.StatusForbidden, fmt.Errorf("edit permission not allowed for this share")
	}

	sourceName := d.Share.GetSourceName()
	if sourceName == "" {
		return http.StatusNotFound, fmt.Errorf("source not available")
	}

	var shareCreatedByUser *users.User
	userValue, err := state.UserForShareOwner(d.Share)
	if err == nil {
		shareCreatedByUser = &userValue
	}
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("user for share no longer exists")
	}
	d.User = shareCreatedByUser

	var req MoveCopyRequest
	if err = json.NewDecoder(r.Body).Decode(&req); err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid JSON body: %v", err)
	}

	if req.Action == "" {
		return http.StatusBadRequest, fmt.Errorf("action is required (copy, move, or rename)")
	}

	for i := range req.Items {
		var sanitizedPath string
		sanitizedPath, err = utils.SanitizePath(req.Items[i].FromPath)
		if err != nil {
			return http.StatusBadRequest, fmt.Errorf("invalid from path: %w", err)
		}
		req.Items[i].FromSource = sourceName
		req.Items[i].FromPath = utils.JoinScopedIndexPath(d.Share.Path, sanitizedPath)
		sanitizedPath, err = utils.SanitizePath(req.Items[i].ToPath)
		if err != nil {
			return http.StatusBadRequest, fmt.Errorf("invalid to path: %w", err)
		}
		req.Items[i].ToSource = sourceName
		req.Items[i].ToPath = utils.JoinScopedIndexPath(d.Share.Path, sanitizedPath)
	}
	d.Data = req

	status, err := ResourcePatchHandler(w, r, d)
	if err != nil {
		logger.Errorf("public patch handler: error processing patch with error %v", err)
		return http.StatusInternalServerError, fmt.Errorf("an error occurred while processing the request")
	}

	return status, err
}

func addVersionSuffix(source string) string {
	counter := 1
	dir, name := path.Split(source)
	ext := filepath.Ext(name)
	base := strings.TrimSuffix(name, ext)
	for {
		if _, err := os.Stat(source); err != nil {
			break
		}
		renamed := fmt.Sprintf("%s(%d)%s", base, counter, ext)
		source = path.Join(dir, renamed)
		counter++
	}
	return source
}

type patchActionParams struct {
	action   string
	srcIndex string
	dstIndex string
	src      string
	dst      string
	d        *Context
	isSrcDir bool
}

func patchAction(ctx context.Context, params patchActionParams) error {
	switch params.action {
	case "copy":
		err := files.CopyResource(params.isSrcDir, params.srcIndex, params.dstIndex, params.src, params.dst)
		return err
	case "rename", "move":
		idx := indexing.GetIndex(params.srcIndex)
		srcPath := idx.MakeIndexPath(params.src, params.isSrcDir).String()
		userScope := ""
		userScope, _ = params.d.User.GetScopeForSourceName(params.srcIndex)
		if userScope != "" && userScope != "/" {
			// Strip the user scope from srcPath so FileInfoFaster doesn't double it
			srcPath = strings.TrimPrefix(srcPath, userScope)
		}

		fileInfo, err := files.FileInfoFaster(utils.FileOptions{
			FollowSymlinks: true,
			Path:           srcPath,
			Source:         params.srcIndex,
			IsDir:          params.isSrcDir,
			ShowHidden:     params.d.User.ShowHidden,
			HideFileExt:    params.d.User.HideFileExt,
		}, params.d.User)

		if err != nil {
			return err
		}

		// delete thumbnails
		preview.DelThumbs(ctx, *fileInfo)
		err = files.MoveResource(params.isSrcDir, params.srcIndex, params.dstIndex, params.src, params.dst)
		if err != nil {
			return err
		}
		reconcileSharesAfterMove(params.isSrcDir, params.srcIndex, params.dstIndex, params.src, params.dst)
		return nil
	default:
		return fmt.Errorf("unsupported action %s: %w", params.action, errors.ErrInvalidRequestParams)
	}
}

func inspectIndex(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Query().Get("path")
	source := r.URL.Query().Get("source")
	isNotDir := r.URL.Query().Get("isDir") == "false" // default to isDir true
	index := indexing.GetIndex(source)
	if index == nil {
		http.Error(w, "source not found", http.StatusNotFound)
		return
	}
	info, _ := index.GetReducedMetadata(path, !isNotDir)
	RenderJSON(w, r, info) // nolint:errcheck
}

func mockData(w http.ResponseWriter, r *http.Request) {
	d := r.URL.Query().Get("numDirs")
	f := r.URL.Query().Get("numFiles")
	NumDirs, err := strconv.Atoi(d)
	numFiles, err2 := strconv.Atoi(f)
	if err != nil || err2 != nil {
		return
	}
	// Optional explicit seed; 0 means derive deterministically from the shape.
	var seed int64
	if s := r.URL.Query().Get("seed"); s != "" {
		parsed, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return
		}
		seed = parsed
	}
	mockDir := indexing.CreateMockDataSeeded(NumDirs, numFiles, seed)
	RenderJSON(w, r, mockDir) // nolint:errcheck
}

// itemsGetHandler efficiently returns a basic list of items for a directory.
// @Summary Get directory items
// @Description Efficiently returns a basic list of items for the specified path and source. Use 'only' parameter to filter by only files or folders
// @Tags Resources
// @Accept json
// @Produce json
// @Param path query string true "A directory path to list child items"
// @Param source query string true "The source name which contains the path"
// @Param only query string false "Filter: 'files', 'folders', or omit for both"
// @Success 200 {object} files.Items "lists files and folders"
// @Failure 403 {object} map[string]string "Forbidden (access denied)"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/resources/items [get]
func itemsGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	source := r.URL.Query().Get("source")
	filePerms, err := effectiveFilePerms(d, source)
	if err != nil {
		return http.StatusForbidden, err
	}
	if !filePerms.View {
		return http.StatusForbidden, fmt.Errorf("user is not allowed to view files in this source")
	}
	items, err := files.GetDirItems(utils.FileOptions{
		FollowSymlinks: true,
		Path:           r.URL.Query().Get("path"),
		Source:         r.URL.Query().Get("source"),
		ShowHidden:     d.User.ShowHidden,
		Only:           r.URL.Query().Get("only"),
	}, d.User)
	if err != nil {
		if err == errors.ErrAccessDenied {
			return http.StatusForbidden, err
		}
		return http.StatusInternalServerError, err
	}
	return RenderJSON(w, r, items)
}

// publicItemsGetHandler efficiently returns a basic list of items for a directory in a public share.
// @Summary Get directory items (public share)
// @Description Efficiently returns a basic list of items for the specified path in a public share. Use hash for authentication instead of source. Use 'only' parameter to filter by only files or folders.
// @Tags Resources
// @Accept json
// @Produce json
// @Param hash query string true "Share hash for authentication"
// @Param path query string false "Path within the share to list child items. Defaults to share root."
// @Param only query string false "Filter: 'files', 'folders', or omit for both"
// @Success 200 {object} files.Items "lists files and folders"
// @Failure 403 {object} map[string]string "Forbidden (access denied)"
// @Failure 404 {object} map[string]string "Share not found or source not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /public/api/resources/items [get]
func publicItemsGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	sourceInfo, ok := settings.Config.Server.SourceMap[d.Share.SourcePath]
	if !ok {
		return http.StatusNotFound, fmt.Errorf("source not found")
	}
	items, err := files.GetDirItems(utils.FileOptions{
		FollowSymlinks: true,
		Path:           d.IndexPath,
		Source:         sourceInfo.Name,
		ShowHidden:     d.ShareUser.ShowHidden,
		Only:           r.URL.Query().Get("only"),
	}, d.ShareUser)
	if err != nil {
		if err == errors.ErrAccessDenied {
			return http.StatusForbidden, err
		}
		return http.StatusInternalServerError, err
	}
	return RenderJSON(w, r, items)
}

func moveCopyWithClientPaths(item MoveCopyItem, clientFrom, clientTo string) MoveCopyItem {
	item.FromPath = clientFrom
	item.ToPath = clientTo
	return item
}

func bulkDeleteActivityItems(items []BulkDeleteItem) []activity.BulkDeleteItem {
	out := make([]activity.BulkDeleteItem, len(items))
	for i, it := range items {
		out[i] = activity.BulkDeleteItem{Source: it.Source, Path: it.Path}
	}
	return out
}

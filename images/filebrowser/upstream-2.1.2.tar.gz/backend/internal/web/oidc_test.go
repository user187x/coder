package web

import (
	"encoding/json"
	"net/http/httptest"
	"reflect"
	"testing"

	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
)

func TestUserInfoUnmarshaller(t *testing.T) {
	tests := []struct {
		name        string
		jsonData    string
		groupsClaim string
		expected    userInfo
	}{
		{
			name:        "standard groups array",
			jsonData:    `{"name":"John","email":"john@example.com","groups":["admin","users"]}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":   "John",
					"email":  "john@example.com",
					"groups": []interface{}{"admin", "users"},
				},
				Groups: []string{"admin", "users"},
			},
		},
		{
			name:        "custom groups claim name",
			jsonData:    `{"name":"Jane","email":"jane@example.com","roles":["admin","users"]}`,
			groupsClaim: "roles",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":  "Jane",
					"email": "jane@example.com",
					"roles": []interface{}{"admin", "users"},
				},
				Groups: []string{"admin", "users"},
			},
		},
		{
			name:        "groups as comma-separated string",
			jsonData:    `{"name":"Bob","email":"bob@example.com","groups":"admin, users, guests"}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":   "Bob",
					"email":  "bob@example.com",
					"groups": "admin, users, guests",
				},
				Groups: []string{"admin", "users", "guests"},
			},
		},
		{
			name:        "no groups field",
			jsonData:    `{"name":"Alice","email":"alice@example.com"}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":  "Alice",
					"email": "alice@example.com",
				},
				Groups: nil,
			},
		},
		{
			name:        "empty groups array",
			jsonData:    `{"name":"Charlie","email":"charlie@example.com","groups":[]}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":   "Charlie",
					"email":  "charlie@example.com",
					"groups": []interface{}{},
				},
				Groups: []string{},
			},
		},
		{
			name:        "preferred_username and sub",
			jsonData:    `{"sub":"auth0|123","preferred_username":"jdoe","email":"jdoe@example.com"}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"sub":                "auth0|123",
					"preferred_username": "jdoe",
					"email":              "jdoe@example.com",
				},
				Groups: nil,
			},
		},
		{
			name:        "empty groups string",
			jsonData:    `{"name":"Dana","groups":""}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"name":   "Dana",
					"groups": "",
				},
				Groups: nil,
			},
		},
		{
			name:        "single group in array",
			jsonData:    `{"preferred_username":"single","groups":["admins"]}`,
			groupsClaim: "groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"preferred_username": "single",
					"groups":             []interface{}{"admins"},
				},
				Groups: []string{"admins"},
			},
		},
		{
			name:        "nested single-level claim",
			jsonData:    `{"username":"john","custom":{"groups":["admin","users"]}}`,
			groupsClaim: "custom.groups",
			expected: userInfo{
				Claims: map[string]interface{}{
					"username": "john",
					"custom": map[string]interface{}{
						"groups": []interface{}{"admin", "users"},
					},
				},
				Groups: []string{"admin", "users"},
			},
		},
		{
			name:        "keycloak resource_access nested structure",
			jsonData:    `{"sub":"user123","resource_access":{"filebrowser-client":{"roles":["admin","editor","viewer"]}}}`,
			groupsClaim: "resource_access.filebrowser-client.roles",
			expected: userInfo{
				Claims: map[string]interface{}{
					"sub": "user123",
					"resource_access": map[string]interface{}{
						"filebrowser-client": map[string]interface{}{
							"roles": []interface{}{"admin", "editor", "viewer"},
						},
					},
				},
				Groups: []string{"admin", "editor", "viewer"},
			},
		},
		{
			name:        "nested claim with single string value",
			jsonData:    `{"username":"bob","auth":{"group":"admin"}}`,
			groupsClaim: "auth.group",
			expected: userInfo{
				Claims: map[string]interface{}{
					"username": "bob",
					"auth": map[string]interface{}{
						"group": "admin",
					},
				},
				Groups: []string{"admin"},
			},
		},
		{
			name:        "invalid nested path returns empty groups",
			jsonData:    `{"username":"alice","custom":{"roles":["user"]}}`,
			groupsClaim: "custom.nonexistent.roles",
			expected: userInfo{
				Claims: map[string]interface{}{
					"username": "alice",
					"custom": map[string]interface{}{
						"roles": []interface{}{"user"},
					},
				},
				Groups: nil,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var userdata userInfo
			unmarshaller := &userInfoUnmarshaller{
				userInfo:    &userdata,
				groupsClaim: tt.groupsClaim,
			}

			err := json.Unmarshal([]byte(tt.jsonData), unmarshaller)
			if err != nil {
				t.Fatalf("Failed to unmarshal: %v", err)
			}

			if !reflect.DeepEqual(userdata, tt.expected) {
				t.Errorf("Expected %+v, got %+v", tt.expected, userdata)
			}
		})
	}
}

func TestUserInfoUnmarshaller_InvalidJSON(t *testing.T) {
	var userdata userInfo
	u := &userInfoUnmarshaller{userInfo: &userdata, groupsClaim: "groups"}
	err := json.Unmarshal([]byte(`{invalid json}`), u)
	if err == nil {
		t.Fatal("Unmarshal expected to fail on invalid JSON")
	}
}

func TestMergeMissingOidcClaims_PreservesIDTokenIdentifier(t *testing.T) {
	userdata := userInfo{
		Claims: map[string]any{"groups": []any{"admins"}},
		Groups: []string{"admins"},
	}
	idTokenClaims := map[string]any{
		"preferred_username": "alice",
		"sub":                "user-123",
	}

	mergeMissingOidcClaims(&userdata, idTokenClaims)

	if userdata.Claims["preferred_username"] != "alice" {
		t.Fatalf("preferred_username = %v, want alice", userdata.Claims["preferred_username"])
	}
	if userdata.Claims["sub"] != "user-123" {
		t.Fatalf("sub = %v, want user-123", userdata.Claims["sub"])
	}
	if _, ok := userdata.Claims["groups"]; !ok {
		t.Fatal("UserInfo groups claim should be preserved")
	}
}

func TestMergeMissingOidcClaims_UserInfoWinsOnConflict(t *testing.T) {
	userdata := userInfo{
		Claims: map[string]any{"email": "from-userinfo@example.com"},
	}
	idTokenClaims := map[string]any{"email": "from-idtoken@example.com"}

	mergeMissingOidcClaims(&userdata, idTokenClaims)

	if userdata.Claims["email"] != "from-userinfo@example.com" {
		t.Fatalf("email = %v, want UserInfo value preserved", userdata.Claims["email"])
	}
}

func TestOidcRedirectURLTrustProxyHeaders(t *testing.T) {
	settings.Config.Http.BaseURL = "/"
	settings.Config.Http.TrustProxyHeaders = true
	t.Cleanup(func() {
		settings.Config.Http.BaseURL = "/"
		settings.Config.Http.TrustProxyHeaders = false
	})

	req := httptest.NewRequest("GET", "http://127.0.0.1:8080/api/auth/oidc/login", nil)
	req.Host = "127.0.0.1:8080"
	req.Header.Set("X-Forwarded-Proto", "https")
	req.Header.Set("X-Forwarded-Host", "filebrowser.example.com")

	got := OidcRedirectURL(req)
	want := "https://filebrowser.example.com/api/auth/oidc/callback"
	if got != want {
		t.Fatalf("OidcRedirectURL = %q, want %q", got, want)
	}
}

func TestOidcRedirectURLWithoutTrustProxyHeaders(t *testing.T) {
	settings.Config.Http.BaseURL = "/files/"
	settings.Config.Http.TrustProxyHeaders = false
	t.Cleanup(func() {
		settings.Config.Http.BaseURL = "/"
		settings.Config.Http.TrustProxyHeaders = false
	})

	req := httptest.NewRequest("GET", "http://filebrowser.example.com/files/api/auth/oidc/login", nil)
	req.Host = "filebrowser.example.com"
	req.Header.Set("X-Forwarded-Proto", "https")
	req.Header.Set("X-Forwarded-Host", "spoofed.example.com")

	got := OidcRedirectURL(req)
	want := "http://filebrowser.example.com/files/api/auth/oidc/callback"
	if got != want {
		t.Fatalf("OidcRedirectURL = %q, want %q", got, want)
	}
}

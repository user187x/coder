package web

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/gtsteffaniak/filebrowser/backend/internal/activity"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/access"
	activitydb "github.com/gtsteffaniak/filebrowser/backend/internal/database/activity"
	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
	"github.com/gtsteffaniak/filebrowser/backend/internal/state"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing"
	"github.com/gtsteffaniak/go-logger/logger"
)

type GroupListResponse struct {
	Groups []string `json:"groups"`
	// Members maps group name to usernames; only set when ?members=true.
	Members map[string][]string `json:"members,omitempty"`
}

// parseAccessQueryPath validates and parses an index path from an API query parameter.
func parseAccessQueryPath(path string) (utils.IndexPath, error) {
	if path == "" {
		return utils.IndexPath{}, fmt.Errorf("path is required")
	}
	return utils.ParseSanitizedIndexPath(path, true)
}

// parseAccessQueryPathOrBadRequest wraps parseAccessQueryPath with a standard HTTP 400 response.
func parseAccessQueryPathOrBadRequest(path string) (utils.IndexPath, int, error) {
	parsed, err := parseAccessQueryPath(path)
	if err != nil {
		return utils.IndexPath{}, http.StatusBadRequest, err
	}
	return parsed, 0, nil
}

// accessGetHandler lists all access rules or retrieves a specific rule.
// @Summary List access rules
// @Description Lists access rules. Can be filtered by source, path, user, or group. Can also be grouped by user or group.
// @Tags Access
// @Accept json
// @Produce json
// @Param source query string false "Source name (e.g. 'default')"
// @Param path query string false "Index path (e.g. /secret)"
// @Param user query string false "Username to filter rules for"
// @Param group query string false "Group name to filter rules for"
// @Success 200 {object} object "Varies based on query. Can be access.FrontendAccessRule (when source and path specified), []access.PrincipalRule, map[string][]access.PrincipalRule, or map[string]access.FrontendAccessRule"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/access [get]
func accessGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	sourceName := r.URL.Query().Get("source")
	indexPath := r.URL.Query().Get("path")
	user := r.URL.Query().Get("user")
	group := r.URL.Query().Get("group")

	var sourcePath string
	if sourceName != "" {
		index := indexing.GetIndex(sourceName)
		if index == nil {
			return http.StatusBadRequest, fmt.Errorf("source not found: %s", sourceName)
		}
		sourcePath = index.Path
	}

	// Return rules based on input parameters
	if user != "" {
		rules := state.GetRulesForUser(sourcePath, user)
		return RenderJSON(w, r, rules)
	}
	if group != "" {
		rules := state.GetRulesForGroup(sourcePath, group)
		return RenderJSON(w, r, rules)
	}

	if sourceName == "" {
		logger.Warningf("api access GET: empty source query (user=%q admin=%v path=%q userQ=%q groupQ=%q)",
			d.User.Username, d.User.Permissions.Admin, indexPath, user, group)
		return http.StatusBadRequest, fmt.Errorf("source parameter is required for this query")
	}

	if indexPath != "" {
		parsedPath, status, err := parseAccessQueryPathOrBadRequest(indexPath)
		if err != nil {
			return status, err
		}
		rule, _ := state.GetFrontendRules(sourcePath, parsedPath)
		return RenderJSON(w, r, rule)
	}

	// List all rules for the source by default
	all, err := state.GetAllRules(sourcePath)
	if err != nil {
		logger.Errorf("failed to retrieve access rules: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("failed to retrieve access rules: %w", err)
	}
	return RenderJSON(w, r, all)
}

// accessPostHandler adds or updates an access rule.
// @Summary Add or update access rule
// @Description Add or update an access rule for a sourcePath and indexPath.
// @Tags Access
// @Accept json
// @Produce json
// @Param source query string true "Source path prefix (e.g. mnt/storage)"
// @Param path query string true "Index path (e.g. /secret)"
// @Param body body object{allow=bool,ruleCategory=string,value=string} true "Rule details: allow (true/false), ruleCategory (user/group), value (username or groupname)"
// @Success 200 {object} map[string]string "Rule added or updated"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/access [post]
func accessPostHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	sourceName := r.URL.Query().Get("source")
	indexPath := r.URL.Query().Get("path")
	index := indexing.GetIndex(sourceName)
	if index == nil {
		return http.StatusBadRequest, fmt.Errorf("source not found: %s", sourceName)
	}
	var body struct {
		Allow        bool   `json:"allow"`
		RuleCategory string `json:"ruleCategory"`
		Value        string `json:"value"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid request body: %w", err)
	}

	body.Value = strings.TrimSpace(body.Value)
	if indexPath == "" || body.RuleCategory == "" || (body.RuleCategory != "all" && body.Value == "") {
		return http.StatusBadRequest, fmt.Errorf("path, ruleCategory, and value are required, unless ruleCategory is 'all'")
	}
	parsedPath, status, err := parseAccessQueryPathOrBadRequest(indexPath)
	if err != nil {
		return status, err
	}
	if body.RuleCategory == "user" {
		if _, err = state.GetUserByUsername(body.Value); err != nil {
			if err == errors.ErrNotExist {
				return http.StatusBadRequest, fmt.Errorf("user not found: %s", body.Value)
			}
			return http.StatusInternalServerError, fmt.Errorf("failed to look up user: %w", err)
		}
	}
	if body.RuleCategory == "group" && !state.GroupExists(body.Value) {
		return http.StatusBadRequest, fmt.Errorf("group not found: %s", body.Value)
	}
	if body.Allow {
		switch body.RuleCategory {
		case "user":
			err = state.AllowUser(index.Path, parsedPath, body.Value)
		case "group":
			err = state.AllowGroup(index.Path, parsedPath, body.Value)
		default:
			return http.StatusBadRequest, fmt.Errorf("invalid ruleCategory: must be 'user' or 'group'")
		}
	} else {
		switch body.RuleCategory {
		case "user":
			err = state.DenyUser(index.Path, parsedPath, body.Value)
		case "group":
			err = state.DenyGroup(index.Path, parsedPath, body.Value)
		case "all":
			err = state.DenyAll(index.Path, parsedPath)
		default:
			return http.StatusBadRequest, fmt.Errorf("invalid ruleCategory: must be 'user', 'group', or 'all'")
		}
	}
	if err != nil {
		if err == errors.ErrExist {
			return http.StatusConflict, fmt.Errorf("rule already contains this entry")
		}
		logger.Errorf("failed to add or update rule: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("failed to add or update rule: %w", err)
	}
	activity.RecordAccessCreate(r, toActor(d), sourceName, parsedPath.String(), activity.AccessRuleCreateChanges(body.Allow, body.RuleCategory, body.Value))
	return RenderJSON(w, r, map[string]string{"message": "rule added or updated"})
}

// accessDeleteHandler deletes a single user or group from a rule.
// @Summary Delete access rule entry
// @Description Delete a user or group from an allow or deny list for a sourcePath and indexPath. When cascade=true, removes the user/group from the specified path and all subpaths.
// @Tags Access
// @Accept json
// @Produce json
// @Param source query string true "Source path prefix (e.g. mnt/storage)"
// @Param path query string true "Index path (e.g. /secret)"
// @Param ruleType query string true "Rule type (allow or deny)"
// @Param ruleCategory query string true "Rule category (user or group)"
// @Param value query string true "Username or groupname to remove"
// @Param cascade query boolean false "Cascade delete to all subpaths (default: false)"
// @Success 200 {object} map[string]string "Rule entry deleted"
// @Failure 404 {object} map[string]string "Not found"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/access [delete]
func accessDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	sourceName := r.URL.Query().Get("source")
	indexPath := r.URL.Query().Get("path")
	index := indexing.GetIndex(sourceName)
	if index == nil {
		return http.StatusBadRequest, fmt.Errorf("source not found: %s", sourceName)
	}

	ruleType := r.URL.Query().Get("ruleType")
	ruleCategory := r.URL.Query().Get("ruleCategory")
	value := strings.TrimSpace(r.URL.Query().Get("value"))
	cascade := r.URL.Query().Get("cascade") == "true"
	allow := ruleType == "allow"

	if indexPath == "" || ruleCategory == "" || (ruleCategory != "all" && value == "") {
		return http.StatusBadRequest, fmt.Errorf("path, ruleCategory, and value are required, unless ruleCategory is 'all'")
	}
	parsedPath, status, err := parseAccessQueryPathOrBadRequest(indexPath)
	if err != nil {
		return status, err
	}

	// Handle cascade delete
	if cascade {
		if ruleCategory == "all" {
			return http.StatusBadRequest, fmt.Errorf("cascade delete is not supported for 'all' rule category")
		}

		var count int

		switch ruleCategory {
		case "user":
			count, err = state.RemoveUserCascade(index.Path, parsedPath, value, allow)
		case "group":
			count, err = state.RemoveGroupCascade(index.Path, parsedPath, value, allow)
		default:
			return http.StatusBadRequest, fmt.Errorf("invalid ruleCategory for cascade delete: must be 'user' or 'group'")
		}

		if err != nil {
			logger.Errorf("failed to cascade delete rule entry: %v", err)
			return http.StatusInternalServerError, fmt.Errorf("failed to cascade delete rule entry: %w", err)
		}

		if count == 0 {
			return http.StatusNotFound, fmt.Errorf("no entries found in rule hierarchy")
		}

		activity.RecordAccessDelete(r, toActor(d), sourceName, parsedPath.String(), activity.AccessRuleDeleteChanges(ruleType, ruleCategory, value, true, count))
		return RenderJSON(w, r, map[string]interface{}{
			"message": "rule entries deleted",
			"count":   count,
		})
	}

	// Handle non-cascade delete (original behavior)
	var found bool
	if allow {
		switch ruleCategory {
		case "user":
			found, err = state.RemoveAllowUser(index.Path, parsedPath, value)
		case "group":
			found, err = state.RemoveAllowGroup(index.Path, parsedPath, value)
		default:
			return http.StatusBadRequest, fmt.Errorf("invalid ruleCategory for allow list: must be 'user' or 'group'")
		}
	} else {
		switch ruleCategory {
		case "user":
			found, err = state.RemoveDenyUser(index.Path, parsedPath, value)
		case "group":
			found, err = state.RemoveDenyGroup(index.Path, parsedPath, value)
		case "all":
			found, err = state.RemoveDenyAll(index.Path, parsedPath)
		default:
			return http.StatusBadRequest, fmt.Errorf("invalid ruleCategory: must be 'user', 'group', or 'all'")
		}
	}
	if err != nil {
		logger.Errorf("failed to remove rule entry: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("failed to remove rule entry: %w", err)
	}
	if !found {
		return http.StatusNotFound, fmt.Errorf("entry not found in rule")
	}

	activity.RecordAccessDelete(r, toActor(d), sourceName, parsedPath.String(), activity.AccessRuleDeleteChanges(ruleType, ruleCategory, value, false, 0))
	return RenderJSON(w, r, map[string]string{"message": "rule entry deleted"})
}

// groupGetHandler retrieves all groups or groups for a specific user.
// @Summary Get all groups or groups for a user
// @Description Returns a list of all groups or the groups for a specific user.
// @Tags Access
// @Accept json
// @Produce json
// @Param user query string false "User name"
// @Param members query bool false "Also return each group's member list (ignored when user is set)"
// @Success 200 {object} GroupListResponse "Object containing a list of groups"
// @Failure 403 {object} map[string]string "Forbidden"
// @Router /api/access/groups [get]
func groupGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.User.Permissions.Admin {
		return http.StatusForbidden, nil
	}
	user := r.URL.Query().Get("user")
	if user != "" {
		if _, err := state.GetUserByUsername(user); err != nil {
			if err == errors.ErrNotExist {
				return http.StatusNotFound, fmt.Errorf("user not found: %s", user)
			}
			return http.StatusInternalServerError, fmt.Errorf("failed to look up user: %w", err)
		}
		groups := state.GetUserGroups(user)
		return RenderJSON(w, r, &GroupListResponse{Groups: groups})
	}
	groups := state.GetAllGroups()
	resp := &GroupListResponse{Groups: groups}
	if r.URL.Query().Get("members") == "true" {
		resp.Members = state.GetGroupMembers()
	}
	return RenderJSON(w, r, resp)
}

// groupPostHandler adds a user to a group.
// @Summary Add a user to a group
// @Description Adds a user to a group.
// @Tags Access
// @Accept json
// @Produce json
// @Param group query string true "Group name"
// @Param user query string true "User name"
// @Success 200 "User added to group successfully"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 500 {object} map[string]string "Internal Server Error"
// @Router /api/access/group [post]
func groupPostHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.User.Permissions.Admin {
		return http.StatusForbidden, nil
	}
	group := strings.TrimSpace(r.URL.Query().Get("group"))
	if group == "" {
		return http.StatusBadRequest, fmt.Errorf("group is required")
	}
	// Strict naming applies only to newly created groups; existing names always work.
	if !state.GroupExists(group) {
		if _, err := access.NormalizeGroupName(group); err != nil {
			return http.StatusBadRequest, err
		}
	}
	user := strings.TrimSpace(r.URL.Query().Get("user"))
	if user == "" {
		return http.StatusBadRequest, fmt.Errorf("user is required")
	}
	if _, err := state.GetUserByUsername(user); err != nil {
		if err == errors.ErrNotExist {
			return http.StatusBadRequest, fmt.Errorf("user not found: %s", user)
		}
		return http.StatusInternalServerError, fmt.Errorf("failed to look up user: %w", err)
	}
	if err := state.AddUserToGroup(group, user); err != nil {
		return http.StatusInternalServerError, err
	}
	return RenderJSON(w, r, map[string]string{"message": "user added to group"})
}

// groupPutHandler creates a group or replaces its membership.
// @Summary Create or update a group
// @Description Creates the group if missing and replaces its member list. When create is true, a group that already exists returns 409.
// @Tags Access
// @Accept json
// @Produce json
// @Param body body object{group=string,members=[]string,create=bool} true "Group name and full member list"
// @Success 200 {object} object "Group saved; unknownMembers lists usernames with no matching local user"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 409 {object} map[string]string "Conflict (group already exists when create is true)"
// @Router /api/access/group [put]
func groupPutHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.User.Permissions.Admin {
		return http.StatusForbidden, nil
	}
	var body struct {
		Group   string   `json:"group"`
		Members []string `json:"members"`
		Create  bool     `json:"create"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
	}
	defer r.Body.Close()
	name := strings.TrimSpace(body.Group)
	if name == "" {
		return http.StatusBadRequest, fmt.Errorf("group is required")
	}
	// Strict naming applies only to newly created groups; existing names always work.
	if !state.GroupExists(name) {
		if _, err := access.NormalizeGroupName(name); err != nil {
			return http.StatusBadRequest, err
		}
	}
	if body.Create && state.GroupExists(name) {
		return http.StatusConflict, fmt.Errorf("group already exists: %s", name)
	}
	members := access.NormalizeMembers(body.Members)
	var unknownMembers []string
	for _, member := range members {
		if _, err := state.GetUserByUsername(member); err != nil {
			if err != errors.ErrNotExist {
				return http.StatusInternalServerError, fmt.Errorf("failed to look up user: %w", err)
			}
			unknownMembers = append(unknownMembers, member)
		}
	}
	if err := state.SetGroupMembers(name, members); err != nil {
		return http.StatusInternalServerError, err
	}
	resp := map[string]interface{}{"message": "group saved"}
	if len(unknownMembers) > 0 {
		resp["unknownMembers"] = unknownMembers
	}
	return RenderJSON(w, r, resp)
}

// groupDeleteHandler removes a user from a group, or deletes the group when no user is given.
// @Summary Remove a user from a group or delete a group
// @Description Removes a user from a group. When the user parameter is omitted, deletes the whole group and removes it from all access rules.
// @Tags Access
// @Accept json
// @Produce json
// @Param group query string true "Group name"
// @Param user query string false "User name"
// @Success 200 "User removed from group successfully"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 500 {object} map[string]string "Internal Server Error"
// @Router /api/access/group [delete]
func groupDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.User.Permissions.Admin {
		return http.StatusForbidden, nil
	}
	group := strings.TrimSpace(r.URL.Query().Get("group"))
	user := strings.TrimSpace(r.URL.Query().Get("user"))
	if group == "" {
		return http.StatusBadRequest, fmt.Errorf("group is required")
	}
	if user == "" {
		// No user given: delete the whole group and its access rule entries.
		if err := state.DeleteGroup(group); err != nil {
			return http.StatusInternalServerError, err
		}
		return RenderJSON(w, r, map[string]string{"message": "group deleted"})
	}
	err := state.RemoveUserFromGroup(group, user)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	return RenderJSON(w, r, map[string]string{"message": "user removed from group"})
}

// userGroupsPutHandler atomically replaces a user's group memberships.
// @Summary Replace a user's group memberships
// @Description Replaces all of a user's group memberships in one request. Every group in the list must already exist.
// @Tags Access
// @Accept json
// @Produce json
// @Param body body object{user=string,groups=[]string} true "Username and full group list"
// @Success 200 {object} map[string]string "User groups updated"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 404 {object} map[string]string "User not found"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/access/user-groups [put]
func userGroupsPutHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	if !d.User.Permissions.Admin {
		return http.StatusForbidden, nil
	}
	var body struct {
		User   string   `json:"user"`
		Groups []string `json:"groups"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
	}
	defer r.Body.Close()
	user := strings.TrimSpace(body.User)
	if user == "" {
		return http.StatusBadRequest, fmt.Errorf("user is required")
	}
	if _, err := state.GetUserByUsername(user); err != nil {
		if err == errors.ErrNotExist {
			return http.StatusNotFound, fmt.Errorf("user not found: %s", user)
		}
		return http.StatusInternalServerError, fmt.Errorf("failed to look up user: %w", err)
	}
	groups := access.NormalizeMembers(body.Groups)
	var unknown []string
	for _, g := range groups {
		if !state.GroupExists(g) {
			unknown = append(unknown, g)
		}
	}
	if len(unknown) > 0 {
		return http.StatusBadRequest, fmt.Errorf("unknown groups: %s", strings.Join(unknown, ", "))
	}
	if err := state.SyncUserGroups(user, groups); err != nil {
		return http.StatusInternalServerError, fmt.Errorf("failed to update user groups: %w", err)
	}
	return RenderJSON(w, r, map[string]string{"message": "user groups updated"})
}

// accessPatchHandler updates an access rule's path.
// @Summary Update access rule path
// @Description Updates the path for a specific access rule
// @Tags Access
// @Accept json
// @Produce json
// @Param body body object{source=string,oldPath=string,newPath=string} true "Source, old path, and new path"
// @Success 200 {object} map[string]string "Rule path updated successfully"
// @Failure 400 {object} map[string]string "Bad request - missing or invalid parameters"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/access [patch]
func accessPatchHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	var body struct {
		Source  string `json:"source"`
		OldPath string `json:"oldPath"`
		NewPath string `json:"newPath"`
	}

	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
	}
	defer r.Body.Close()

	if body.Source == "" || body.OldPath == "" || body.NewPath == "" {
		return http.StatusBadRequest, fmt.Errorf("source, oldPath, and newPath are required")
	}

	// Get the index for the source
	index := indexing.GetIndex(body.Source)
	if index == nil {
		return http.StatusBadRequest, fmt.Errorf("source not found: %s", body.Source)
	}

	oldPath, status, err := parseAccessQueryPathOrBadRequest(body.OldPath)
	if err != nil {
		return status, err
	}
	newPath, status, err := parseAccessQueryPathOrBadRequest(body.NewPath)
	if err != nil {
		return status, err
	}

	err = state.UpdateRulePath(index.Path, oldPath, newPath)
	if err != nil {
		logger.Errorf("failed to update rule path: %v", err)
		return http.StatusInternalServerError, fmt.Errorf("failed to update rule path: %w", err)
	}

	activity.RecordAccessUpdate(r, toActor(d), body.Source, newPath.String(), []activitydb.FieldChange{
		{Field: "oldPath", From: oldPath.String(), To: newPath.String()},
	})

	return RenderJSON(w, r, map[string]string{"message": "rule path updated"})
}

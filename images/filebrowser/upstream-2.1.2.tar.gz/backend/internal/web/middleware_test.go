package web

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"

	"github.com/gtsteffaniak/filebrowser/backend/internal/app"
	"github.com/gtsteffaniak/filebrowser/backend/internal/auth"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/share"
	_ "github.com/gtsteffaniak/filebrowser/backend/internal/database/sqldb" // Import to register SQL driver
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/filebrowser/backend/internal/state"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing/iteminfo"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"golang.org/x/crypto/bcrypt"
)

func setupTestEnv(t *testing.T) {
	utils.BcryptCost = bcrypt.MinCost
	dbPath := filepath.Join(t.TempDir(), "test.sqlite")

	// Initialize state with SQLite database
	_, err := state.Initialize(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	app.MustWireServices(state.Default())
	t.Cleanup(func() {
		state.Close()
	})

	settings.Config.Server.SourceMap = map[string]*settings.Source{
		"/srv": {
			Path: "/srv",
			Name: "srv",
		},
	}
	settings.Config.Server.NameToSource = map[string]*settings.Source{
		"srv": {
			Path: "/srv",
			Name: "srv",
		},
	}
	// Initialize user resolvers so users package can resolve source names
	settings.InitializeUserResolvers()
	mockFileInfoFaster(t) // Mock FileInfoFasterFunc for this test
}

func testSessionToken(t *testing.T, user *users.User, duration time.Duration) string {
	t.Helper()
	if duration == 0 {
		duration = time.Hour * 2
	}
	tokenString, _, err := auth.MakeSignedTokenAPI(user, "WEB_TOKEN_"+utils.InsecureRandomIdentifier(4), duration, user.Permissions, true)
	if err != nil {
		t.Fatalf("MakeSignedTokenAPI: %v", err)
	}
	if err := state.RegisterSessionToken(tokenString, user.ID); err != nil {
		t.Fatalf("RegisterSessionToken: %v", err)
	}
	return tokenString
}

func mockFileInfoFaster(t *testing.T) {
	// Backup the original function
	originalFileInfoFaster := FileInfoFasterFunc
	// Defer restoration of the original function
	t.Cleanup(func() { FileInfoFasterFunc = originalFileInfoFaster })

	// Mock the function to skip execution
	FileInfoFasterFunc = func(opts utils.FileOptions, user *users.User) (*iteminfo.ExtendedFileInfo, error) {
		return &iteminfo.ExtendedFileInfo{
			FileInfo: iteminfo.FileInfo{
				Path: opts.Path,
				ItemInfo: iteminfo.ItemInfo{
					Name: "mocked_file",
					Size: 12345,
				},
			},
		}, nil
	}
}

func TestWithAdminHelper(t *testing.T) {
	setupTestEnv(t)
	// Mock a user who has admin permissions
	adminUser := &users.User{
		ID: 1,
		FrontendUser: users.FrontendUser{
			Username:    "admin",
			Permissions: users.Permissions{Admin: true}, // Ensure the user is an admin
		},
	}
	nonAdminUser := &users.User{
		ID: 2,
		FrontendUser: users.FrontendUser{
			Username:    "non-admin",
			Permissions: users.Permissions{Admin: false}, // Non-admin user
		},
	}
	// Save the users to the mock database
	if err := state.CreateUser(adminUser, ""); err != nil {
		t.Fatal("failed to create admin user:", err)
	}
	// CreateUser runs ApplyUserDefaults, which replaces permissions from global UserDefaults.
	adminUser.Permissions = users.Permissions{Admin: true}
	if err := state.UpdateUser(adminUser, "", "permissions"); err != nil {
		t.Fatal("failed to set admin permissions:", err)
	}
	if err := state.CreateUser(nonAdminUser, ""); err != nil {
		t.Fatal("failed to create non-admin user:", err)
	}
	nonAdminUser.Permissions = users.Permissions{Admin: false}
	if err := state.UpdateUser(nonAdminUser, "", "permissions"); err != nil {
		t.Fatal("failed to set non-admin permissions:", err)
	}
	// Test cases for different scenarios
	testCases := []struct {
		name               string
		expectedStatusCode int
		user               *users.User
	}{
		{
			name:               "Admin access allowed",
			expectedStatusCode: http.StatusOK, // Admin should be able to access
			user:               adminUser,
		},
		{
			name:               "Non-admin access forbidden",
			expectedStatusCode: http.StatusForbidden, // Non-admin should be forbidden
			user:               nonAdminUser,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			tokenString := testSessionToken(t, tc.user, time.Hour*2)

			handler := withAdmin(mockHandler)

			recorder := httptest.NewRecorder()
			req, err := http.NewRequest(http.MethodGet, "/users", http.NoBody)
			if err != nil {
				t.Fatalf("Error creating request: %v", err)
			}
			req.AddCookie(&http.Cookie{
				Name:  "filebrowser_quantum_jwt",
				Value: tokenString,
			})

			handler(recorder, req)

			if recorder.Code != tc.expectedStatusCode {
				t.Errorf("\"%v\" expected status code %d, got %d", tc.name, tc.expectedStatusCode, recorder.Code)
			}
		})
	}
}

func TestPublicShare_RejectsRevokedJWT(t *testing.T) {
	setupTestEnv(t)

	victim := &users.User{
		FrontendUser: users.FrontendUser{
			Username:    "victim",
			Permissions: users.Permissions{Api: true},
		},
		BackendScopes: []users.BackendScope{
			{Path: "/srv", Scope: "/"},
		},
	}
	if err := state.CreateUser(victim, ""); err != nil {
		t.Fatal("failed to create victim user:", err)
	}
	victim.Permissions = users.Permissions{Api: true}
	if err := state.UpdateUser(victim, "", "permissions"); err != nil {
		t.Fatal("failed to set victim permissions:", err)
	}

	originalAuthKey := settings.Config.Auth.Key
	settings.Config.Auth.Key = "key"
	t.Cleanup(func() { settings.Config.Auth.Key = originalAuthKey })

	tokenString := testSessionToken(t, victim, time.Hour*2)

	shareLink := &share.Share{
		ShareSettings: share.ShareSettings{
			ShareLimits: share.ShareLimits{
				SourceName:       "srv",
				AllowedUsernames: []string{"victim"},
			},
		},
		ShareColumns: share.ShareColumns{
			Hash: "revoked_jwt_hash",
			Path: "/",
		},
		SourcePath: "/srv",
		UserID:     victim.ID,
	}
	if err := state.CreateShare(shareLink); err != nil {
		t.Fatal("failed to create share:", err)
	}

	handler := withHashFile(publicGetResourceHandler)

	makeRequest := func(jwt string) *httptest.ResponseRecorder {
		recorder := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/public/api/resources?hash=revoked_jwt_hash&path=/", http.NoBody)
		req.AddCookie(&http.Cookie{
			Name:  "filebrowser_quantum_jwt",
			Value: jwt,
		})
		handler(recorder, req)
		return recorder
	}

	// Valid token: allow-listed user can access the share.
	rec := makeRequest(tokenString)
	if rec.Code != http.StatusOK {
		t.Fatalf("valid token: expected status %d, got %d", http.StatusOK, rec.Code)
	}

	if err := state.RevokeToken(tokenString); err != nil {
		t.Fatalf("failed to revoke token: %v", err)
	}

	// Revoked token must not resurrect the victim on public-share routes.
	rec = makeRequest(tokenString)
	if rec.Code == http.StatusOK {
		t.Fatalf("revoked token: expected non-200 status, got %d (JWT resurrection bypass)", rec.Code)
	}
}

func TestExtractUserFromExpiredToken_RejectsRevokedJWT(t *testing.T) {
	_, tokenString := issueExtractUserTestToken(t, time.Hour*2)
	if err := state.RevokeToken(tokenString); err != nil {
		t.Fatalf("failed to revoke token: %v", err)
	}

	req := httptest.NewRequest(http.MethodGet, "/public/api/resources", http.NoBody)
	req.AddCookie(&http.Cookie{
		Name:  "filebrowser_quantum_jwt",
		Value: tokenString,
	})

	data := &requestContext{}
	if got := extractUserFromExpiredToken(req, data); got != nil {
		t.Fatalf("extractUserFromExpiredToken() = user %q, want nil for revoked token", got.Username)
	}
}

func TestExtractUserFromExpiredToken_AcceptsExpiredNonRevoked(t *testing.T) {
	user, tokenString := issueExtractUserTestToken(t, -time.Minute)

	req := httptest.NewRequest(http.MethodGet, "/public/api/resources", http.NoBody)
	req.AddCookie(&http.Cookie{
		Name:  "filebrowser_quantum_jwt",
		Value: tokenString,
	})

	data := &requestContext{}
	got := extractUserFromExpiredToken(req, data)
	if got == nil {
		t.Fatal("extractUserFromExpiredToken() = nil, want user for expired non-revoked token")
	}
	if got.Username != user.Username {
		t.Fatalf("extractUserFromExpiredToken() username = %q, want %q", got.Username, user.Username)
	}
}

func TestExtractUserFromExpiredToken_RejectsRevokedExpired(t *testing.T) {
	_, tokenString := issueExtractUserTestToken(t, -time.Hour)
	if err := state.RevokeToken(tokenString); err != nil {
		t.Fatalf("failed to revoke token: %v", err)
	}

	req := httptest.NewRequest(http.MethodGet, "/public/api/resources", http.NoBody)
	req.AddCookie(&http.Cookie{
		Name:  "filebrowser_quantum_jwt",
		Value: tokenString,
	})

	data := &requestContext{}
	if got := extractUserFromExpiredToken(req, data); got != nil {
		t.Fatalf("extractUserFromExpiredToken() = user %q, want nil for revoked expired token", got.Username)
	}
}

func TestExtractUserFromExpiredToken_RejectsPastGrace(t *testing.T) {
	_, tokenString := issueExtractUserTestToken(t, -(state.BearerTokenGrace + time.Minute))

	req := httptest.NewRequest(http.MethodGet, "/public/api/resources", http.NoBody)
	req.AddCookie(&http.Cookie{
		Name:  "filebrowser_quantum_jwt",
		Value: tokenString,
	})

	data := &requestContext{}
	if got := extractUserFromExpiredToken(req, data); got != nil {
		t.Fatalf("extractUserFromExpiredToken() = user %q, want nil for token expired past grace", got.Username)
	}
}

func issueExtractUserTestToken(t *testing.T, duration time.Duration) (*users.User, string) {
	t.Helper()
	setupTestEnv(t)

	stored := &users.User{
		FrontendUser: users.FrontendUser{
			Username:    "victim",
			Permissions: users.Permissions{Api: true},
		},
	}
	if err := state.CreateUser(stored, ""); err != nil {
		t.Fatal("failed to create user:", err)
	}
	user, err := state.GetUserByUsername("victim")
	if err != nil {
		t.Fatal("failed to load user:", err)
	}
	user.Permissions = users.Permissions{Api: true}
	if err = state.UpdateUser(&user, "", "permissions"); err != nil {
		t.Fatal("failed to set user permissions:", err)
	}
	user, err = state.GetUserByUsername("victim")
	if err != nil {
		t.Fatal("failed to reload user:", err)
	}

	originalAuthKey := settings.Config.Auth.Key
	settings.Config.Auth.Key = "key"
	t.Cleanup(func() { settings.Config.Auth.Key = originalAuthKey })

	tokenString := testSessionToken(t, &user, duration)
	return &user, tokenString
}

func TestPublicShareHandlerAuthentication(t *testing.T) {
	setupTestEnv(t)

	const passwordBcrypt = "$2y$10$TFAmdCbyd/mEZDe5fUeZJu.MaJQXRTwdqb/IQV.eTn6dWrF58gCSe" // bcrypt hashed password
	const accentedPasswordBcrypt = "$2b$04$JaVUkztbmWKgV8GsSvRorettpNHrc0BvYV3/oARpepfoanKbqt5zi"

	// Create and save a dummy user (shares reference owner by UserID)
	dummyUser := &users.User{
		ID: 1,
		FrontendUser: users.FrontendUser{
			Username:    "testuser",
			Permissions: users.Permissions{Admin: false},
		},
		BackendScopes: []users.BackendScope{
			{Path: "/srv", Scope: "/"}, // Must match SourceMap key (canonical path, no trailing slash)
		},
	}
	if err := state.CreateUser(dummyUser, ""); err != nil {
		t.Fatal("failed to create dummy user:", err)
	}

	originalAuthKey := settings.Config.Auth.Key
	settings.Config.Auth.Key = "key"
	t.Cleanup(func() { settings.Config.Auth.Key = originalAuthKey })

	testCases := []struct {
		name               string
		share              *share.Share
		token              string
		password           string
		extraHeaders       map[string]string
		expectedStatusCode int
	}{
		{
			name: "Public share, no auth required",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "public_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
			},
			expectedStatusCode: http.StatusOK, // zero means 200 on helpers
		},
		{
			name: "Private share, valid password",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "pw_and_token_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
				PasswordHash: passwordBcrypt,
			},
			extraHeaders: map[string]string{
				"X-SHARE-PASSWORD": "password",
			},
			expectedStatusCode: http.StatusOK, // zero means 200 on helpers
		},
		{
			name: "Private share, no auth provided",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "private_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
				PasswordHash: passwordBcrypt,
			},
			expectedStatusCode: http.StatusUnauthorized,
		},
		{
			name: "Private share, download token rejected on listing route",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "token_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
				PasswordHash: passwordBcrypt,
			},
			token:              "download-token-placeholder",
			expectedStatusCode: http.StatusUnauthorized,
		},
		{
			name: "Private share, invalid password",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "pw_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
				PasswordHash: passwordBcrypt,
			},
			extraHeaders: map[string]string{
				"X-SHARE-PASSWORD": "wrong-password",
			},
			expectedStatusCode: http.StatusUnauthorized,
		},
		{
			name: "Private share, valid encoded non-ASCII password",
			share: &share.Share{
				ShareSettings: share.ShareSettings{
					ShareLimits: share.ShareLimits{SourceName: "srv"},
				},
				ShareColumns: share.ShareColumns{Hash: "accented_password_hash", Path: "/"},
				SourcePath:   "/srv",
				UserID:       1,
				PasswordHash: accentedPasswordBcrypt,
			},
			extraHeaders: map[string]string{
				"X-SHARE-PASSWORD": "pass%C3%A9",
			},
			expectedStatusCode: http.StatusOK,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			if err := state.CreateShare(tc.share); err != nil {
				t.Fatal("failed to save share:", err)
			}

			recorder := httptest.NewRecorder()
			handler := withHashFile(publicGetResourceHandler)

			token := tc.token
			if tc.name == "Private share, download token rejected on listing route" {
				minted, _, err := mintShareDownloadAccessToken(tc.share.Hash, time.Hour, 0)
				if err != nil {
					t.Fatalf("mintShareDownloadAccessToken: %v", err)
				}
				token = minted
			}

			req := newTestRequest(t, tc.share.Hash, token, tc.password, tc.extraHeaders)

			// Serve the request
			handler(recorder, req)

			if recorder.Code != tc.expectedStatusCode {
				t.Errorf("expected status code %d, got %d", tc.expectedStatusCode, recorder.Code)
			}
		})
	}
}

// Helper function to create a new HTTP request with optional parameters
func newTestRequest(t *testing.T, hash, token, password string, headers map[string]string) *http.Request {
	req := newHTTPRequest(t, hash, func(r *http.Request) {
		// Set query parameters based on provided values
		q := r.URL.Query()
		q.Set("path", "/")
		q.Set("hash", hash)
		if token != "" {
			q.Set("token", token)
		}
		if password != "" {
			q.Set("password", password)
		}
		r.URL.RawQuery = q.Encode()

		// Set any extra headers if provided
		for key, value := range headers {
			r.Header.Set(key, value)
		}
	})
	return req
}

func mockHandler(w http.ResponseWriter, r *http.Request, d *requestContext) (int, error) {
	return http.StatusOK, nil // mock response
}

// Modify newHTTPRequest to accept the hash and use it in the URL path.
func newHTTPRequest(t *testing.T, hash string, requestModifiers ...func(*http.Request)) *http.Request {
	t.Helper()
	url := "/public/share/" + hash + "/" // Dynamically include the hash in the URL path
	r, err := http.NewRequest(http.MethodGet, url, http.NoBody)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	for _, modify := range requestModifiers {
		modify(r)
	}
	return r
}

func TestWithTimeoutReturnsJSONTimeoutReason(t *testing.T) {
	t.Parallel()
	timeout := 50 * time.Millisecond
	handler := withTimeout(timeout, func(w http.ResponseWriter, r *http.Request, data *requestContext) (int, error) {
		<-r.Context().Done()
		return http.StatusOK, nil
	})

	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	rec := httptest.NewRecorder()
	handler(rec, req)

	if rec.Code != http.StatusRequestTimeout {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusRequestTimeout)
	}
	if ct := rec.Header().Get("Content-Type"); ct != "application/json; charset=utf-8" {
		t.Fatalf("content-type = %q", ct)
	}

	var body HttpResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if body.Status != http.StatusRequestTimeout {
		t.Fatalf("body.status = %d", body.Status)
	}
	if body.Message != "request timed out after "+timeout.String() {
		t.Fatalf("body.message = %q, want request timed out after %q", body.Message, timeout.String())
	}
}

func TestWithTimeoutHandlerErrorBeforeDeadline(t *testing.T) {
	t.Parallel()
	handler := withTimeout(time.Second, func(w http.ResponseWriter, r *http.Request, data *requestContext) (int, error) {
		return http.StatusBadRequest, context.Canceled
	})

	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	rec := httptest.NewRecorder()
	handler(rec, req)

	if rec.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusBadRequest)
	}
	var body HttpResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if body.Message != context.Canceled.Error() {
		t.Fatalf("body.message = %q", body.Message)
	}
}

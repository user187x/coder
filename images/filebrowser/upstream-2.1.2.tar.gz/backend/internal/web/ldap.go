package web

import (
	"crypto/tls"
	"fmt"
	"strings"

	ldap "github.com/go-ldap/ldap/v3"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/go-logger/logger"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"

)

// AuthenticateLDAPUser attempts LDAP authentication and returns the filebrowser user if successful.
func AuthenticateLDAPUser(username, password string) (*users.User, error) {
	username = strings.TrimSpace(username)
	if username == "" {
		return nil, fmt.Errorf("username required")
	}
	groups, userAttributes, err := authenticateLDAP(username, password)
	if err != nil {
		logger.Debugf("ldap authentication failed: %v", err)
		return nil, err
	}

	// Use the configured UserIdentifier if available, otherwise use the login username
	ldapCfg := settings.Config.Auth.Methods.LdapAuth
	mappedUsername := username
	if ldapCfg.UserIdentifier != "" {
		if val, ok := userAttributes[ldapCfg.UserIdentifier]; ok && val != "" {
			mappedUsername = val
			logger.Debugf("ldap: mapped username from %s: %s -> %s", ldapCfg.UserIdentifier, username, mappedUsername)
		} else {
			logger.Warningf("ldap: userIdentifier '%s' not found in LDAP entry for user %s, using login username", ldapCfg.UserIdentifier, username)
		}
	}

	logger.Debugf("ldap authentication successful, getting or creating user %s", mappedUsername)
	return getOrCreateLdapUser(mappedUsername, groups)
}

func authenticateLDAP(username, password string) ([]string, map[string]string, error) {
	c := settings.Config.Auth.Methods.LdapAuth
	logger.Debugf("ldap: connecting to %s", c.Server)

	var opts []ldap.DialOpt
	if c.DisableVerifyTLS && c.Scheme == "ldaps" {
		opts = append(opts, ldap.DialWithTLSConfig(&tls.Config{InsecureSkipVerify: true}))
		logger.Warning("LDAP TLS verification is disabled.")
	}

	conn, err := ldap.DialURL(c.Server, opts...)
	if err != nil {
		return nil, nil, fmt.Errorf("ldap connect: %w", err)
	}
	defer conn.Close()

	// Bind with service account
	if c.UserPassword != "" {
		logger.Debugf("ldap: binding as service account %s", c.UserDN)
		if err = conn.Bind(c.UserDN, c.UserPassword); err != nil {
			return nil, nil, fmt.Errorf("ldap bind (service): %w", err)
		}
	} else {
		logger.Debugf("ldap: no service account bind (userPassword empty)")
	}

	groupAttr := settings.ResolveLdapGroupsClaim(c.GroupsClaim)
	attributes := []string{"dn", groupAttr}
	if c.UserIdentifier != "" {
		attributes = append(attributes, c.UserIdentifier)
	}

	filter := fmt.Sprintf(c.UserFilter, ldap.EscapeFilter(username))
	searchRequest := ldap.NewSearchRequest(
		c.BaseDN,
		ldap.ScopeWholeSubtree,
		ldap.NeverDerefAliases,
		0,
		0,
		false,
		filter,
		attributes,
		nil,
	)

	result, err := conn.Search(searchRequest)
	if err != nil {
		return nil, nil, fmt.Errorf("ldap search (%s): %w", c.Server, err)
	}

	if len(result.Entries) == 0 {
		return nil, nil, fmt.Errorf("user not found: %s (LDAP search for %s returned no entries)", username, filter)
	}

	entry := result.Entries[0]
	if len(result.Entries) > 1 {
		// Prefer the user entry when multiple match (e.g. Authentik returns user + virtual group with same cn).
		if u := pickUserEntry(result.Entries); u != nil {
			entry = u
			logger.Debugf("ldap: multiple entries, using user entry DN=%s", entry.DN)
		} else {
			return nil, nil, fmt.Errorf("multiple entries for user: %s (set userFilter to narrow, e.g. (&(cn=%%s)(objectClass=user)))", username)
		}
	}
	userDN := entry.DN

	// Verify password by binding as the user
	if err := conn.Bind(userDN, password); err != nil {
		logger.Debugf("ldap: bind as user failed: %v", err)
		return nil, nil, fmt.Errorf("ldap bind (user): %w", err)
	}

	// Re-bind as service account for any follow-up (we're done; this is optional)
	if c.UserPassword != "" {
		_ = conn.Bind(c.UserDN, c.UserPassword)
	}

	groups := entry.GetAttributeValues(groupAttr)

	// Extract user attributes for identifier mapping
	userAttributes := make(map[string]string)
	if c.UserIdentifier != "" {
		values := entry.GetAttributeValues(c.UserIdentifier)
		if len(values) > 0 {
			userAttributes[c.UserIdentifier] = values[0]
		}
	}

	return groups, userAttributes, nil
}

// pickUserEntry returns the entry that represents a user when multiple entries match (e.g. Authentik user + virtual group).
// Prefers entries with objectClass=user or DN under ou=users; returns nil if none or multiple user entries.
func pickUserEntry(entries []*ldap.Entry) *ldap.Entry {
	var user *ldap.Entry
	for _, e := range entries {
		oc := e.GetAttributeValues("objectClass")
		dnLower := strings.ToLower(e.DN)
		isUser := false
		for _, c := range oc {
			if strings.EqualFold(c, "user") {
				isUser = true
				break
			}
		}
		if !isUser && strings.Contains(dnLower, "ou=users") {
			isUser = true
		}
		if isUser {
			if user != nil {
				return nil // multiple user entries
			}
			user = e
		}
	}
	return user
}

// ldapGroupMatches reports whether an LDAP group membership value matches a
// configured group. Matching is case-insensitive and accepts a full DN or a
// CN-only value. When both sides are DNs, the complete DN must match (case-
// insensitive); CN-only fallback applies only when one side is not a DN, so
// groups that share a CN under different parents cannot authorize each other.
func ldapGroupMatches(member, configured string) bool {
	member = strings.TrimSpace(member)
	configured = strings.TrimSpace(configured)
	if configured == "" {
		return false
	}
	if strings.EqualFold(member, configured) {
		return true
	}
	memberIsDN := ldapIsDN(member)
	configuredIsDN := ldapIsDN(configured)
	memberCN := ldapCN(member)
	configuredCN := ldapCN(configured)

	// Config CN-only vs member full DN.
	if memberIsDN && !configuredIsDN && memberCN != "" && strings.EqualFold(memberCN, configured) {
		return true
	}
	// Config full DN vs member CN-only.
	if configuredIsDN && !memberIsDN && configuredCN != "" && strings.EqualFold(member, configuredCN) {
		return true
	}
	return false
}

// ldapIsDN reports whether s parses as an LDAP distinguished name.
func ldapIsDN(s string) bool {
	_, err := ldap.ParseDN(s)
	return err == nil
}

// ldapCN returns the first CN RDN value from an LDAP DN string, or "" if none.
func ldapCN(s string) string {
	dn, err := ldap.ParseDN(s)
	if err != nil {
		return ""
	}
	for _, rdn := range dn.RDNs {
		for _, attr := range rdn.Attributes {
			if strings.EqualFold(attr.Type, "cn") {
				return attr.Value
			}
		}
	}
	return ""
}

// getOrCreateLdapUser returns the filebrowser user for an LDAP-authenticated username, creating one if configured.
// userGroups authorization is enforced in getOrCreateAuthenticatedUser via ldapGroupMatches.
func getOrCreateLdapUser(username string, groups []string) (*users.User, error) {
	logger.Debugf("getting or creating ldap user %s", username)
	ldapCfg := settings.Config.Auth.Methods.LdapAuth

	isAdmin := false
	if ldapCfg.AdminGroup != "" {
		for _, g := range groups {
			if ldapGroupMatches(g, ldapCfg.AdminGroup) {
				isAdmin = true
				logger.Debugf("User %s is in admin group %s, granting admin privileges.", username, ldapCfg.AdminGroup)
				break
			}
		}
	}

	return getOrCreateAuthenticatedUser(username, users.LoginMethodLdap, isAdmin, groups, true)
}

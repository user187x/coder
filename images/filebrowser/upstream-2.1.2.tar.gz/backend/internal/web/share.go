package web

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"

	"github.com/gtsteffaniak/filebrowser/backend/internal/activity"
	"github.com/gtsteffaniak/filebrowser/backend/internal/adapters/fs/files"
	activitydb "github.com/gtsteffaniak/filebrowser/backend/internal/database/activity"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/share"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/users"
	"github.com/gtsteffaniak/filebrowser/backend/internal/sharedefaults"
	"github.com/gtsteffaniak/filebrowser/backend/internal/state"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/go-logger/logger"
)

func applyShareDefaultsPolicy(u *users.User, editable *share.ShareEditable, isCreate bool) (int, error) {
	if u == nil || u.Permissions.Admin {
		return 0, nil
	}
	defaults := state.GetShareDefaults()
	enforced := state.GetEnforcedShareDefaults()
	if isCreate {
		sharedefaults.ApplyDefaultsToEditable(editable, defaults)
	}
	sharedefaults.NormalizeUploadShareEditable(editable)
	if err := sharedefaults.ValidateEditableNotEnforced(editable, enforced, defaults); err != nil {
		return http.StatusForbidden, err
	}
	sharedefaults.ApplyEnforcedDefaults(editable, defaults, enforced)
	return 0, nil
}

// shareListHandler returns a list of all share links.
// @Summary List share links
// @Description Returns a list of share links for the current user, or all links if the user is an admin.
// @Tags Shares
// @Accept json
// @Produce json
// @Success 200 {array} share.ShareFrontend "List of share links"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/share/list [get]
func shareListHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	var (
		shares []share.Share
		err    error
	)
	if d.User.Permissions.Admin {
		shares, err = state.GetAllShares()
	} else {
		shares, err = state.GetSharesByUserID(d.User.ID)
	}
	if err != nil {
		return http.StatusInternalServerError, err
	}
	host, scheme := shareURLParams(r)
	return RenderJSON(w, r, state.PrepShareValuesForFrontend(d.User, r, host, scheme, shares))
}

// shareGetsHandler retrieves share links for a specific resource path.
// @Summary Get share links by path
// @Description Retrieves all share links associated with a specific resource path for the current user.
// @Tags Shares
// @Accept json
// @Produce json
// @Param path query string true "Resource path for which to retrieve share links"
// @Param source query string true "Source name for share links"
// @Success 200 {array} share.ShareFrontend "List of share links for the specified path"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/share [get]
func shareGetHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	path := r.URL.Query().Get("path")
	sourceName := r.URL.Query().Get("source")
	if path == "" {
		return http.StatusBadRequest, fmt.Errorf("path is required")
	}
	cleanPath, err := utils.SanitizePath(path)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid path: %w", err)
	}
	path = cleanPath
	sourceInfo, ok := settings.Config.Server.NameToSource[sourceName] // backend source is path
	if !ok {
		return http.StatusBadRequest, fmt.Errorf("invalid source name: %s", sourceName)
	}
	userscope, err := d.User.GetScopeForSourceName(sourceName)
	if err != nil {
		return http.StatusForbidden, err
	}
	scopePath := utils.JoinPathAsUnix(userscope, path)
	idx := indexing.GetIndex(sourceInfo.Name)
	if idx == nil {
		return http.StatusBadRequest, fmt.Errorf("index not found for source: %s", sourceName)
	}

	s, err := state.GetSharesInScope(scopePath, sourceInfo.Path, d.User.ID)
	if err != nil {
		return http.StatusInternalServerError, fmt.Errorf("error getting share info from server")
	}
	host, scheme := shareURLParams(r)
	return RenderJSON(w, r, state.PrepSharesForFrontend(d.User, r, host, scheme, s...))
}

// shareDeleteHandler deletes a specific share link by its hash.
// @Summary Delete a share link
// @Description Deletes a share link specified by its hash.
// @Tags Shares
// @Accept json
// @Produce json
// @Param hash query string true "Hash of the share link to delete"
// @Success 200 "Share link deleted successfully"
// @Failure 400 {object} map[string]string "Bad request - missing or invalid hash"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/share [delete]
func shareDeleteHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	hash := r.URL.Query().Get("hash")

	if hash == "" {
		return http.StatusBadRequest, nil
	}

	thisShare, err := state.GetShare(hash)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("share not found")
	}
	if !thisShare.UserCanEdit(d.User) {
		return http.StatusForbidden, fmt.Errorf("you are not allowed to delete this share")
	}

	err = state.DeleteShare(hash)
	if err != nil {
		return ErrToStatus(err), err
	}

	activity.RecordShareMutation(r, toActor(d), activitydb.EventShareDelete, hash, thisShare.SourceName, thisShare.Path, nil)
	return ErrToStatus(err), err
}

// sharePatchHandler updates a share link's path.
// @Summary Update share link path
// @Description Updates the path for a specific share link identified by hash
// @Tags Shares
// @Accept json
// @Produce json
// @Param body body object{hash=string,path=string} true "Hash and new path"
// @Success 200 {object} share.ShareFrontend "Updated share link"
// @Failure 400 {object} map[string]string "Bad request - missing or invalid parameters"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/share [patch]
func sharePatchHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	var body struct {
		Hash string `json:"hash"`
		Path string `json:"path"`
	}

	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
	}
	defer r.Body.Close()

	if body.Hash == "" || body.Path == "" {
		return http.StatusBadRequest, fmt.Errorf("hash and path are required")
	}

	sanitizedPath, err := utils.SanitizePath(body.Path)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid path: %w", err)
	}
	body.Path = sanitizedPath

	// only allow users to update their own shares
	thisShare, err := state.GetShare(body.Hash)
	if err != nil {
		return ErrToStatus(err), fmt.Errorf("failed to load share: %w", err)
	}
	if !thisShare.UserCanEdit(d.User) {
		return http.StatusForbidden, fmt.Errorf("you are not allowed to update this share")
	}
	sourceName := thisShare.GetSourceName()
	if sourceName == "" {
		return http.StatusBadRequest, fmt.Errorf("source not available for share")
	}
	userscope, err := d.User.GetScopeForSourceName(sourceName)
	if err != nil {
		return http.StatusForbidden, err
	}
	storedPath := utils.JoinPathAsUnix(userscope, body.Path)
	err = state.UpdateSharePath(body.Hash, storedPath)
	if err != nil {
		return http.StatusInternalServerError, err
	}

	updatedShare, err := state.GetShare(body.Hash)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	host, scheme := shareURLParams(r)
	prepared := state.PrepShareForFrontend(d.User, r, host, scheme, updatedShare)
	if prepared == nil {
		return http.StatusInternalServerError, fmt.Errorf("could not prepare share response")
	}
	changes := []activitydb.FieldChange{{
		Field: "path",
		From:  thisShare.Path,
		To:    updatedShare.Path,
	}}
	activity.RecordShareMutation(r, toActor(d), activitydb.EventShareUpdate, body.Hash, updatedShare.SourceName, updatedShare.Path, changes)
	return RenderJSON(w, r, prepared)
}

// sharePostHandler creates a new share link.
// @Summary Create a share link
// @Description Creates a new share link with an optional expiration time and password protection.
// @Tags Shares
// @Accept json
// @Produce json
// @Param body body share.SharePostBody true "Share creation parameters"
// @Success 200 {object} share.ShareFrontend "Created share link"
// @Failure 400 {object} map[string]string "Bad request - failed to decode body"
// @Failure 500 {object} map[string]string "Internal server error"
// @Router /api/share [post]
func sharePostHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	var req share.SharePostBody
	var bodyBytes []byte
	var err error
	if r.Body != nil {
		bodyBytes, err = io.ReadAll(r.Body)
		if err != nil {
			return http.StatusBadRequest, fmt.Errorf("failed to read body: %w", err)
		}
		defer r.Body.Close()
	}
	if len(bodyBytes) > 0 {
		if err = json.Unmarshal(bodyBytes, &req); err != nil {
			return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
		}
	}

	if req.Hash != "" {
		_, err = state.GetShare(req.Hash)
		if err != nil {
			return http.StatusBadRequest, fmt.Errorf("invalid hash provided")
		}
	}

	var expire int64

	if req.Hash == "" && req.Expires != "" {
		expire, err = shareExpireFromRequest(req.Expires, req.Unit)
		if err != nil {
			return http.StatusInternalServerError, err
		}
	}

	hash, status, err2 := sharePasswordFromRequest(req.Password)
	if err2 != nil {
		return status, err2
	}
	stringHash := ""
	if len(hash) > 0 {
		stringHash = string(hash)
	}
	if req.Hash != "" {
		beforeShare, getErr := state.GetShare(req.Hash)
		if getErr != nil {
			return http.StatusBadRequest, fmt.Errorf("share not found")
		}
		if !beforeShare.UserCanEdit(d.User) {
			return http.StatusForbidden, fmt.Errorf("you are not allowed to update this share")
		}
		updateSourceName := beforeShare.GetSourceName()
		mergedEditable, mergeErr := sharedefaults.MergeEditableUpdate(share.EditableFromShare(&beforeShare), bodyBytes)
		if mergeErr != nil {
			return http.StatusBadRequest, mergeErr
		}
		req.ShareEditable = mergedEditable
		if req.Expires != "" {
			expire, err = shareExpireFromRequest(req.Expires, req.Unit)
			if err != nil {
				return http.StatusInternalServerError, err
			}
		} else {
			expire = beforeShare.Expire
		}
		if status, policyErr := applyShareDefaultsPolicy(d.User, &req.ShareEditable, false); policyErr != nil {
			return status, policyErr
		}
		if updateSourceName != "" {
			ownerPerms, permErr := d.User.FilePermsForSourceName(updateSourceName)
			if permErr != nil {
				return http.StatusForbidden, permErr
			}
			share.ClampShareEditable(ownerPerms, &req.ShareEditable)
		}
		err = state.UpdateShare(req.Hash, func(link *share.Share) error {
			shouldResetCounts := link.DownloadsLimit != req.DownloadsLimit ||
				link.PerUserDownloadLimit != req.PerUserDownloadLimit

			if err = applySharePasswordUpdate(link, req.Password, stringHash); err != nil {
				return err
			}

			preservedPath := link.Path
			preservedSourcePath := link.SourcePath
			preservedPinned := link.PinnedItems
			preservedVersion := link.Version

			share.ApplyPostBodyUpdate(link, &req, expire)

			link.Path = preservedPath
			link.SourcePath = preservedSourcePath
			link.PinnedItems = preservedPinned
			link.Version = preservedVersion
			if shouldResetCounts {
				link.ResetDownloadCounts()
			}
			return nil
		})
		if err != nil {
			return http.StatusInternalServerError, err
		}

		updatedShare, err3 := state.GetShare(req.Hash)
		if err3 != nil {
			return http.StatusInternalServerError, err3
		}
		if beforeShare.QuotaLimitBytes > 0 && updatedShare.QuotaLimitBytes <= 0 {
			if qerr := state.DeleteShareQuotaCounter(updatedShare.Hash); qerr != nil {
				return http.StatusInternalServerError, qerr
			}
		} else if updatedShare.QuotaLimitBytes > 0 {
			if qerr := state.EnsureShareQuotaCounter(updatedShare.Hash); qerr != nil {
				return http.StatusInternalServerError, qerr
			}
			if beforeShare.QuotaLimitBytes <= 0 {
				idx := indexing.GetIndex(updatedShare.GetSourceName())
				if idx != nil {
					indexPath := updatedShare.Path
					if indexPath == "" {
						indexPath = "/"
					}
					if rbErr := state.RebuildShareQuotaUsage(updatedShare.Hash, updatedShare.GetSourceName(), indexPath); rbErr != nil {
						logger.Warningf("rebuild share quota usage failed: %v", rbErr)
					}
				}
			}
		}
		changes := activity.ShareUpdateChanges(&beforeShare, &updatedShare)
		host, scheme := shareURLParams(r)
		prepared := state.PrepShareForFrontend(d.User, r, host, scheme, updatedShare)
		if prepared == nil {
			return http.StatusInternalServerError, fmt.Errorf("could not prepare share response")
		}
		if len(changes) > 0 {
			activity.RecordShareMutation(r, toActor(d), activitydb.EventShareUpdate, req.Hash, updatedShare.SourceName, updatedShare.Path, changes)
		}
		return RenderJSON(w, r, prepared)
	}

	source, ok := settings.Config.Server.NameToSource[req.SourceName]
	if !ok {
		return http.StatusForbidden, fmt.Errorf("source with name not found: %s", req.SourceName)
	}

	if source.Config.Private {
		return http.StatusForbidden, fmt.Errorf("the target source is private, sharing is not permitted")
	}

	secureHash, err := generateShortUUID()
	if err != nil {
		return http.StatusInternalServerError, err
	}
	idx := indexing.GetIndex(source.Name)
	if idx == nil {
		return http.StatusForbidden, fmt.Errorf("source with name not found: %s", req.SourceName)
	}
	userscope, err := d.User.GetScopeForSourceName(source.Name)
	if err != nil {
		return http.StatusForbidden, err
	}
	providedPath := req.Path

	cleanPath, err := utils.SanitizePath(providedPath)
	if err != nil {
		return http.StatusBadRequest, err
	}

	storedPath := utils.JoinPathAsUnix(userscope, cleanPath)

	if status, policyErr := applyShareDefaultsPolicy(d.User, &req.ShareEditable, true); policyErr != nil {
		return status, policyErr
	}
	ownerPerms, permErr := d.User.FilePermsForSourceName(source.Name)
	if permErr != nil {
		return http.StatusForbidden, permErr
	}
	share.ClampShareEditable(ownerPerms, &req.ShareEditable)
	shareLimits := req.ShareLimits
	shareLimits.SourceName = source.Name

	s := &share.Share{
		ShareSettings: share.ShareSettings{
			FrontendShareInfo: req.FrontendShareInfo,
			ShareLimits:       shareLimits,
		},
		ShareColumns: share.ShareColumns{
			Hash:   secureHash,
			Path:   storedPath,
			Expire: expire,
		},
		SourcePath:   source.Path,
		UserID:       d.User.ID,
		PasswordHash: stringHash,
		Version:      1,
	}
	s.DownloadURL = ""
	s.ShareURL = ""
	s.FaviconUrl = ""
	s.BannerUrl = ""
	s.FrontendShareInfo.SourceURL = ""
	s.FrontendShareInfo.HasPassword = stringHash != ""
	s.CanEditShare = false
	s.SingleFileShare = false

	if err = state.CreateShare(s); err != nil {
		return http.StatusInternalServerError, err
	}

	created, err := state.GetShare(secureHash)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	host, scheme := shareURLParams(r)
	prepared := state.PrepShareForFrontend(d.User, r, host, scheme, created)
	if prepared == nil {
		return http.StatusInternalServerError, fmt.Errorf("could not prepare share response")
	}
	activity.RecordShareMutation(r, toActor(d), activitydb.EventShareCreate, s.Hash, s.SourceName, s.Path, nil)
	return RenderJSON(w, r, prepared)
}

// DirectDownloadResponse represents the response for direct download endpoint.
type DirectDownloadResponse struct {
	Hash      string `json:"hash"`
	Token     string `json:"token"`
	ExpiresAt int64  `json:"expiresAt"`
	URL       string `json:"url"`
}

// parseShareDownloadTokenParams reads duration, unit, and optional use-count from the direct-download API query.
func parseShareDownloadTokenParams(r *http.Request) (time.Duration, int, error) {
	durationStr := r.URL.Query().Get("duration")
	if durationStr == "" {
		durationStr = "60"
	}
	durationNum, err := strconv.Atoi(durationStr)
	if err != nil {
		return 0, 0, fmt.Errorf("invalid duration: %v", err)
	}

	unit := r.URL.Query().Get("unit")
	if unit == "" {
		unit = "minutes"
	}
	ttl, err := parseShareDownloadAccessDuration(durationNum, unit)
	if err != nil {
		return 0, 0, err
	}

	maxUses := 0
	if countStr := r.URL.Query().Get("count"); countStr != "" {
		maxUses, err = strconv.Atoi(countStr)
		if err != nil || maxUses <= 0 {
			return 0, 0, fmt.Errorf("invalid count: %v", err)
		}
	}
	return ttl, maxUses, nil
}

// mintShareDownloadTokenResponse builds the JSON payload for GET /api/share/direct.
func mintShareDownloadTokenResponse(r *http.Request, hash string, ttl time.Duration, maxUses int) (DirectDownloadResponse, error) {
	token, expiresAt, err := mintShareDownloadAccessToken(hash, ttl, maxUses)
	if err != nil {
		return DirectDownloadResponse{}, err
	}
	host, scheme := shareURLParams(r)
	return DirectDownloadResponse{
		Hash:      hash,
		Token:     token,
		ExpiresAt: expiresAt,
		URL:       directDownloadURL(host, scheme, hash, token),
	}, nil
}

// shareDirectDownloadHandler mints a download-only ephemeral token for a password-protected share.
// @Summary Get direct download link
// @Description Mints a download-only ephemeral token for an existing password-protected share. Requires the share owner or an admin plus a valid X-SHARE-PASSWORD header. API-only; not used by the FileBrowser UI. Default duration is 60 minutes. Maximum token lifetime is 24 hours regardless of unit.
// @Tags Shares
// @Accept json
// @Produce json
// @Param hash query string true "Share hash"
// @Param duration query string false "Duration value (default: 60)"
// @Param unit query string false "Duration unit: minutes or hours (default: minutes)"
// @Param count query string false "Maximum number of downloads allowed with this token (default: unlimited within TTL)"
// @Param X-SHARE-PASSWORD header string true "Share password"
// @Success 200 {object} DirectDownloadResponse "Ephemeral download link"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 401 {object} map[string]string "Invalid or missing share password"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Share not found"
// @Router /api/share/direct [get]
func shareDirectDownloadHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	hash := r.URL.Query().Get("hash")
	if hash == "" {
		return http.StatusBadRequest, fmt.Errorf("hash is required")
	}

	link, err := state.GetShare(hash)
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("share not found")
	}
	if !link.HasPassword() {
		return http.StatusBadRequest, fmt.Errorf("share is not password protected")
	}
	if !link.UserCanEdit(d.User) {
		return http.StatusForbidden, fmt.Errorf("you are not allowed to mint tokens for this share")
	}

	status, err := AuthenticateShareRequest(w, r, link)
	if err != nil || status != http.StatusOK {
		return http.StatusUnauthorized, fmt.Errorf("invalid share password")
	}

	ttl, maxUses, err := parseShareDownloadTokenParams(r)
	if err != nil {
		return http.StatusBadRequest, err
	}

	response, err := mintShareDownloadTokenResponse(r, hash, ttl, maxUses)
	if err != nil {
		return http.StatusInternalServerError, err
	}
	return RenderJSON(w, r, response)
}

// getShareImage serves banner or favicon files for shares as resizable previews
// @Summary Get share image (banner or favicon) as preview
// @Description Returns a resizable preview (large size) for the banner or favicon file of a share
// @Tags Shares
// @Produce image/jpeg
// @Param hash query string true "Share hash"
// @Param banner query bool false "Request banner file"
// @Param favicon query bool false "Request favicon file"
// @Success 200 {file} file "Preview image content (JPEG)"
// @Failure 400 {object} map[string]string "Invalid request"
// @Failure 403 {object} map[string]string "Permission denied"
// @Failure 404 {object} map[string]string "Asset not found"
// @Router /public/api/share/image [get]
func getShareImage(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	isBanner := r.URL.Query().Get("banner") == "true"
	isFavicon := r.URL.Query().Get("favicon") == "true"

	if !isBanner && !isFavicon {
		return http.StatusBadRequest, fmt.Errorf("either banner or favicon parameter must be true")
	}

	userValue, err := state.UserForShareOwner(d.Share)
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("user for share no longer exists")
	}
	shareCreatedByUser := &userValue

	sourceName, assetPath, err := d.Share.GetShareImagePartsHelper(isBanner)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid asset configuration: %v", err)
	}

	fileInfo, err := files.FileInfoFaster(utils.FileOptions{
		Path:           assetPath,
		Source:         sourceName,
		Expand:         false,
		Content:        false,
		Metadata:       false,
		ShowHidden:     false,
		FollowSymlinks: true,
	}, shareCreatedByUser)
	if err != nil {
		logger.Errorf("error accessing share asset: source=%v path=%v error=%v", sourceName, assetPath, err)
		return http.StatusNotFound, fmt.Errorf("asset file not found or not accessible")
	}

	if !strings.HasPrefix(fileInfo.Type, "image/") {
		return http.StatusBadRequest, fmt.Errorf("invalid file type, must be image")
	}

	d.FileInfo = *fileInfo
	q := r.URL.Query()
	if isBanner {
		q.Set("size", "xlarge")
	} else {
		q.Set("size", "small")
	}
	r.URL.RawQuery = q.Encode()

	status, err := PreviewHelperFunc(w, r, d)
	if err != nil {
		logger.Errorf("error generating preview for share asset: source=%v path=%v error=%v", sourceName, assetPath, err)
		return http.StatusNotFound, fmt.Errorf("preview not available for this asset")
	}

	return status, err
}

// shareInfoHandler retrieves share information by hash.
// @Summary Get share information by hash
// @Description Returns information about a share link based on its hash. This endpoint is publicly accessible and can be used with or without authentication.
// @Tags Shares
// @Accept json
// @Produce json
// @Param hash query string true "Hash of the share link"
// @Success 200 {object} share.Share "Share information"
// @Failure 404 {object} map[string]string "Share hash not found"
// @Router /public/api/share/info [get]
func shareInfoHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	hash := r.URL.Query().Get("hash")
	shareInfo, err := state.GetShare(hash)
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("share hash not found")
	}
	frontendShareInfo := shareInfo.FrontendShareInfo
	frontendShareInfo.ShareURL = ShareURLFromRequest(r, hash, false, shareInfo.HasPassword())
	frontendShareInfo.BannerUrl = shareInfo.BannerURL()
	frontendShareInfo.FaviconUrl = shareInfo.FaviconURL()
	filtered := make([]users.SidebarLink, 0, len(frontendShareInfo.SidebarLinks))
	for _, link := range frontendShareInfo.SidebarLinks {
		if link.Category == "download" && frontendShareInfo.ShareType == "upload" {
			continue
		}
		if link.Category == "download" && frontendShareInfo.DisableDownload {
			continue
		}
		filtered = append(filtered, link)
	}
	frontendShareInfo.SidebarLinks = filtered
	frontendShareInfo.SourceURL = shareInfo.SourceURL(d.User)
	frontendShareInfo.CanEditShare = shareInfo.UserCanEdit(d.User)
	frontendShareInfo.SingleFileShare = shareInfo.IsSingleFileShare()
	frontendShareInfo.HasPassword = shareInfo.HasPassword()
	if frontendShareInfo.SourceURL != "" {
		frontendShareInfo.SidebarLinks = append(frontendShareInfo.SidebarLinks, users.SidebarLink{
			Name:     "sourceLocation",
			Category: "custom",
			Target:   frontendShareInfo.SourceURL,
		})
	}
	resp := struct {
		share.FrontendShareInfo
		QuotaLimitBytes     int64                       `json:"quotaLimitBytes,omitempty"`
		QuotaUsedBytes      int64                       `json:"quotaUsedBytes,omitempty"`
		QuotaAvailableBytes int64                       `json:"quotaAvailableBytes,omitempty"`
		FolderQuotas        []publicFolderQuotaSnapshot `json:"folderQuotas,omitempty"`
	}{
		FrontendShareInfo: frontendShareInfo,
		QuotaLimitBytes:   shareInfo.QuotaLimitBytes,
	}
	if shareInfo.QuotaLimitBytes > 0 {
		used, reserved := state.GetShareQuotaUsage(hash)
		resp.QuotaUsedBytes = used
		avail := shareInfo.QuotaLimitBytes - used - reserved
		if avail < 0 {
			avail = 0
		}
		resp.QuotaAvailableBytes = avail
	}
	if sourceInfo, ok := settings.Config.Server.SourceMap[shareInfo.SourcePath]; ok {
		sourceName := shareInfo.GetSourceName()
		for _, fq := range state.ApplicableFolderQuotas(sourceInfo.Path, shareInfo.Path, shareInfo.UserID) {
			snap := state.FolderQuotaSnapshot(fq, sourceName)
			resp.FolderQuotas = append(resp.FolderQuotas, publicFolderQuotaSnapshot{
				LimitBytes:    snap.LimitBytes,
				UsedBytes:     snap.UsedBytes,
				ReservedBytes: snap.ReservedBytes,
			})
		}
	}
	return RenderJSON(w, r, resp)
}

type publicFolderQuotaSnapshot struct {
	LimitBytes    int64 `json:"limitBytes"`
	UsedBytes     int64 `json:"usedBytes,omitempty"`
	ReservedBytes int64 `json:"reservedBytes,omitempty"`
}

type sharePinnedItemPatchRequest struct {
	Path string `json:"path" validate:"required"`
	Name string `json:"name" validate:"required"`
}

func normalizeShareRelativeDir(shareRelDir string) (string, error) {
	if shareRelDir == "" || shareRelDir == "/" {
		return "/", nil
	}
	cleanDir, err := utils.SanitizePath(shareRelDir)
	if err != nil {
		return "", fmt.Errorf("invalid path: %w", err)
	}
	return utils.AddTrailingSlashIfNotExists(cleanDir), nil
}

// sharePatchPinnedItemsHandler adds or removes a pinned item on a share.
// @Summary Add or remove a pinned item on a share
// @Description Patches one pinned item at a time on a share. Defaults to add; pass ?action=remove to unpin.
// @Tags Share
// @Accept json
// @Produce json
// @Param hash query string true "Share hash"
// @Param action query string false "add (default) or remove"
// @Param body body sharePinnedItemPatchRequest true "Pinned item"
// @Success 204 "No Content"
// @Failure 400 {object} map[string]string "Bad Request"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Not Found"
// @Failure 500 {object} map[string]string "Internal Server Error"
// @Router /public/api/share/pinned-items [patch]
func sharePatchPinnedItemsHandler(w http.ResponseWriter, r *http.Request, d *Context) (int, error) {
	hash := r.URL.Query().Get("hash")
	if hash == "" {
		return http.StatusBadRequest, fmt.Errorf("hash is required")
	}

	link, err := state.GetShare(hash)
	if err != nil {
		return http.StatusNotFound, fmt.Errorf("share hash not found")
	}

	if d.User.Username == "anonymous" || !link.UserCanEdit(d.User) {
		return http.StatusForbidden, fmt.Errorf("share pin editing is not allowed for this user")
	}

	if link.ShareType == "upload" {
		return http.StatusForbidden, fmt.Errorf("pinning is disabled for upload shares")
	}

	var body sharePinnedItemPatchRequest
	if err = json.NewDecoder(r.Body).Decode(&body); err != nil {
		return http.StatusBadRequest, fmt.Errorf("failed to decode body: %w", err)
	}
	defer r.Body.Close()

	action := pinnedItemAction(r)
	if action != "add" && action != "remove" {
		return http.StatusBadRequest, fmt.Errorf("action must be add or remove")
	}

	if body.Path == "" || body.Name == "" {
		return http.StatusBadRequest, fmt.Errorf("path and name are required")
	}

	shareRelDir, err := normalizeShareRelativeDir(body.Path)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid path: %s", body.Path)
	}

	cleanName, err := utils.SanitizePath(body.Name)
	if err != nil {
		return http.StatusBadRequest, fmt.Errorf("invalid name: %s", body.Name)
	}
	body.Name = cleanName

	pinned := link.EnsurePinnedItems()
	switch action {
	case "add":
		pinned.Add(shareRelDir, body.Name)
	case "remove":
		pinned.Remove(shareRelDir, body.Name)
	}

	if err := state.UpdateShare(hash, func(existing *share.Share) error {
		existing.PinnedItems = link.PinnedItems
		return nil
	}); err != nil {
		return http.StatusInternalServerError, fmt.Errorf("failed to save share: %w", err)
	}

	return http.StatusNoContent, nil
}

func getSharePasswordHash(plaintextPassword string) (data []byte, statuscode int, err error) {
	if plaintextPassword == "" {
		return nil, 0, nil
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(plaintextPassword), bcrypt.DefaultCost)
	if err != nil {
		return nil, http.StatusInternalServerError, fmt.Errorf("failed to hash password")
	}

	return hash, 0, nil
}

// sharePasswordFromRequest hashes a password for new shares. Nil or empty means no password.
func sharePasswordFromRequest(password *string) ([]byte, int, error) {
	if password == nil || *password == "" {
		return nil, 0, nil
	}
	return getSharePasswordHash(*password)
}

func shareExpireFromRequest(expires, unit string) (int64, error) {
	num, err := strconv.Atoi(expires)
	if err != nil {
		return 0, err
	}

	var add time.Duration
	switch unit {
	case "seconds":
		add = time.Second * time.Duration(num)
	case "minutes":
		add = time.Minute * time.Duration(num)
	case "days":
		add = time.Hour * 24 * time.Duration(num)
	default:
		add = time.Hour * time.Duration(num)
	}

	return time.Now().Add(add).Unix(), nil
}

// applySharePasswordUpdate sets or preserves password credentials on share update.
// Nil password omits the field (keep existing); empty string clears; non-empty replaces.
func applySharePasswordUpdate(link *share.Share, password *string, hashedPassword string) error {
	if password == nil {
		return nil
	}
	if *password == "" {
		link.PasswordHash = ""
		return nil
	}
	link.PasswordHash = hashedPassword
	return nil
}

func generateShortUUID() (string, error) {
	// Generate 16 random bytes (128 bits of entropy)
	bytes := make([]byte, 16)
	_, err := rand.Read(bytes)
	if err != nil {
		return "", err
	}

	// Encode the bytes to a URL-safe base64 string
	uuid := base64.RawURLEncoding.EncodeToString(bytes)

	// Trim the length to 22 characters for a shorter ID
	return uuid[:22], nil
}

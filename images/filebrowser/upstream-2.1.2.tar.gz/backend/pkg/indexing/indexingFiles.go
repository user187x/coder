package indexing

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/gtsteffaniak/filebrowser/backend/internal/adapters/fs/fileutils"
	"github.com/gtsteffaniak/filebrowser/backend/internal/database/dbindex"
	dbsql "github.com/gtsteffaniak/filebrowser/backend/internal/database/sql"
	"github.com/gtsteffaniak/filebrowser/backend/internal/errors"
	"github.com/gtsteffaniak/filebrowser/backend/internal/utils"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/indexing/iteminfo"
	"github.com/gtsteffaniak/filebrowser/backend/pkg/settings"
	"github.com/gtsteffaniak/go-cache/cache"
	"github.com/gtsteffaniak/go-logger/logger"
	"golang.org/x/net/webdav"
)

var (
	RealPathCache = cache.NewCache[string](48*time.Hour, 72*time.Hour)
	IsDirCache    = cache.NewCache[bool](48*time.Hour, 72*time.Hour)
)

// getDiskUsage returns the actual disk space used by a file in bytes
// This is a simplified helper for shallow calculations and API calls
// For scanning with hardlink detection, use handleFile instead
// If useLogicalSize is true, returns the logical file size instead
func getDiskUsage(fileInfo os.FileInfo, useLogicalSize bool) int64 {
	// If useLogicalSize is true, return logical size (no block alignment)
	if useLogicalSize {
		if fileInfo.IsDir() {
			return 0 // Directories have no logical size
		}
		return fileInfo.Size()
	}

	// Disk usage mode (du-like behavior)
	// For directories, use minimum 4KB
	if fileInfo.IsDir() {
		return 4096
	}

	// For files, round up to nearest 4KB block for non-zero files
	// Note: handleFile in unix.go/windows.go provides more accurate disk usage during scanning
	size := fileInfo.Size()
	if size == 0 {
		return 0
	}
	// Round up to nearest 4KB
	blocks := (size + 4095) / 4096
	return blocks * 4096
}

// Options holds all configuration options for indexing and filesystem operations
type Options struct {
	// Indexing operation options
	Recursive     bool // whether to recursively index subdirectories
	CheckViewable bool // whether to check if the path has viewable:true (for API access checks)
	IsRoutineScan bool // whether this is a routine/scheduled scan (vs initial indexing)

	// Filesystem info retrieval options
	SkipExtendedAttrs bool   // Skip hasPreview and other extended attributes
	FollowSymlinks    bool   // Whether to follow symlinks or return symlink info
	ShowHidden        bool   // Whether to include hidden files/directories
	HideFileExt       string // Hide files based on extensions
}

// ScannerInfo is the exposed scanner information for the client
type ScannerInfo struct {
	Stats
	Path            string `json:"path"`
	IsRoot          bool   `json:"isRoot"`
	CurrentSchedule int    `json:"currentSchedule"`
}

type Stats struct {
	NumDirs         uint64    `json:"numDirs"`
	NumFiles        uint64    `json:"numFiles"`
	NumDeleted      uint64    `json:"numDeleted"`
	QuickScanTime   int       `json:"quickScanDurationSeconds"`
	FullScanTime    int       `json:"fullScanDurationSeconds"`
	LastIndexedUnix int64     `json:"lastIndexedUnixTime"`
	Complexity      uint      `json:"complexity"`
	LastScanned     time.Time `json:"lastScanned"`
	UsedAsIndexed   uint64    `json:"used"`
	UsedDisk        uint64    `json:"usedAlt"`
	DiskTotal       uint64    `json:"total"`
	// UsedDiskRoot/DiskTotalRoot are the root-filesystem-only view: a single
	// statfs of the source path without aggregating nested mounts.
	UsedDiskRoot  uint64 `json:"usedAltRoot"`
	DiskTotalRoot uint64 `json:"totalRoot"`
	// UsageScopeMismatch is true when indexed used exceeds partition total at the
	// source root (e.g. nested mounts under the source path). Display-only signal.
	UsageScopeMismatch bool `json:"usageScopeMismatch,omitempty"`
}

// reduced index is json exposed to the client
type ReducedIndex struct {
	Stats
	IdxName          string         `json:"name"`
	ReadOnly         bool           `json:"readOnly"`
	Private          bool           `json:"private"`
	IndexingDisabled bool           `json:"indexingDisabled,omitempty"`
	Status           IndexStatus    `json:"status"`
	Scanners         []*ScannerInfo `json:"scanners,omitempty"`
}

type Index struct {
	ReducedIndex
	settings.Source   `json:"-"`
	db                *dbsql.IndexDB
	previousNumDirs   uint64              // Track previous NumDirs to use when scan in progress (computed value is 0)
	previousNumFiles  uint64              // Track previous NumFiles to use when scan in progress (computed value is 0)
	scanners          map[string]*Scanner // path -> scanner
	mock              bool
	mu                sync.RWMutex
	activeScannerPath string
	schedulerStop     chan struct{}
	schedulerStopOnce sync.Once
	schedulerBatch    int // >0: serial pass in progress; suppresses PostScan inside executeScan
	// Adaptive scheduler: run one serial scan on process start (then normal slot cadence).
	schedulerStartupPassPending bool
	// In-memory folder size tracking (not stored in SQLite)
	folderSizes         map[string]uint64   // path -> size (in-memory only, calculated from children)
	folderSizesUnsynced map[string]struct{} // Tracks which folder sizes have changed since last DB sync
	folderSizesMu       sync.RWMutex        // Dedicated RWMutex allows concurrent reads, serializes writes
	// Scan session tracking: timestamp when scan session started (for timestamp-based conflict detection)
	scanSessionStartTime int64           // Unix timestamp when current scan session started (0 if no active scan)
	scanUpdatedPaths     map[string]bool // Tracks directories updated by the scan (to distinguish from API updates)
	// WebDAV lock system for this source (isolated per source)
	WebdavLock webdav.LockSystem

	// Adaptive scheduler: shared slot map (UTC unix seconds -> scanners).
	scheduleSlotsMu sync.Mutex
	scheduleSlots   map[int64][]*Scanner
}

var (
	indexes      map[string]*Index
	indexesMutex sync.RWMutex
	indexDB      *dbsql.IndexDB // Shared database for all indexes
)

type IndexStatus string

const (
	READY       IndexStatus = "ready"
	INDEXING    IndexStatus = "indexing"
	UNAVAILABLE IndexStatus = "unavailable"
)

// omitList contains directory names to skip during indexing
var omitList = map[string]bool{
	"$RECYCLE.BIN":              true,
	"System Volume Information": true,
	"@eaDir":                    true,
}

func init() {
	indexes = make(map[string]*Index)
}

// GetNumDirs calculates the total number of directories by summing all scanner values
func (idx *Index) GetNumDirs() uint64 {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	current := idx.getNumDirsUnlocked()
	if current == 0 {
		current = idx.previousNumDirs
	}
	return current
}

// getNumDirsUnlocked calculates NumDirs without acquiring lock (assumes lock is already held)
func (idx *Index) getNumDirsUnlocked() uint64 {
	var totalDirs uint64 = 0
	for _, scanner := range idx.scanners {
		totalDirs += scanner.numDirs
	}
	return totalDirs
}

// GetNumFiles calculates the total number of files by summing all scanner values.
func (idx *Index) GetNumFiles() uint64 {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	current := idx.getNumFilesUnlocked()
	// If computed value is 0 (scan in progress), use previous non-zero value
	if current == 0 && idx.previousNumFiles > 0 {
		return idx.previousNumFiles
	}
	return current
}

// getNumFilesUnlocked calculates NumFiles without acquiring lock (assumes lock is already held)
func (idx *Index) getNumFilesUnlocked() uint64 {
	var totalFiles uint64 = 0
	for _, scanner := range idx.scanners {
		totalFiles += scanner.numFiles
	}
	return totalFiles
}

// GetQuickScanTime calculates the total quick scan time by summing all scanner values
func (idx *Index) GetQuickScanTime() int {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getQuickScanTimeUnlocked()
}

// getQuickScanTimeUnlocked calculates QuickScanTime without acquiring lock (assumes lock is already held)
func (idx *Index) getQuickScanTimeUnlocked() int {
	var total = 0
	for _, scanner := range idx.scanners {
		total += scanner.quickScanTime
	}
	return total
}

// GetFullScanTime calculates the total full scan time by summing all scanner values
func (idx *Index) GetFullScanTime() int {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getFullScanTimeUnlocked()
}

// getFullScanTimeUnlocked calculates FullScanTime without acquiring lock (assumes lock is already held)
func (idx *Index) getFullScanTimeUnlocked() int {
	var total = 0
	for _, scanner := range idx.scanners {
		total += scanner.fullScanTime
	}
	return total
}

// GetComplexity calculates the complexity based on full scan time and number of directories
func (idx *Index) GetComplexity() uint {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getComplexityUnlocked()
}

// getComplexityUnlocked calculates Complexity without acquiring lock (assumes lock is already held)
func (idx *Index) getComplexityUnlocked() uint {
	// If we have a persisted complexity value and scanners haven't been scanned yet, use it
	if idx.Complexity > 0 && len(idx.scanners) == 0 {
		return idx.Complexity
	}

	if len(idx.scanners) == 0 {
		// No scanners yet, but check if we have a persisted value
		if idx.Complexity > 0 {
			return idx.Complexity
		}
		return 0
	}

	allScannedAtLeastOnce := true
	for _, scanner := range idx.scanners {
		if scanner.lastScanned.IsZero() {
			allScannedAtLeastOnce = false
			break
		}
	}

	if !allScannedAtLeastOnce {
		// Scanners haven't completed first scan yet, use persisted value if available
		if idx.Complexity > 0 {
			return idx.Complexity
		}
		return 0
	}

	totalFullScanTime := idx.getFullScanTimeUnlocked()
	totalDirs := idx.getNumDirsUnlocked()
	calculatedComplexity := calculateComplexity(totalFullScanTime, totalDirs)

	// Update persisted value with calculated value
	if calculatedComplexity > 0 {
		idx.Complexity = calculatedComplexity
	}

	return calculatedComplexity
}

// GetLastIndexed returns the most recent scan time from all scanners
func (idx *Index) GetLastIndexed() time.Time {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getLastIndexedUnlocked()
}

// getLastIndexedUnlocked calculates LastIndexed without acquiring lock (assumes lock is already held)
func (idx *Index) getLastIndexedUnlocked() time.Time {
	var mostRecentScan time.Time
	for _, scanner := range idx.scanners {
		if scanner.lastScanned.After(mostRecentScan) {
			mostRecentScan = scanner.lastScanned
		}
	}
	return mostRecentScan
}

// GetStatus returns the computed status based on scanner state, or UNAVAILABLE if explicitly set
func (idx *Index) GetStatus() IndexStatus {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getStatusUnlocked()
}

// getStatusUnlocked calculates Status without acquiring lock (assumes lock is already held)
func (idx *Index) getStatusUnlocked() IndexStatus {
	if idx.Status == UNAVAILABLE {
		return UNAVAILABLE
	}

	if len(idx.scanners) == 0 {
		return idx.Status // Return current status if no scanners
	}

	allScannedAtLeastOnce := true

	for _, scanner := range idx.scanners {
		if scanner.lastScanned.IsZero() {
			allScannedAtLeastOnce = false
		}
	}

	if idx.getActiveScannerPathUnlocked() != "" {
		return INDEXING
	} else if allScannedAtLeastOnce {
		return READY
	}

	return idx.Status
}

// InitializeIndexDB creates the shared index database for all sources.
// Returns true if the database was recreated (either fresh or after corruption).
func InitializeIndexDB() (bool, error) {
	var err error
	journalMode := "OFF"
	if settings.Config.Server.IndexSqlConfig.WalMode {
		journalMode = "WAL"
	}
	batchSize := settings.Config.Server.IndexSqlConfig.BatchSize
	cacheSizeMB := settings.Config.Server.IndexSqlConfig.CacheSizeMB
	disableReuse := settings.Config.Server.IndexSqlConfig.DisableReuse
	var isNewDb bool
	indexDB, isNewDb, err = dbsql.NewIndexDB("all", journalMode, batchSize, cacheSizeMB, disableReuse)
	if err != nil {
		logger.Fatalf("failed to initialize index database: %v", err)
		return false, err
	}

	return isNewDb, nil
}

// GetIndexDB returns the shared index database.
func GetIndexDB() *dbsql.IndexDB {
	return indexDB
}

// StopAllScanners stops all scanners for all indexes
// This should be called during graceful shutdown before closing the database
func StopAllScanners() {
	indexesMutex.Lock()
	defer indexesMutex.Unlock()
	for _, idx := range indexes {
		idx.stopScheduler()
	}
}

// SetIndexDBForTesting sets the index database for testing purposes.
func SetIndexDBForTesting(db *dbsql.IndexDB) {
	indexDB = db
}

// SetIndexingStorage is removed; index metadata persists via SetMetaStore from app.WireServices.

func Initialize(source *settings.Source, mock bool, isNewDb bool) {
	indexesMutex.Lock()
	// Use shared database - all sources are differentiated by the source column
	if indexDB == nil {
		logger.Errorf("index database not initialized, call InitializeIndexDB() first")
		indexesMutex.Unlock()
		return
	}

	newIndex := Index{
		mock:                mock,
		Source:              *source,
		db:                  indexDB, // Use shared database
		scanUpdatedPaths:    make(map[string]bool),
		folderSizes:         make(map[string]uint64),   // In-memory folder size tracking
		folderSizesUnsynced: make(map[string]struct{}), // Track changed folders
		WebdavLock:          webdav.NewMemLS(),         // Initialize WebDAV lock system for this source
	}
	newIndex.ReducedIndex = ReducedIndex{
		Status:  "indexing",
		IdxName: source.Name,
		Stats: Stats{
			Complexity: 0,
		},
	}
	indexes[newIndex.Name] = &newIndex
	indexesMutex.Unlock()
	if !newIndex.Config.ResolvedRules.IndexingDisabled {
		logger.Infof("initializing index: [%v]", newIndex.Name)
		// Start multi-scanner system (each scanner will do its own initial scan)
		// Pass isNewDb flag so setupMultiScanner knows whether to load persisted complexity
		go newIndex.setupMultiScanner(isNewDb)
	} else {
		newIndex.Status = "ready"
		logger.Debug("indexing disabled for source: " + newIndex.Name)
	}
}

// PathContext contains all resolved information about a path
// Calculated ONCE to avoid duplicate stat calls and redundant checks
type PathContext struct {
	IndexPath string      // normalized path (dirs have trailing /)
	RealPath  string      // resolved filesystem path
	BaseName  string      // file/folder name only
	IsDir     bool        // directory or file
	IsHidden  bool        // starts with . or hidden attribute
	IsSymlink bool        // is symbolic link
	FileInfo  os.FileInfo // from stat call
}

// FileInfoRequest specifies what information to retrieve
type FileInfoRequest struct {
	IndexPath         string
	FollowSymlinks    bool
	BoundIndexPath    string // index prefix for symlink containment (e.g. user scope)
	ShowHidden        bool
	HideFileExt       string // Hide files based on their extension
	Expand            bool   // get child items for directories
	IsRoutineScan     bool   // scanner vs API call
	SkipExtendedAttrs bool   // whether to skip extended attributes
}

// filesystemBound resolves the filesystem path for an index prefix under this source.
func (idx *Index) filesystemBound(boundIndexPath string) (string, error) {
	bound := boundIndexPath
	if bound == "" {
		bound = "/"
	}
	fsPath := idx.Path
	if bound != "/" {
		fsPath = utils.JoinUnderSourceRoot(idx.Path, bound)
	}
	abs, err := filepath.Abs(fsPath)
	if err != nil {
		return "", err
	}
	return filepath.EvalSymlinks(abs)
}

// ensureResolvedContained rejects resolved filesystem paths outside the source or scope prefix.
func (idx *Index) ensureResolvedContained(realPath, boundIndexPath string) error {
	sourceRoot, err := idx.filesystemBound("/")
	if err != nil {
		return err
	}
	if err := iteminfo.PathWithinRoot(sourceRoot, realPath); err != nil {
		return errors.ErrPathEscapesScope
	}
	bound := boundIndexPath
	if bound == "" {
		bound = "/"
	}
	if bound != "/" {
		scopeRoot, err := idx.filesystemBound(bound)
		if err != nil {
			return err
		}
		if err := iteminfo.PathWithinRoot(scopeRoot, realPath); err != nil {
			return errors.ErrPathEscapesScope
		}
	}
	return nil
}

// resolveSymlinksContained resolves symlinks and ensures the target stays within bounds.
func (idx *Index) resolveSymlinksContained(fsPath, boundIndexPath string) (string, error) {
	resolved, err := filepath.EvalSymlinks(fsPath)
	if err != nil {
		return "", err
	}
	if err := idx.ensureResolvedContained(resolved, boundIndexPath); err != nil {
		return "", err
	}
	return resolved, nil
}

// resolvePathContext resolves all path characteristics in a SINGLE stat call
// This eliminates duplicate stat/lstat calls and redundant isHidden/isSymlink checks
func (idx *Index) resolvePathContext(indexPath string, followSymlinks bool, boundIndexPath string) (*PathContext, error) {
	realPath := utils.JoinUnderSourceRoot(idx.Path, indexPath)

	// ONE filesystem stat call
	fileInfo, err := os.Lstat(realPath)
	if err != nil {
		return nil, err
	}

	isSymlink := fileInfo.Mode()&os.ModeSymlink != 0

	// Resolve symlink if requested
	if isSymlink && followSymlinks {
		realPath, err = idx.resolveSymlinksContained(realPath, boundIndexPath)
		if err != nil {
			return nil, err
		}
		fileInfo, err = os.Stat(realPath)
		if err != nil {
			return nil, err
		}
	}

	isDir := fileInfo.IsDir()

	// Normalize path (directories get trailing slash)
	normalizedPath := indexPath
	if isDir && !strings.HasSuffix(indexPath, "/") {
		normalizedPath += "/"
	}

	baseName := filepath.Base(strings.TrimSuffix(normalizedPath, "/"))
	if normalizedPath == "/" {
		baseName = filepath.Base(idx.Path)
	}

	return &PathContext{
		IndexPath: normalizedPath,
		RealPath:  realPath,
		BaseName:  baseName,
		IsDir:     isDir,
		IsHidden:  IsHidden(realPath),
		IsSymlink: isSymlink,
		FileInfo:  fileInfo,
	}, nil
}

// evaluateIndexRules checks if a path should be accessible based on index rules
// Returns whether the path is viewable and/or indexable
// Does NOT check user permissions (that's handled in the API layer)
func (idx *Index) evaluateIndexRules(ctx *PathContext, isRoutineScan bool) (isViewable bool, isIndexable bool) {
	// For scanner (routine scan), only check the item itself
	// For API requests, check item and all parent paths
	if isRoutineScan {
		isViewable = idx.IsViewable(ctx.IsDir, ctx.IndexPath, ctx.IsSymlink, ctx.IsHidden)
	} else {
		isViewable = idx.IsViewableWithParentCheck(ctx.IsDir, ctx.IndexPath, ctx.IsSymlink, ctx.IsHidden)
	}

	shouldSkip := idx.ShouldSkip(ctx.IsDir, ctx.IndexPath, ctx.IsHidden, ctx.IsSymlink, isRoutineScan)
	isIndexable = !shouldSkip
	return isViewable, isIndexable
}

// GetFileInfo is the unified entry point for retrieving file/directory information
// It applies index rules (IsViewable/ShouldSkip) but does NOT check user permissions
// User permission checking happens in the API layer (FileInfoFaster)
func (idx *Index) GetFileInfo(req FileInfoRequest) (*iteminfo.FileInfo, error) {
	// 1. Resolve path context (single stat call)
	ctx, err := idx.resolvePathContext(req.IndexPath, req.FollowSymlinks, req.BoundIndexPath)
	if err != nil {
		return nil, err
	}

	// 2. Apply index rules (non-routine scan)
	isViewable, isIndexable := idx.evaluateIndexRules(ctx, false)
	// API request: path must be viewable
	if !isViewable {
		return nil, errors.ErrNotViewable
	}

	// 3. Return appropriate info
	if !ctx.IsDir {
		// Single file
		return idx.getFileInfoFromContext(ctx, isIndexable)
	}

	// Directory
	if req.Expand {
		// Get directory with children
		return idx.getDirInfoFromContext(ctx, isViewable, isIndexable, req)
	}

	// Just directory metadata (no children)
	return idx.getBasicDirInfo(ctx), nil
}

// getFileInfoFromContext returns info for a single file
func (idx *Index) getFileInfoFromContext(ctx *PathContext, isIndexable bool) (*iteminfo.FileInfo, error) {
	size := idx.getFileSizeForDisplay(ctx.FileInfo)
	fileInfo := &iteminfo.FileInfo{
		Path: ctx.IndexPath,
		ItemInfo: iteminfo.ItemInfo{
			Name:    ctx.BaseName,
			Size:    size,
			Created: getCreatedTime(ctx.FileInfo, ctx.RealPath),
			ModTime: ctx.FileInfo.ModTime(),
			Hidden:  ctx.IsHidden,
		},
	}
	fileInfo.DetectType(ctx.RealPath, false)

	// Set preview flags
	setFilePreviewFlags(&fileInfo.ItemInfo, ctx.RealPath)

	return fileInfo, nil
}

// getDirInfoFromContext gets full directory info using PathContext
func (idx *Index) getDirInfoFromContext(ctx *PathContext, isViewable, isIndexable bool, req FileInfoRequest) (*iteminfo.FileInfo, error) {
	dir, err := os.Open(ctx.RealPath)
	if err != nil {
		return nil, err
	}
	defer dir.Close()

	opts := Options{
		Recursive:         false,
		CheckViewable:     true,
		IsRoutineScan:     req.IsRoutineScan,
		SkipExtendedAttrs: req.SkipExtendedAttrs || !isIndexable,
		FollowSymlinks:    req.FollowSymlinks,
		ShowHidden:        req.ShowHidden,
		HideFileExt:       req.HideFileExt,
	}

	return idx.GetDirInfoCore(dir, ctx.FileInfo, ctx.IndexPath, opts, nil)
}

// getBasicDirInfo returns just directory metadata without children
func (idx *Index) getBasicDirInfo(ctx *PathContext) *iteminfo.FileInfo {
	return &iteminfo.FileInfo{
		Path: ctx.IndexPath,
		ItemInfo: iteminfo.ItemInfo{
			Name:    ctx.BaseName,
			Type:    "directory",
			Size:    0,
			Created: getCreatedTime(ctx.FileInfo, ctx.RealPath),
			ModTime: ctx.FileInfo.ModTime(),
			Hidden:  ctx.IsHidden,
		},
	}
}

// Define a function to recursively index files and directories
func (idx *Index) indexDirectory(indexPath string, opts Options, scanner *Scanner) (int64, bool, error) {
	if !strings.HasSuffix(indexPath, "/") {
		indexPath = indexPath + "/"
	}
	realPath := utils.JoinUnderSourceRoot(idx.Path, indexPath)

	// Open the directory
	dir, err := os.Open(realPath)
	if err != nil {
		// must have been deleted
		return 0, false, err
	}
	defer dir.Close()

	dirInfo, err := dir.Stat()
	if err != nil {
		return 0, false, err
	}

	// check if excluded from indexing
	hidden := IsHidden(realPath)
	isSymlink := dirInfo.Mode()&os.ModeSymlink != 0
	if idx.ShouldSkip(dirInfo.IsDir(), indexPath, hidden, isSymlink, true) {
		return 0, false, errors.ErrNotIndexed
	}

	dirFileInfo, err2 := idx.GetDirInfo(dir, dirInfo, indexPath, opts, scanner)
	if err2 != nil {
		return 0, false, err2
	}
	idx.UpdateMetadata(dirFileInfo, scanner, !opts.Recursive)

	// Always store the calculated directory size in the in-memory map
	// This ensures parent directories are updated after copy/move operations
	idx.SetFolderSize(indexPath, uint64(dirFileInfo.Size))

	return dirFileInfo.Size, dirFileInfo.HasPreview, nil
}

// GetFsInfoCore is the consolidated implementation for both GetFsInfo and GetFsInfoViewableOnly
func (idx *Index) GetFsInfoCore(indexPath string, opts Options) (*iteminfo.FileInfo, error) {
	// Handle symlinks if not following them
	realPath := utils.JoinUnderSourceRoot(idx.Path, indexPath)
	if opts.FollowSymlinks {
		var err error
		realPath, err = idx.resolveSymlinksContained(realPath, "/")
		if err != nil {
			return nil, err
		}
	}

	dir, err := os.Open(realPath)
	if err != nil {
		return nil, err
	}
	defer dir.Close()

	dirInfo, err2 := dir.Stat()
	if err2 != nil {
		return nil, err2
	}
	baseName := filepath.Base(indexPath)
	if indexPath == "/" {
		baseName = filepath.Base(idx.Path)
	}

	// Handle file case
	if !dirInfo.IsDir() {
		// Check if item is accessible
		hidden := IsHidden(realPath)
		isSymlink := dirInfo.Mode()&os.ModeSymlink != 0
		isViewable := idx.IsViewable(dirInfo.IsDir(), indexPath, isSymlink, hidden)
		isSkipped := idx.ShouldSkip(dirInfo.IsDir(), indexPath, hidden, isSymlink, false)

		// Deny access if not viewable AND skipped
		if opts.CheckViewable {
			if !isViewable {
				return nil, errors.ErrNotViewable
			}
		} else if isSkipped {
			return nil, errors.ErrNotViewable
		}

		realSize, _ := idx.handleFile(dirInfo, indexPath, realPath, false, nil)
		fileInfo := &iteminfo.FileInfo{
			Path: indexPath,
			ItemInfo: iteminfo.ItemInfo{
				Name:    baseName,
				Size:    int64(realSize),
				Created: getCreatedTime(dirInfo, realPath),
				ModTime: dirInfo.ModTime(),
			},
		}
		fileInfo.DetectType(realPath, false)
		// Set preview flags unless explicitly skipped
		if !opts.SkipExtendedAttrs {
			setFilePreviewFlags(&fileInfo.ItemInfo, realPath)
		}
		return fileInfo, nil
	}

	// Handle directory case
	response, err := idx.GetDirInfoCore(dir, dirInfo, indexPath, opts, nil)
	if err != nil {
		return nil, err
	}

	// Handle file-in-directory case
	if !dirInfo.IsDir() {
		for _, item := range response.Files {
			if item.Name == baseName {
				return &iteminfo.FileInfo{
					Path:     utils.JoinPathAsUnix(indexPath, item.Name),
					ItemInfo: item.ItemInfo,
				}, nil
			}
		}
		return nil, fmt.Errorf("file not found in directory: %s", indexPath)
	}

	return response, nil
}

// GetFsInfo returns filesystem information with index checks and extended attributes
func (idx *Index) GetFsInfo(adjustedPath string, followSymlinks bool, showHidden bool) (*iteminfo.FileInfo, error) {
	return idx.GetFsInfoCore(adjustedPath, Options{
		Recursive:         false,
		CheckViewable:     true,
		IsRoutineScan:     false,
		SkipExtendedAttrs: false,
		FollowSymlinks:    followSymlinks,
		ShowHidden:        showHidden,
	})
}

// GetFsInfoViewableOnly returns filesystem information for viewable-only paths (not indexed)
func (idx *Index) GetFsInfoViewableOnly(adjustedPath string, followSymlinks bool, showHidden bool) (*iteminfo.FileInfo, error) {
	return idx.GetFsInfoCore(adjustedPath, Options{
		Recursive:         false,
		CheckViewable:     true,
		IsRoutineScan:     false,
		SkipExtendedAttrs: true,
		FollowSymlinks:    followSymlinks,
		ShowHidden:        showHidden,
	})
}

// fetchExtendedAttributes loads indexed subfolder has_preview for the current directory from GetMetadataInfo (database).
// The listed directory's own HasPreview is derived only in GetDirInfoCore from children (never from a stale parent DB row).
func (idx *Index) fetchExtendedAttributes(indexPath string, opts Options) map[string]bool {
	subdirHasPreviewMap := make(map[string]bool)

	if opts.SkipExtendedAttrs || opts.Recursive {
		return subdirHasPreviewMap
	}

	realDirInfo, exists := idx.GetMetadataInfo(indexPath, true, false)
	if !exists {
		return subdirHasPreviewMap
	}

	for _, folder := range realDirInfo.Folders {
		key := utils.AddTrailingSlashIfNotExists(indexPath + folder.Name)
		subdirHasPreviewMap[key] = folder.HasPreview
	}

	return subdirHasPreviewMap
}

// processDirectoryItem processes a directory item and returns the itemInfo, size, and whether it should be counted
func (idx *Index) processDirectoryItem(file os.FileInfo, indexPath string, subdirHasPreviewMap map[string]bool, opts Options, scanner *Scanner) (*iteminfo.ItemInfo, int64, bool) {
	dirPath := indexPath + file.Name()

	// Check NeverWatchPaths for recursive scans (scanner only)
	if opts.IsRoutineScan && idx.IsNeverWatchPath(indexPath) {
		return nil, 0, false
	}

	// Skip non-indexable dirs
	if omitList[file.Name()] {
		return nil, 0, false
	}

	itemInfo := &iteminfo.ItemInfo{
		Name:    file.Name(),
		Created: getCreatedTime(file, utils.JoinPathAsUnix(idx.Path, indexPath, file.Name())),
		ModTime: file.ModTime(),
		Hidden:  IsHidden(utils.JoinPathAsUnix(idx.Path, indexPath, file.Name())),
		Type:    "directory",
	}

	if opts.Recursive {
		// Recursive: index the subdirectory
		subdirSize, subdirHasPreview, err := idx.indexDirectory(dirPath, opts, scanner)
		if err != nil {
			logger.Errorf("Failed to index directory %s: %v", dirPath, err)
			return nil, 0, false
		}
		// Apply minimum 4KB for directories only in disk usage mode
		if !idx.Config.UseLogicalSize && subdirSize < 4096 {
			subdirSize = 4096
		}
		itemInfo.Size = subdirSize
		itemInfo.HasPreview = subdirHasPreview
		return itemInfo, itemInfo.Size, true
	}

	// Non-recursive: get folder size and hasPreview from cache
	childIndexPath := utils.AddTrailingSlashIfNotExists(dirPath)
	itemInfo.Size = idx.GetFolderSizeForDisplay(childIndexPath)

	// Use batched hasPreview map if available
	if !opts.SkipExtendedAttrs && subdirHasPreviewMap != nil {
		if hasPreviewValue, exists := subdirHasPreviewMap[childIndexPath]; exists {
			itemInfo.HasPreview = hasPreviewValue
		}
	}

	return itemInfo, itemInfo.Size, true
}

// processFileItem processes a file item and returns the itemInfo, size, shouldCount, and whether it bubbles up hasPreview
func (idx *Index) processFileItem(file os.FileInfo, indexPath string, opts Options, scanner *Scanner) (*iteminfo.ItemInfo, int64, bool, bool) {

	fullCombined := utils.JoinPathAsUnix(idx.Path, indexPath, file.Name())
	itemInfo := &iteminfo.ItemInfo{
		Name:    file.Name(),
		Created: getCreatedTime(file, fullCombined),
		ModTime: file.ModTime(),
		Hidden:  IsHidden(fullCombined),
	}
	itemInfo.DetectType(fullCombined, false)

	// For API calls (non-recursive, no scanner), use appropriate size calculation
	// For scanning (recursive or with scanner), use handleFile for hardlink detection
	var size uint64
	var shouldCountSize bool
	if !opts.Recursive && scanner == nil {
		size = uint64(idx.getFileSizeForDisplay(file))
		shouldCountSize = true
	} else {
		size, shouldCountSize = idx.handleFile(file, indexPath, fullCombined, opts.IsRoutineScan, scanner)
	}
	itemInfo.Size = int64(size)

	// Extended attributes for files
	bubblesUpHasPreview := false
	if !opts.SkipExtendedAttrs {
		usedCachedPreview := false
		if !idx.Config.ResolvedRules.IndexingDisabled && opts.Recursive {
			simpleType := strings.Split(itemInfo.Type, "/")[0]
			if simpleType == "audio" {
				previousInfo, exists := idx.GetReducedMetadata(fullCombined, false)
				if exists && time.Time.Equal(previousInfo.ModTime, file.ModTime()) {
					itemInfo.HasPreview = previousInfo.HasPreview
					usedCachedPreview = true
				}
			}
		}
		if !usedCachedPreview {
			setFilePreviewFlags(itemInfo, fullCombined)
		}
		bubblesUpHasPreview = iteminfo.ShouldBubbleUpToFolderPreview(*itemInfo)
	} else {
		itemInfo.HasPreview = false
	}

	return itemInfo, itemInfo.Size, shouldCountSize, bubblesUpHasPreview
}

// GetDirInfoCore is the consolidated implementation for both GetDirInfo and GetDirInfoViewableOnly
func (idx *Index) GetDirInfoCore(dirInfo *os.File, stat os.FileInfo, indexPath string, opts Options, scanner *Scanner) (*iteminfo.FileInfo, error) {
	if !strings.HasSuffix(indexPath, "/") {
		indexPath = indexPath + "/"
	}
	files, err := dirInfo.Readdir(-1)
	if err != nil {
		return nil, err
	}
	subdirHasPreviewMap := idx.fetchExtendedAttributes(indexPath, opts)

	baseName := filepath.Base(indexPath)
	if indexPath == "/" {
		baseName = filepath.Base(idx.Path)
	}

	var totalSize int64
	fileInfos := []iteminfo.ExtendedItemInfo{}
	dirInfos := []iteminfo.ItemInfo{}
	processedCount := 0
	hasPreview := false

	for _, file := range files {
		subfileBaseName := file.Name()
		isDir := iteminfo.IsDirectory(file)
		fullCombined := indexPath + subfileBaseName
		// Add trailing slash for directories to match normalized folder paths
		if isDir {
			fullCombined = fullCombined + "/"
		}
		hidden := IsHidden(utils.JoinPathAsUnix(idx.Path, indexPath, subfileBaseName))
		isSymlink := file.Mode()&os.ModeSymlink != 0

		// Check if item should be skipped
		shouldSkip := false

		// Check hidden files
		if !opts.ShowHidden && hidden {
			shouldSkip = true
		}

		// Check root include rules
		if !shouldSkip && indexPath == "/" && !idx.shouldInclude(subfileBaseName) {
			shouldSkip = true
		}

		// Check viewable/indexable rules
		if !shouldSkip {
			isViewable := idx.IsViewable(isDir, fullCombined, isSymlink, hidden)
			isSkipped := idx.ShouldSkip(isDir, fullCombined, hidden, isSymlink, opts.IsRoutineScan)
			if opts.CheckViewable {
				shouldSkip = !isViewable && isSkipped
			} else {
				shouldSkip = isSkipped
			}
		}
		if shouldSkip {
			continue
		}
		processedCount++

		if isDir {
			itemInfo, size, shouldCount := idx.processDirectoryItem(file, indexPath, subdirHasPreviewMap, opts, scanner)
			if itemInfo == nil {
				continue
			}
			if shouldCount {
				totalSize += size
			}
			dirInfos = append(dirInfos, *itemInfo)
			if opts.Recursive && opts.IsRoutineScan {
				idx.incrementScannerDirs()
			}
		} else {
			itemInfo, size, shouldCount, bubblesUp := idx.processFileItem(file, indexPath, opts, scanner)
			if bubblesUp {
				hasPreview = true
			}
			if shouldCount {
				totalSize += size
			}
			fileInfos = append(fileInfos, iteminfo.ExtendedItemInfo{ItemInfo: *itemInfo})
			if opts.IsRoutineScan {
				idx.incrementScannerFiles()
			}
		}
	}

	// Check ignoreZeroSizeFolders: works consistently regardless of size calculation mode
	// In logical mode: folders with no files will have totalSize=0
	// In disk usage mode: folders with no files will have totalSize>0 from 4KB minimums,
	//                     but we check if there are no actual files/folders processed
	if idx.Config.ResolvedRules.IgnoreAllZeroSizeFolders && indexPath != "/" {
		// If using logical size, check totalSize==0
		// If using disk usage, check if we have no files AND no folders (truly empty)
		isEmpty := false
		if idx.Config.UseLogicalSize {
			isEmpty = (totalSize == 0)
		} else {
			// In disk usage mode, check if directory has no actual content
			// (processedCount will be 0 if truly empty)
			isEmpty = (len(fileInfos) == 0 && len(dirInfos) == 0)
		}

		if isEmpty {
			return nil, errors.ErrNotIndexed
		}
	}

	dirFileInfo := &iteminfo.FileInfo{
		Path:    indexPath,
		Files:   fileInfos,
		Folders: dirInfos,
	}
	dirFileInfo.ItemInfo = iteminfo.ItemInfo{
		Name:       baseName,
		Type:       "directory",
		Size:       totalSize,
		Created:    getCreatedTime(stat, dirInfo.Name()),
		ModTime:    stat.ModTime(),
		HasPreview: hasPreview,
	}
	dirFileInfo.SortItems()

	return dirFileInfo, nil
}

// GetDirInfo returns directory information with index checks and extended attributes
func (idx *Index) GetDirInfo(dirInfo *os.File, stat os.FileInfo, indexPath string, opts Options, scanner *Scanner) (*iteminfo.FileInfo, error) {
	// Ensure filesystem options are set correctly for indexed paths
	opts.SkipExtendedAttrs = false
	return idx.GetDirInfoCore(dirInfo, stat, indexPath, opts, scanner)
}

func (idx *Index) GetRealPath(relativePath ...string) (string, bool, error) {
	return idx.getRealPathInternal("/", false, relativePath...)
}

// GetRealPathScoped resolves an index path and rejects symlink targets outside the source and bound prefix.
func (idx *Index) GetRealPathScoped(boundIndexPath string, relativePath ...string) (string, bool, error) {
	return idx.getRealPathInternal(boundIndexPath, true, relativePath...)
}

func (idx *Index) getRealPathInternal(boundIndexPath string, enforceScope bool, relativePath ...string) (string, bool, error) {
	parts := make([]string, 0, len(relativePath)+1)
	parts = append(parts, idx.Path)
	for _, p := range relativePath {
		parts = append(parts, utils.CleanIndexPathSegment(p))
	}
	joinedPath := filepath.Join(parts...)
	bound := boundIndexPath
	if enforceScope && bound == "" {
		bound = "/"
	}
	cacheKey := fmt.Sprintf("realpath|scoped=%t|bound=%q|path=%q", enforceScope, bound, joinedPath)
	isDir, _ := IsDirCache.Get(cacheKey + ":isdir")
	cached, ok := RealPathCache.Get(cacheKey)
	if ok && cached != "" {
		return cached, isDir, nil
	}
	absolutePath, err := filepath.Abs(joinedPath)
	if err != nil {
		return absolutePath, false, fmt.Errorf("could not get real path: %v, %s", joinedPath, err)
	}
	realPath, isDir, err := iteminfo.ResolveSymlinks(absolutePath)
	if err != nil {
		return realPath, isDir, err
	}
	if enforceScope {
		if err := idx.ensureResolvedContained(realPath, boundIndexPath); err != nil {
			return "", false, err
		}
	} else if err := idx.ensureResolvedContained(realPath, "/"); err != nil {
		return "", false, err
	}
	RealPathCache.Set(cacheKey, realPath)
	IsDirCache.Set(cacheKey+":isdir", isDir)
	return realPath, isDir, nil
}

func (idx *Index) RefreshFileInfo(opts utils.FileOptions) error {
	// For files, refresh the parent directory
	if !opts.IsDir {
		parentPath := idx.MakeIndexPath(filepath.Dir(opts.Path), true).String()
		return idx.RefreshDirectory(parentPath, false) // non-recursive for file changes
	}

	// For directories, use the recursive flag from opts
	indexPath := idx.MakeIndexPath(opts.Path, true).String()
	return idx.RefreshDirectory(indexPath, opts.Recursive)
}

// RefreshDirectory re-indexes a directory and updates its cached size
// Use recursive=true for copy/move operations to capture entire tree
// Use recursive=false for simple metadata updates (like after file edits)
func (idx *Index) RefreshDirectory(indexPath string, recursive bool) error {
	if idx.Config.ResolvedRules.IndexingDisabled {
		return nil
	}

	if !strings.HasSuffix(indexPath, "/") {
		indexPath = indexPath + "/"
	}

	realPath := utils.JoinUnderSourceRoot(idx.Path, indexPath)

	// Check if directory exists
	dirInfo, err := os.Stat(realPath)
	if err != nil {
		// Directory deleted - clear from cache and update parents
		idx.folderSizesMu.Lock()
		previousSize, exists := idx.folderSizes[indexPath]
		delete(idx.folderSizes, indexPath)
		delete(idx.folderSizesUnsynced, indexPath)
		idx.folderSizesMu.Unlock()

		if exists && previousSize > 0 {
			idx.updateFolderSizeAndParents(indexPath, 0, previousSize, false)
		}
		return nil
	}

	if !dirInfo.IsDir() {
		return fmt.Errorf("path is not a directory: %s", indexPath)
	}

	// Check if excluded from indexing
	hidden := IsHidden(realPath)
	isSymlink := dirInfo.Mode()&os.ModeSymlink != 0
	if idx.ShouldSkip(true, indexPath, hidden, isSymlink, false) {
		return errors.ErrNotIndexed
	}

	// Use indexDirectory for proper recursive indexing
	opts := Options{
		Recursive:     recursive,
		IsRoutineScan: false,
		CheckViewable: false,
	}

	_, _, err = idx.indexDirectory(indexPath, opts, nil)
	return err
}

// updateFolderSizeAndParents updates a folder size and propagates the change to all parents
func (idx *Index) updateFolderSizeAndParents(path string, newSize uint64, previousSize uint64, updateTarget bool) {
	// Calculate the delta
	var sizeDelta int64
	if newSize >= previousSize {
		sizeDelta = int64(newSize - previousSize)
	} else {
		sizeDelta = -int64(previousSize - newSize)
	}

	if sizeDelta == 0 && !updateTarget {
		return // No change, nothing to propagate
	}

	idx.folderSizesMu.Lock()
	defer idx.folderSizesMu.Unlock()

	// Optionally update the target folder itself
	if updateTarget {
		idx.folderSizes[path] = newSize
		idx.folderSizesUnsynced[path] = struct{}{}
	}

	if sizeDelta == 0 {
		return // No parent updates needed
	}

	// Walk up the parent chain and update all parents
	currentPath := path
	for {
		parentDir := utils.GetParentDirectoryPath(currentPath)
		if parentDir == "" {
			break // Reached the top
		}
		// Keys in folderSizes match indexing paths (trailing slash for non-root dirs; root stays "/").
		if parentDir != "/" {
			parentDir = utils.AddTrailingSlashIfNotExists(parentDir)
		}

		// Update parent size with delta
		parentSize := idx.folderSizes[parentDir]
		if sizeDelta > 0 {
			idx.folderSizes[parentDir] = parentSize + uint64(sizeDelta)
		} else {
			// Prevent underflow
			absDelta := uint64(-sizeDelta)
			if parentSize >= absDelta {
				idx.folderSizes[parentDir] = parentSize - absDelta
			} else {
				logger.Warningf("[FOLDER_SIZE] Parent %s would underflow (%d - %d), setting to 0",
					parentDir, parentSize, absDelta)
				idx.folderSizes[parentDir] = 0
			}
		}
		idx.folderSizesUnsynced[parentDir] = struct{}{} // Mark parent as unsynced

		// Move up to the next parent
		currentPath = parentDir
	}
}

// GetFolderSizeForDisplay retrieves folder size with appropriate formatting based on config
func (idx *Index) GetFolderSizeForDisplay(path string) int64 {
	size, exists := idx.GetFolderSizeForIndexPath(path)
	if !exists {
		// No cached size - return appropriate default
		if idx.Config.UseLogicalSize {
			return 0 // Logical mode: empty directory = 0
		}
		return 4096 // Disk usage mode: minimum 4KB
	}

	// Apply 4KB minimum in disk usage mode
	if !idx.Config.UseLogicalSize && size < 4096 {
		return 4096
	}

	return int64(size)
}

// getFileSizeForDisplay returns file size with appropriate calculation based on config
func (idx *Index) getFileSizeForDisplay(file os.FileInfo) int64 {
	if idx.Config.UseLogicalSize {
		// Logical size mode: return actual bytes
		return file.Size()
	}

	// Disk usage mode: use getDiskUsage helper
	return getDiskUsage(file, false)
}

// SyncFolderSizesToDB syncs in-memory folder sizes to the database after a scan completes
// Only syncs folders marked as dirty (changed) and processes in batches to avoid large SQL statements
func (idx *Index) SyncFolderSizesToDB() error {

	idx.folderSizesMu.Lock()

	// Collect only dirty (changed) folder sizes
	sizesToSync := make(map[string]uint64)
	for path := range idx.folderSizesUnsynced {
		if size, exists := idx.folderSizes[path]; exists {
			sizesToSync[path] = size
		}
	}
	idx.folderSizesMu.Unlock()

	if len(sizesToSync) == 0 {
		return nil
	}

	// Process in batches of 1000 to avoid massive SQL statements
	const batchSize = 1000
	paths := make([]string, 0, len(sizesToSync))
	for path := range sizesToSync {
		paths = append(paths, path)
	}

	totalUpdated := int64(0)
	for i := 0; i < len(paths); i += batchSize {
		end := i + batchSize
		if end > len(paths) {
			end = len(paths)
		}

		batchPaths := paths[i:end]
		batchMap := make(map[string]uint64, len(batchPaths))
		for _, path := range batchPaths {
			batchMap[path] = sizesToSync[path]
		}

		rowsUpdated, err := idx.db.UpdateFolderSizesIfChanged(idx.Name, batchMap)
		if err != nil {
			logger.Errorf("[FOLDER_SIZE_SYNC] Failed to update folder sizes batch %d-%d: %v", i, end, err)
			return err
		}
		totalUpdated += rowsUpdated

		// Remove synced paths from unsynced map
		idx.folderSizesMu.Lock()
		for _, path := range batchPaths {
			delete(idx.folderSizesUnsynced, path)
		}
		idx.folderSizesMu.Unlock()

		if rowsUpdated > 0 {
			logger.Debugf("[FOLDER_SIZE_SYNC] Batch %d-%d: updated %d folders (skipped %d unchanged)",
				i, end, rowsUpdated, len(batchPaths)-int(rowsUpdated))
		}
	}

	if totalUpdated > 0 {
		logger.Infof("[FOLDER_SIZE_SYNC] Updated %d folder sizes (skipped %d unchanged)",
			totalUpdated, len(sizesToSync)-int(totalUpdated))
	}

	return nil
}

func IsHidden(realPath string) bool {
	if filepath.Base(realPath)[0] == '.' {
		return true
	}
	if runtime.GOOS == "windows" {
		return CheckWindowsHidden(realPath)
	}
	// Default behavior for non-Windows systems
	return false
}

// setFilePreviewFlags determines if a file should have a preview based on its type
func setFilePreviewFlags(fileInfo *iteminfo.ItemInfo, realPath string) {
	if fileInfo.Size == 0 {
		return
	}
	simpleType := strings.Split(fileInfo.Type, "/")[0]
	switch fileInfo.Type {
	case "image/heic", "image/heif":
		if fileInfo.Size > iteminfo.LargeFileSizeThreshold {
			fileInfo.HasPreview = false
			return
		}
		fileInfo.HasPreview = settings.CanConvertImage("heic")
		return
	}
	switch simpleType {
	case "image":
		if fileInfo.Size > iteminfo.LargeFileSizeThreshold {
			fileInfo.HasPreview = false
			return
		}
		fileInfo.HasPreview = true
		return
	case "video":
		ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(fileInfo.Name)), ".")
		fileInfo.HasPreview = settings.CanConvertVideo(ext)
		return
	case "audio":
		ext := strings.ToLower(filepath.Ext(fileInfo.Name))
		hasArt := iteminfo.HasAlbumArt(realPath, ext)
		fileInfo.HasPreview = hasArt
		return
	}
	// Check for office docs and PDFs
	if settings.Config.Integrations.OnlyOffice.Secret != "" && iteminfo.IsOnlyOffice(fileInfo.Name) {
		fileInfo.HasPreview = true
		return
	}
	if iteminfo.HasDocConvertableExtension(fileInfo.Name, fileInfo.Type) {
		fileInfo.HasPreview = true
		return
	}
}

// IsViewable checks if a path is viewable (allows FS access)
// Only checks the item itself, not parent paths
func (idx *Index) IsViewable(isDir bool, indexPath string, isSymlink bool, isHidden bool) bool {
	if indexPath == "/" || idx.Config.ResolvedRules.NoRules {
		return true
	}

	rules := idx.Config.ResolvedRules

	// Check if hidden and should be blocked
	if isHidden && rules.IgnoreAllHidden {
		return false
	}

	// Check symlinks
	if isSymlink && rules.IgnoreAllSymlinks {
		return false
	}

	baseName := filepath.Base(indexPath)

	if isDir {
		// Check folder rules
		if rule, exists := rules.FolderNames[baseName]; exists {
			return rule.Viewable
		}
		if rule, exists := rules.FolderPaths[indexPath]; exists {
			return rule.Viewable
		}
		for _, rule := range rules.FolderEndsWith {
			if strings.HasSuffix(baseName, rule.FolderEndsWith) {
				return rule.Viewable
			}
		}
		for _, rule := range rules.FolderStartsWith {
			if strings.HasPrefix(baseName, rule.FolderStartsWith) {
				return rule.Viewable
			}
		}
	} else {
		// Check file rules
		if rule, exists := rules.FileNames[baseName]; exists {
			return rule.Viewable
		}
		if rule, exists := rules.FilePaths[indexPath]; exists {
			return rule.Viewable
		}
		for _, rule := range rules.FileEndsWith {
			if strings.HasSuffix(baseName, rule.FileEndsWith) {
				return rule.Viewable
			}
		}
		for _, rule := range rules.FileStartsWith {
			if strings.HasPrefix(baseName, rule.FileStartsWith) {
				return rule.Viewable
			}
		}
	}

	return true // Default: viewable unless explicitly set to false
}

// IsViewableWithParentCheck checks if a path is viewable by walking up the directory tree
// Used for API requests where we need to check inherited rules from parent folders
func (idx *Index) IsViewableWithParentCheck(isDir bool, indexPath string, isSymlink bool, isHidden bool) bool {
	if idx.Config.ResolvedRules.IndexingDisabled || idx.Config.ResolvedRules.NoRules {
		return true
	}

	// Check the item itself - if not viewable, stop here
	if !idx.IsViewable(isDir, indexPath, isSymlink, isHidden) {
		return false
	}

	// Item is viewable, now check parent recursively
	parentDir := utils.GetParentDirectoryPath(indexPath)
	if parentDir == "" || parentDir == "/" {
		return true // Reached root with no non-viewable rules, default to viewable
	}

	// Check if parent is hidden
	realPath, _, _ := idx.GetRealPath(parentDir)
	return idx.IsViewableWithParentCheck(true, parentDir, false, IsHidden(realPath))
}

// ShouldSkip checks if a path should be skipped from indexing
// isRoutineScan: true for scanner (no parent checks), false for API (check parents)
func (idx *Index) ShouldSkip(isDir bool, adjustedPath string, isHidden bool, isSymlink bool, isRoutineScan bool) bool {
	if idx.Config.ResolvedRules.IndexingDisabled {
		return true
	}
	rules := idx.Config.ResolvedRules
	if adjustedPath == "/" || rules.NoRules {
		return false
	}
	if isHidden && rules.IgnoreAllHidden {
		return true
	}
	if isSymlink && rules.IgnoreAllSymlinks {
		return true
	}
	baseName := filepath.Base(adjustedPath)

	if isDir {
		// Check exact name match
		if _, ok := rules.FolderNames[baseName]; ok {
			return true
		}
		// Check exact path match
		if _, ok := rules.FolderPaths[adjustedPath]; ok {
			return true
		}
		// For API calls (not routine scan), check parent paths too
		if !isRoutineScan {
			for path := range rules.FolderPaths {
				if strings.HasPrefix(adjustedPath, path) {
					return true
				}
			}
		}
		// Check suffix match
		for _, rule := range rules.FolderEndsWith {
			if strings.HasSuffix(baseName, rule.FolderEndsWith) {
				return true
			}
		}
		// Check prefix match
		for _, rule := range rules.FolderStartsWith {
			if strings.HasPrefix(baseName, rule.FolderStartsWith) {
				return true
			}
		}
	} else {
		// Check exact name match
		if _, ok := rules.FileNames[baseName]; ok {
			return true
		}
		// Check exact path match
		if _, ok := rules.FilePaths[adjustedPath]; ok {
			return true
		}
		// For API calls (not routine scan), check parent paths too
		// Also check if file is inside a viewable-only folder
		if !isRoutineScan {
			for path, rule := range rules.FilePaths {
				if strings.HasPrefix(adjustedPath, path) && !rule.Viewable {
					return true
				}
			}
			// Check if file's parent folder is viewable (don't skip if parent allows viewing)
			for path, rule := range rules.FolderPaths {
				if strings.HasPrefix(adjustedPath, path) && !rule.Viewable {
					return true
				}
			}
		}
		// Check suffix match
		for _, rule := range rules.FileEndsWith {
			if strings.HasSuffix(baseName, rule.FileEndsWith) {
				return true
			}
		}
		// Check prefix match
		for _, rule := range rules.FileStartsWith {
			if strings.HasPrefix(baseName, rule.FileStartsWith) {
				return true
			}
		}
	}

	return false
}

// IsNeverWatchPath checks if a directory should not be re-indexed after the initial scan
// This is specifically for NeverWatchPaths - paths that are indexed once, then never watched again
// Returns true if the path should be skipped during routine scans (after initial indexing)
func (idx *Index) IsNeverWatchPath(adjustedPath string) bool {
	// Only apply NeverWatchPaths if we've completed at least one scan
	if idx.GetLastIndexed().IsZero() {
		return false // Initial scan - don't skip
	}

	rules := idx.Config.ResolvedRules
	if len(rules.NeverWatchPaths) == 0 {
		return false
	}

	// Check if this path is in NeverWatchPaths
	_, exists := rules.NeverWatchPaths[adjustedPath]
	return exists
}

func (idx *Index) SetUsage(aggregate, rootOnly fileutils.PartitionUsage, UsedAsIndexed uint64) {
	if settings.Config.Frontend.DisableUsedPercentage {
		return
	}
	idx.mu.Lock()
	defer idx.mu.Unlock()
	idx.DiskTotal = aggregate.Total
	idx.UsedAsIndexed = UsedAsIndexed
	idx.UsedDisk = aggregate.Used
	idx.DiskTotalRoot = rootOnly.Total
	idx.UsedDiskRoot = rootOnly.Used
}

func (idx *Index) SetStatus(status IndexStatus) error {
	idx.mu.Lock()
	idx.Status = status
	idx.mu.Unlock()
	return idx.SendSourceUpdateEvent()
}

// getActiveScannerPath returns the path of the currently active scanner, or empty string if none
// Assumes mutex is NOT held - will acquire its own lock
func (idx *Index) getActiveScannerPath() string {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.getActiveScannerPathUnlocked()
}

// getActiveScannerPathUnlocked returns the path of the currently active scanner, or empty string if none
func (idx *Index) getActiveScannerPathUnlocked() string {
	return idx.activeScannerPath
}

// input should be non-index path.
// isDir indicates whether the path is a directory (true) or file (false).
func (idx *Index) MakeIndexPath(path string, isDir bool) utils.IndexPath {
	if path == "." || strings.HasPrefix(path, "./") {
		path = strings.TrimPrefix(path, ".")
	}
	path = strings.TrimPrefix(path, idx.Path)
	path = idx.MakeIndexPathPlatform(path)
	return utils.IndexPathFromNormalized(path, isDir)
}

// MakeAbsolutePath converts a relative index path to an absolute path by combining
// the source path with the relative path. This ensures paths are unique across sources.
func (idx *Index) MakeAbsolutePath(indexPath string) string {
	return idx.Path + indexPath
}

func (idx *Index) shouldInclude(baseName string) bool {
	rules := idx.Config.ResolvedRules
	hasRules := false
	if len(rules.IncludeRootItems) > 0 {
		hasRules = true
		// Check with trailing slash since includeRootItems are normalized with trailing slashes
		if _, exists := rules.IncludeRootItems["/"+baseName+"/"]; exists {
			return true
		}
	}
	if !hasRules {
		return true
	}
	return false
}

// useAdaptiveScheduling reports whether the index uses tiered/aligned scheduling.
func (idx *Index) useAdaptiveScheduling() bool {
	return true
}

// Save persists the index and scanner information to the database and notifies clients via SSE.
func (idx *Index) Save() error {
	if err := idx.writePersistedIndexInfo(); err != nil {
		return err
	}
	if err := idx.SendSourceUpdateEvent(); err != nil {
		logger.Errorf("[%s] Failed to send source update event: %v", idx.Name, err)
	}
	return nil
}

// writePersistedIndexInfo writes scanners, stats, and disk totals to Bolt (no SSE broadcast).
func (idx *Index) writePersistedIndexInfo() error {
	if !metaStoreConfigured() {
		return nil
	}

	idx.mu.RLock()
	scanners := make(map[string]*dbindex.PersistedScannerInfo)
	for path, scanner := range idx.scanners {
		scanners[path] = &dbindex.PersistedScannerInfo{
			Path:            path,
			Complexity:      scanner.complexity,
			CurrentSchedule: scanner.currentSchedule,
			QuickScanTime:   scanner.quickScanTime,
			FullScanTime:    scanner.fullScanTime,
			NumDirs:         scanner.numDirs,
			NumFiles:        scanner.numFiles,
			LastScanned:     scanner.lastScanned,
		}
	}

	complexity := idx.getComplexityUnlocked()
	numDirs := idx.getNumDirsUnlocked()
	numFiles := idx.getNumFilesUnlocked()
	usedAsIndexed := idx.UsedAsIndexed
	usedDisk := idx.UsedDisk
	diskTotal := idx.DiskTotal
	usedDiskRoot := idx.UsedDiskRoot
	diskTotalRoot := idx.DiskTotalRoot
	idx.mu.RUnlock()

	info := &dbindex.IndexInfo{
		Path:          idx.Path,
		Source:        idx.Name,
		Complexity:    complexity,
		NumDirs:       numDirs,
		NumFiles:      numFiles,
		UsedAsIndexed: usedAsIndexed,
		UsedDisk:      usedDisk,
		DiskTotal:     diskTotal,
		UsedDiskRoot:  usedDiskRoot,
		DiskTotalRoot: diskTotalRoot,
		Scanners:      scanners,
	}

	return saveIndexInfo(info)
}

// Load restores index and scanner information from the database
func (idx *Index) Load() error {
	if !metaStoreConfigured() {
		return nil
	}

	info, err := getIndexInfoByPath(idx.Path)
	if err != nil {
		if err == errors.ErrNotExist {
			// No persisted data exists, this is fine for new indexes
			return nil
		}
		return err
	}

	idx.mu.Lock()
	defer idx.mu.Unlock()

	// Restore index-level stats
	idx.previousNumDirs = info.NumDirs
	idx.previousNumFiles = info.NumFiles
	idx.Complexity = info.Complexity
	idx.NumDirs = info.NumDirs
	idx.NumFiles = info.NumFiles
	idx.UsedAsIndexed = info.UsedAsIndexed
	idx.UsedDisk = info.UsedDisk
	idx.DiskTotal = info.DiskTotal
	idx.UsedDiskRoot = info.UsedDiskRoot
	idx.DiskTotalRoot = info.DiskTotalRoot

	// Restore scanner information (will be applied when scanners are created)
	// Store in a temporary map that setupMultiScanner can use
	if idx.scanners == nil {
		idx.scanners = make(map[string]*Scanner)
	}

	// Note: Scanners will be created by setupMultiScanner, but we'll restore
	// their stats after creation. Store the persisted scanner info for later use.
	// We'll handle this in setupMultiScanner after scanners are created.

	return nil
}

// Flush persists all index information to the database
func (idx *Index) Flush() error {
	return idx.Save()
}

import { defineConfig, devices } from "@playwright/test";
import type { PlaywrightFixtureOptions } from "./tests/playwright/test-setup";

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig<PlaywrightFixtureOptions>({
  globalSetup: "./tests/playwright/screenshots-setup.ts",
  timeout: 60_000,
  testDir: "./tests/playwright/screenshots",
  /* Run tests in files in parallel */
  fullyParallel: false,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: false,
  /* Retry on CI only */
  retries: 1,
  /* Opt out of parallel tests on CI. */
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: "line",
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    launchOptions: {
      args: [
        '--disable-gpu',
        '--use-gl=swiftshader',  // CPU-based WebGL renderer built into Chromium
        '--enable-webgl',
        '--disable-dev-shm-usage',  // Overcome limited resource problems in Docker
        '--no-sandbox',  // Required for Docker
      ],
    },
    actionTimeout: 5000,
    storageState: "loginAuth.json",
    /* Base URL to use in actions like `await page.goto('/')`. */
    baseURL: "http://localhost:8080",

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: "on-first-retry",

    /* Set default locale to English (US) */
    locale: "en-US",
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: "dark-screenshots",
      use: {
        ...devices["Desktop Chrome"],
        theme: 'dark',
      },
    },
    {
      name: "light-screenshots",
      use: {
        ...devices["Desktop Chrome"],
        theme: 'light',
      },
    },
  ],
});

#!/usr/bin/env bash
#
# GPU utilisation for the Dracula "gpu-usage" segment; replaces upstream
# scripts/gpu_usage.sh, which only measured NVIDIA/amdgpu and showed 0% on
# everything else. Reports the busiest GPU it can read without root:
#
#   NVIDIA      nvidia-smi (skipped while the card is runtime-suspended, so a
#               hybrid laptop's dGPU isn't woken every refresh)
#   amdgpu      device/gpu_busy_percent
#   Intel i915  100 - idle share of gt/gt*/rc6_residency_ms over the refresh
#   Intel xe    100 - idle share of tile*/gt*/gtidle/idle_residency_ms
#   macOS       ioreg "Device Utilization %"
#
# Prints N/A when nothing is measurable (VMs, headless servers).

export LC_ALL=en_US.UTF-8

current_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source $current_dir/utils.sh

# Cumulative idle-time counters (ms) for every Intel GT. Older i915 kernels
# only have power/rc6_residency_ms; newer ones alias it to gt0, and the
# duplicate is harmless since only the busiest reading is kept.
function idle_counter_paths {
 ls /sys/class/drm/card*/gt/gt*/rc6_residency_ms \
  /sys/class/drm/card*/power/rc6_residency_ms \
  /sys/class/drm/card*/device/tile*/gt*/gtidle/idle_residency_ms 2>/dev/null
}

function now_ms {
 date +%s%3N
}

# Largest 0-100 integer among the args; empty if none are numeric
function max_of {
 local max="" n
 for n in "$@"; do
  [[ "$n" =~ ^[0-9]+$ ]] || continue
  ((n > 100)) && n=100
  if [[ -z "$max" ]] || ((n > max)); then max=$n; fi
 done
 echo "$max"
}

function nvidia_usage {
 local smi
 smi=$(command -v nvidia-smi || ls /usr/lib/wsl/lib/nvidia-smi 2>/dev/null) || return

 # Skip only when every NVIDIA display device is asleep. No PCI entry at all
 # (WSL) means we can't tell, so ask nvidia-smi anyway.
 local dev found=0 awake=0
 for dev in /sys/bus/pci/devices/*; do
  [[ "$(cat "$dev/vendor" 2>/dev/null)" == 0x10de ]] || continue
  [[ "$(cat "$dev/class" 2>/dev/null)" == 0x03* ]] || continue
  found=1
  [[ "$(cat "$dev/power/runtime_status" 2>/dev/null)" == suspended ]] || awake=1
 done
 if ((found && !awake)); then
  echo 0
  return
 fi

 timeout 2 "$smi" --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | tr -dc '0-9\n'
}

function linux_usage {
 local refresh_rate="$1"
 local paths=() before=() samples=() i t0 t1 elapsed idle

 while IFS= read -r path; do
  paths+=("$path")
  before+=("$(cat "$path")")
 done < <(idle_counter_paths)
 t0=$(now_ms)

 sleep "$refresh_rate"

 if ((${#paths[@]})); then
  t1=$(now_ms)
  elapsed=$((t1 - t0))
  for i in "${!paths[@]}"; do
   idle=$(($(cat "${paths[$i]}") - before[i]))
   ((idle > elapsed)) && idle=$elapsed # sampling jitter
   ((elapsed > 0)) && samples+=($((100 - idle * 100 / elapsed)))
  done
 fi

 samples+=($(cat /sys/class/drm/card*/device/gpu_busy_percent 2>/dev/null))
 samples+=($(nvidia_usage))

 max_of "${samples[@]}"
}

function apple_usage {
 local refresh_rate="$1"
 sleep "$refresh_rate"
 max_of $(ioreg -r -d 1 -w 0 -c IOAccelerator 2>/dev/null |
  grep -o '"Device Utilization %"=[0-9]*' | cut -d= -f2)
}

main() {
 local refresh_rate=$(get_tmux_option "@dracula-refresh-rate" 1)
 local gpu_label=$(get_tmux_option "@dracula-gpu-usage-label" "GPU")
 local usage=""

 case "$(uname -s)" in
  Linux) usage=$(linux_usage "$refresh_rate") ;;
  Darwin) usage=$(apple_usage "$refresh_rate") ;;
  *) sleep "$refresh_rate" ;;
 esac

 if [[ -n "$usage" ]]; then
  echo "$gpu_label $(normalize_percent_len "${usage}%")"
 else
  echo "$gpu_label $(normalize_percent_len "N/A")"
 fi
}

main

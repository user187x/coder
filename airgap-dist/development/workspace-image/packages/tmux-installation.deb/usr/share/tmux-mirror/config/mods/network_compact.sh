#!/usr/bin/env bash

# Condensed replacement for Dracula's network_bandwidth.sh: "↓1.2M ↑ 34K"
# (~13 columns instead of ~29), leaving room on the status bar for battery.
# Used via `custom:network_compact.sh` in @dracula-plugins; copied into the
# Dracula scripts dir by mods/update-tpm-resources.
#
# Honors the same options as the upstream plugin:
#   @dracula-network-bandwidth           interface (auto-detected when unset)
#   @dracula-network-bandwidth-interval  extra seconds between samples

export LC_ALL=en_US.UTF-8

interface_get() {
 local name
 name="$(tmux show-option -gqv "@dracula-network-bandwidth")"
 if [[ -z $name ]] && type ip >/dev/null 2>&1; then
  name="$(ip -o route get 192.168.0.0 2>/dev/null | awk '{print $5}')"
 fi
 echo "$name"
}

# Fixed-width rate: 0-1023 B, then K/M/G with one decimal below 10.
human() {
 awk -v b="$1" 'BEGIN {
    split("B K M G", u, " ")
    i = 1
    while (b >= 1024 && i < 4) { b /= 1024; i++ }
    if (i == 1 || b >= 10) printf "%4d%s", b, u[i]
    else printf "%4.1f%s", b, u[i]
  }'
}

main() {
 local interval period iface="" new_iface counter=0 rx tx prev_rx prev_tx stats
 interval="$(tmux show-option -gqv "@dracula-network-bandwidth-interval")"
 period=$((1 + ${interval:-0}))

 while true; do
  if ((counter-- <= 0)); then
   counter=60
   new_iface="$(interface_get)"
   [[ $new_iface != "$iface" ]] && prev_rx=""
   iface=$new_iface
  fi

  stats="/sys/class/net/$iface/statistics"
  if [[ -z $iface || ! -r $stats/rx_bytes ]]; then
   echo "↓  --  ↑  --"
   counter=0
   sleep 5
   continue
  fi

  read -r rx <"$stats/rx_bytes"
  read -r tx <"$stats/tx_bytes"

  if [[ -n $prev_rx ]]; then
   echo "↓$(human $(((rx - prev_rx) / period))) ↑$(human $(((tx - prev_tx) / period)))"
  fi

  prev_rx=$rx
  prev_tx=$tx
  sleep "$period"
 done
}

main

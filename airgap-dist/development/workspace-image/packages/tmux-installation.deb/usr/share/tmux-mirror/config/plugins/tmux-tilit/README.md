<div align = "center">

<h1><a href="https://2kabhishek.github.io/tmux-tilit">tmux-tilit</a></h1>

<a href="https://github.com/2KAbhishek/tmux-tilit/blob/main/LICENSE">
<img alt="License" src="https://img.shields.io/github/license/2kabhishek/tmux-tilit?style=flat&color=eee&label="> </a>

<a href="https://github.com/2KAbhishek/tmux-tilit/graphs/contributors">
<img alt="People" src="https://img.shields.io/github/contributors/2kabhishek/tmux-tilit?style=flat&color=ffaaf2&label=People"> </a>

<a href="https://github.com/2KAbhishek/tmux-tilit/stargazers">
<img alt="Stars" src="https://img.shields.io/github/stars/2kabhishek/tmux-tilit?style=flat&color=98c379&label=Stars"></a>

<a href="https://github.com/2KAbhishek/tmux-tilit/network/members">
<img alt="Forks" src="https://img.shields.io/github/forks/2kabhishek/tmux-tilit?style=flat&color=66a8e0&label=Forks"> </a>

<a href="https://github.com/2KAbhishek/tmux-tilit/watchers">
<img alt="Watches" src="https://img.shields.io/github/watchers/2kabhishek/tmux-tilit?style=flat&color=f5d08b&label=Watches"> </a>

<a href="https://github.com/2KAbhishek/tmux-tilit/pulse">
<img alt="Last Updated" src="https://img.shields.io/github/last-commit/2kabhishek/tmux-tilit?style=flat&color=e06c75&label="> </a>

<h3>Better tiling for tmux 🪟🪓</h3>

<figure>
  <img src= "images/screenshot.png" alt="tmux-tilit Demo">
  <br/>
  <figcaption>tmux-tilit screenshot</figcaption>
</figure>

</div>

## What is this

tmux-tilit brings tiling window manager features and intuitive keybindings to your tmux workflows, boosting your productivity like never before.

## Features

- **Intuitive Tiling Management**: Split and arrange panes, layouts, workspaces with intuitive keybindings similar to tiling window managers
- **Vim/Neovim Integration**: Seamless navigation between vim/neovim splits and tmux panes
- **External Tools**: Integration with utilities like lazygit, extrakto for text grabbing and [tdo](https://github.com/2KAbhishek/tdo) for notes management
- **Session Management**: Integration with [tea](https://github.com/2KAbhishek/tmux-tea) for session management
- **Prefix Mode**: Optional prefix mode for compatibility with window managers that use Alt as default modifier
- **International Keyboard Support**: Configurable shift+number mappings for different keyboard layouts

## Prerequisites

Before you begin, ensure you have met the following requirements:

- You have installed the latest version of `tmux (>= 3.0)` and [`tpm`](https://github.com/tmux-plugins/tpm).

## Installing tmux-tilit

To get tmux-tilit, add the following to your `tmux.conf`:

```bash
set -g @plugin '2kabhishek/tmux-tilit'
```

## Using tmux-tilit

### Keybindings

<kbd>Alt</kbd> is the default `tilit-mod` key, these bindings will change if you are changing it or using `tilit-prefix`.

| Keybinding                               | Action                   |
| ---------------------------------------- | ------------------------ |
| <kbd>Alt</kbd> + <kbd>`</kbd>            | Last active window       |
| <kbd>Alt</kbd> + <kbd>,</kbd>            | Rename current window    |
| <kbd>Alt</kbd> + <kbd>/</kbd>            | Horizontal Split         |
| <kbd>Alt</kbd> + <kbd>\\</kbd>           | Vertical Split           |
| <kbd>Alt</kbd> + <kbd>[ / ]</kbd>        | Focus prev/next window   |
| <kbd>Alt</kbd> + <kbd>- / =</kbd>        | Increase/Decrease width  |
| <kbd>Alt</kbd> + <kbd>Enter</kbd>        | Create a new pane        |
| <kbd>Alt</kbd> + <kbd>0-9</kbd>          | Switch to window 0-9     |
| <kbd>Alt</kbd> + <kbd>Shift + 0-9</kbd>  | Move pane to window 0-9  |
| <kbd>Alt</kbd> + <kbd>Arrow Keys</kbd>   | Resize pane in direction |
| <kbd>Alt</kbd> + <kbd>h/j/k/l</kbd>      | Focus pane in direction  |
| <kbd>Alt</kbd> + <kbd>H/J/K/L</kbd>      | Move pane in direction   |
| <kbd>Alt</kbd> + <kbd>a</kbd>            | AI Agent Picker [tea][4] |
| <kbd>Alt</kbd> + <kbd>A</kbd>            | Opencode CLI             |
| <kbd>Alt</kbd> + <kbd>b</kbd>            | Toggle status bar        |
| <kbd>Alt</kbd> + <kbd>c</kbd>            | Edit config              |
| <kbd>Alt</kbd> + <kbd>C</kbd>            | Customize mode           |
| <kbd>Alt</kbd> + <kbd>d</kbd>            | Run launcher, [dexe][3]  |
| <kbd>Alt</kbd> + <kbd>D</kbd>            | Detach                   |
| <kbd>Alt</kbd> + <kbd>e</kbd>            | Layout: Even Vertical    |
| <kbd>Alt</kbd> + <kbd>E</kbd>            | Layout: Even Horizontal  |
| <kbd>Alt</kbd> + <kbd>f</kbd>            | Text grab [extrakto][2]  |
| <kbd>Alt</kbd> + <kbd>F</kbd>            | Fuzzy edit files         |
| <kbd>Alt</kbd> + <kbd>g</kbd>            | Open lazygit             |
| <kbd>Alt</kbd> + <kbd>i</kbd>            | Synchronize pane inputs  |
| <kbd>Alt</kbd> + <kbd>I</kbd>            | Open tilit README        |
| <kbd>Alt</kbd> + <kbd>m</kbd>            | Layout: Main Vertical    |
| <kbd>Alt</kbd> + <kbd>M</kbd>            | Layout: Main Horizontal  |
| <kbd>Alt</kbd> + <kbd>n</kbd>            | Pending todos [tdo][1]   |
| <kbd>Alt</kbd> + <kbd>N</kbd>            | Search notes [tdo][1]    |
| <kbd>Alt</kbd> + <kbd>o</kbd>            | Open floating terminal   |
| <kbd>Alt</kbd> + <kbd>p</kbd>            | Last active pane         |
| <kbd>Alt</kbd> + <kbd>q</kbd>            | Close session            |
| <kbd>Alt</kbd> + <kbd>r</kbd>            | Reload config            |
| <kbd>Alt</kbd> + <kbd>R</kbd>            | Rotate window            |
| <kbd>Alt</kbd> + <kbd>s</kbd>            | Show all panes           |
| <kbd>Alt</kbd> + <kbd>t</kbd>            | Session manager [tea][1] |
| <kbd>Alt</kbd> + <kbd>T</kbd>            | Layout: Tiled            |
| <kbd>Alt</kbd> + <kbd>w</kbd>            | Move pane to new window  |
| <kbd>Alt</kbd> + <kbd>x</kbd>            | Close pane               |
| <kbd>Alt</kbd> + <kbd>X</kbd>            | Close window             |
| <kbd>Alt</kbd> + <kbd>y</kbd>            | Toggle copy mode         |
| <kbd>Alt</kbd> + <kbd>z</kbd>            | Layout: Zoom             |
| <kbd>Shift</kbd> + <kbd>Left/Right</kbd> | Focus prev/next window   |

#### Prefix Bindings

tmux-tilit sets up keybindings that work with the tmux `prefix` key:

| Keybinding         | Action                   |
| ------------------ | ------------------------ |
| <kbd>H/J/K/L</kbd> | Resize pane in direction |
| <kbd>r</kbd>       | Reload config            |

> Default `prefix` key is <kbd>Ctrl</kbd> + <kbd>b</kbd>

#### Copy Mode Bindings

Enable/Disable copy mode by pressing <kbd>Alt</kbd> + <kbd>y</kbd>:

> This mode supports vi navigation keys by default

| Keybinding                     | Action                      |
| ------------------------------ | --------------------------- |
| <kbd>Alt</kbd> + <kbd>y</kbd>  | Toggle/Exit copy mode       |
| <kbd>y</kbd>                   | Copy                        |
| <kbd>Ctrl</kbd> + <kbd>v</kbd> | Toggle block/rectangle mode |
| <kbd>v</kbd>                   | Start selection             |
| <kbd>V</kbd>                   | Line selection              |

[1]: https://github.com/2KAbhishek/tdo
[2]: https://github.com/laktak/extrakto
[3]: https://github.com/2KAbhishek/dexe
[4]: https://github.com/2KAbhishek/tmux-tea

### Customizing tmux-tilit

#### `config` for custom tmux config location

By default, tmux-tilit uses `$HOME/.tmux.conf` for config-related operations (reload, edit).

If your config is in a different location, you can set:

```bash
set -g @tilit-config "$HOME/.config/tmux/tmux.conf"
```

#### `autotiling` for dynamic layout splits

By default, autotiling is enabled (`'on'`). This automatically splits panes horizontally or vertically based on active pane dimensions (similar to i3/sway autotiling).

To disable this behavior:

```bash
set -g @tilit-autotiling 'off'
```

You can customize the aspect ratio threshold (default is `2.0`). Lower values trigger horizontal splits more easily:

```bash
set -g @tilit-splitratio '1.7'
```

> Note: For the best autotiling experience, it is recommended to unset `@tilit-layout` (or leave it empty) so that tmux does not force a specific static layout after splitting.

#### `easymode` for arrow key navigation

To navigate using arrow keys, you can enable easy mode with: `set -g @tilit-easymode 'on'`

The revised keybindings for the pane focus and movement then become:

| Keybinding                                                          | Description              |
| ------------------------------------------------------------------- | ------------------------ |
| <kbd>Alt</kbd> + <kbd>&#8592;/&#8595;/&#8593;/&#8594;</kbd>         | Focus pane in direction  |
| <kbd>Alt</kbd> + <kbd>Shift + &#8592;/&#8595;/&#8593;/&#8594;</kbd> | Move pane in direction   |
| <kbd>Alt</kbd> + <kbd>h/j/k/l</kbd>                                 | Resize pane in direction |

#### `layout` for customizing default layout

You can set the default layout with `set -g @tilit-default 'layout'`, this will be used when creating new windows or panes.

Available layouts are:

- `main-vertical`
- `main-horizontal`
- `tiled`
- `even-vertical`
- `even-horizontal`

#### `mod` for customizing the modifier key

By default, tmux-tilit uses `M-` (Alt/Meta) as the modifier for direct keybindings.

You can change it to another tmux modifier prefix:

```bash
# Default
set -g @tilit-mod 'M-'

# Example: Ctrl-based bindings
set -g @tilit-mod 'C-'
```

`@tilit-mod` is used only in non-prefix mode.

#### `navigator` for integrating with vim/neovim

Seamlessly navigate across vim/neovim splits and tmux panes without requiring heavy third-party plugins. Enabled by default (`'on'`):

```bash
# Default: Navigate using Ctrl + hjkl
set -g @tilit-navigator 'on'

# Navigate using Alt + hjkl (matches tilit-mod without capturing Ctrl keys)
set -g @tilit-navigator 'alt' # or 'mod' / 'M-'

# Disable seamless vim navigation (standard tmux pane switching only)
set -g @tilit-navigator 'off'

# Disable built-in pane navigation (when managing pane navigation externally)
set -g @tilit-navigator 'none'
```

<details>
<summary><b>Neovim Setup</b></summary>

Add the following to your Neovim config or use [homegrown.nvim's tmux module](https://github.com/2kabhishek/homegrown.nvim/)

```lua
local function tmux_navigate(direction)
    local winnr = vim.fn.winnr()
    vim.cmd('wincmd ' .. direction)
    if winnr == vim.fn.winnr() and vim.env.TMUX then
        local tmux_dir = { h = 'L', j = 'D', k = 'U', l = 'R' }
        vim.fn.system('tmux select-pane -' .. tmux_dir[direction])
    end
end

-- Default: Ctrl + hjkl (or change to '<M-h>', etc. if using @tilit-navigator 'alt')
vim.keymap.set('n', '<C-h>', function() tmux_navigate('h') end, { silent = true, desc = 'Tmux Navigate Left' })
vim.keymap.set('n', '<C-j>', function() tmux_navigate('j') end, { silent = true, desc = 'Tmux Navigate Down' })
vim.keymap.set('n', '<C-k>', function() tmux_navigate('k') end, { silent = true, desc = 'Tmux Navigate Up' })
vim.keymap.set('n', '<C-l>', function() tmux_navigate('l') end, { silent = true, desc = 'Tmux Navigate Right' })
```

</details>

<details>
<summary><b>Vim Setup</b></summary>

Add the following to your `~/.vimrc`:

```vim
function! s:TmuxNavigate(dir) abort
    let l:w = winnr()
    execute 'wincmd ' . a:dir
    if l:w == winnr() && exists('$TMUX')
        call system('tmux select-pane -' . get({'h':'L','j':'D','k':'U','l':'R'}, a:dir))
    endif
endfunction

" Default: Ctrl + hjkl (or change to '<M-h>', etc. if using @tilit-navigator 'alt')
nnoremap <silent> <C-h> :call <SID>TmuxNavigate('h')<CR>
nnoremap <silent> <C-j> :call <SID>TmuxNavigate('j')<CR>
nnoremap <silent> <C-k> :call <SID>TmuxNavigate('k')<CR>
nnoremap <silent> <C-l> :call <SID>TmuxNavigate('l')<CR>
```

</details>

#### `prefix` for integrating with window managers

If your window manager uses <kbd>Alt</kbd> as default modifier, it's recommended to switch to <kbd>Super</kbd> or <kbd>Meta</kbd> for a smoother experience.

If you do not want to do that you can enable prefix mode for tmux-tilit:

```bash
set -g @tilit-prefix 'C-space' # or any other key combo
set -g repeat-time 1000
```

This will let you hit <kbd>Ctrl</kbd> + <kbd>space</kbd> and then a key to perform an action, repeat-time lets you run more actions with a single prefix.

> Note: This prefix is different from the tmux default prefix.
> If you do not use C-a as your tmux prefix - I highly recommend using that as the tilit-prefix and set the tmux-prefix back to C-b

#### `shiftnum` for working with international keyboards

You can set the `@tilit-shiftnum` option to match your keyboard layout:

```bash
# US Keyboard
set -g @tilit-shiftnum '!@#$%^&*()'
# UK Keyboard
set -g @tilit-shiftnum '!"£$%^&*()'
```

## How I built this

Major credits to [tmux-tilish](https://github.com/jabirali/tmux-tilish) for the inspiration
I wanted to add some new commands and integrations, make the keybindings match better with tmux defaults.

## Challenges faced

Making sure the keybindings work across different command line programs and environments was challenging.

## What I learned

- Learned more about the tmux API.

## What's next

You tell me!

Hit the ⭐ button if you found this useful.

### 🧰 Tooling

- [dots2k](https://github.com/2kabhishek/dots2k) — Dev Environment
- [nvim2k](https://github.com/2kabhishek/nvim2k) — Personalized Editor
- [sway2k](https://github.com/2kabhishek/sway2k) — Desktop Environment
- [qute2k](https://github.com/2kabhishek/qute2k) — Personalized Browser

### 🔍 More Info

- [tmux-tea](https://github.com/2kabhishek/tmux-tea) — Simple and powerful tmux session manager
- [tmux2k](https://github.com/2kabhishek/tmux2k) — Makes your tmux statusbar pretty!

<div align="center">

<a href="https://github.com/2KAbhishek/tmux-tilit">Source</a> | <a href="https://2kabhishek.github.io/tmux-tilit">Website</a>

</div>

#!/bin/bash
# shellcheck disable=SC2016
# shellcheck disable=SC2086

CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

declare -A TILIT_OPTIONS
while IFS=' ' read -r opt val; do
    TILIT_OPTIONS["$opt"]="$val"
done < <(tmux show-options -g 2>/dev/null | grep -E "^(@tilit-|base-index)")

get_tmux_option() {
    local option="$1"
    local default="$2"
    local val="${TILIT_OPTIONS[$option]}"
    if [ -z "$val" ]; then
        val="$(tmux show-option -gqv "$option" 2>/dev/null)"
    fi
    if [ -n "$val" ]; then
        val="${val#\"}"
        val="${val%\"}"
        val="${val#\'}"
        val="${val%\'}"
        if [[ "$val" =~ ^\$[a-zA-Z_][a-zA-Z0-9_]*$ ]]; then
            local var_name="${val#\$}"
            val="${!var_name}"
        elif [[ "$val" == *"\$HOME"* ]]; then
            val="${val//\$HOME/$HOME}"
        elif [[ "$val" == "~"* ]]; then
            val="${val/#\~/$HOME}"
        fi
        printf '%s\n' "$val"
    else
        printf '%s\n' "$default"
    fi
}

# Read user options.
for opt in easymode layout navigator prefix mod shiftnum config autotiling splitratio; do
    export "$opt"="$(get_tmux_option "@tilit-$opt" "")"
done

navigator="${navigator:-on}"
autotiling="${autotiling:-on}"
splitratio="${splitratio:-2.0}"

# Determine "arrow types".
if [ "${easymode:-}" = "on" ]; then
    h='left' j='down' k='up' l='right'
    H='S-left' J='S-down' K='S-up' L='S-right'
    left='h' down='j' up='k' right='l'
else
    h='h' j='j' k='k' l='l'
    H='H' J='J' K='K' L='L'
    left='left' down='down' up='up' right='right'
fi

# Determine modifier vs. prefix key.
if [ -z "${prefix:-}" ]; then
    bind='bind -n'
    mod="${mod:-M-}"
else
    bind='bind -rT tilit' mod=''
fi

# Define a prefix key.
if [ -n "$prefix" ]; then
    tmux bind -n "$prefix" switch-client -T tilit
fi

# Autoselect default layout after creating new window.
if [ -n "${layout:-}" ]; then
    tmux set-hook -g window-linked "select-layout \"$layout\"; select-layout -E"
    tmux select-layout "$layout"
    tmux select-layout -E
fi

# Navigator integration (supports vim-tmux-navigator, Navigator.nvim, smart-splits.nvim)
is_vim="tmux display-message -p '#{@pane-is-vim}' 2>/dev/null | grep -q 1 || ps -o state= -o comm= -t '#{pane_tty}' | grep -iqE '^[^TXZ ]+ +(\\S+\\/)?g?\.?(view|n?vim?x?)(-wrapped)?(diff)?$'"
bind_pane_nav=true

case "${navigator:-}" in
    on|yes|true|C-|c-|ctrl|Ctrl)
        tmux bind-key -n C-h if-shell "$is_vim" "send-keys C-h" "select-pane -L"
        tmux bind-key -n C-j if-shell "$is_vim" "send-keys C-j" "select-pane -D"
        tmux bind-key -n C-k if-shell "$is_vim" "send-keys C-k" "select-pane -U"
        tmux bind-key -n C-l if-shell "$is_vim" "send-keys C-l" "select-pane -R"
        tmux bind-key -n C-\\ if-shell "$is_vim" "send-keys C-\\\\" "select-pane -l"

        tmux bind-key -T copy-mode-vi C-h select-pane -L
        tmux bind-key -T copy-mode-vi C-j select-pane -D
        tmux bind-key -T copy-mode-vi C-k select-pane -U
        tmux bind-key -T copy-mode-vi C-l select-pane -R
        tmux bind-key -T copy-mode-vi C-\\ select-pane -l
        ;;
    M-|m-|alt|Alt|meta|Meta|mod|\$mod)
        bind_pane_nav=false

        tmux bind-key -n "${mod}${h}" if-shell "$is_vim" "send-keys ${mod}${h}" "select-pane -L"
        tmux bind-key -n "${mod}${j}" if-shell "$is_vim" "send-keys ${mod}${j}" "select-pane -D"
        tmux bind-key -n "${mod}${k}" if-shell "$is_vim" "send-keys ${mod}${k}" "select-pane -U"
        tmux bind-key -n "${mod}${l}" if-shell "$is_vim" "send-keys ${mod}${l}" "select-pane -R"
        tmux bind-key -n "${mod}\\" if-shell "$is_vim" "send-keys ${mod}\\\\" "select-pane -l"

        tmux bind-key -T copy-mode-vi "${mod}${h}" select-pane -L
        tmux bind-key -T copy-mode-vi "${mod}${j}" select-pane -D
        tmux bind-key -T copy-mode-vi "${mod}${k}" select-pane -U
        tmux bind-key -T copy-mode-vi "${mod}${l}" select-pane -R
        tmux bind-key -T copy-mode-vi "${mod}\\" select-pane -l
        ;;
    none|manual|custom)
        bind_pane_nav=false
        ;;
esac

# Use US keyboard layout, unless configured
if [ -z "$shiftnum" ]; then
    shiftnum='!@#$%^&*()'
fi

config_path="${config:-$HOME/.tmux.conf}"
plugin_path=${TMUX_PLUGIN_MANAGER_PATH:-$HOME/.config/tmux/plugins}

char_at() {
    local str="$1"
    local idx="$2"
    echo "${str:$((idx - 1)):1}"
}

to_ratio_int() {
    local val="$1"
    if [[ "$val" != *.* ]]; then
        val="${val}.0"
    fi
    local int_part="${val%%.*}"
    local frac_part="${val#*.}"
    local first_dec="${frac_part:0:1}"
    echo "${int_part}${first_dec}"
}

# Bind keys to switch between workspaces.
bind_switch() {
    tmux $bind "$1" if-shell "tmux select-window -t :$2" "" "new-window -c '#{pane_current_path}' -t :$2"
}

# Bind keys to move panes between workspaces.
bind_move() {
    tmux $bind "$1" if-shell "tmux join-pane -t :$2" "" \
        "new-window -c '#{pane_current_path}' -dt :$2; join-pane -t :$2; select-pane -t top-left; kill-pane" \\\; select-layout \\\; select-layout -E
}

# Bind keys to switch layouts
bind_layout() {
    tmux $bind "$1" select-layout "$2" \\\; select-layout -E
}

# Base index aware mapping
if [ "$(get_tmux_option "base-index" "0")" = "1" ]; then
    bind_switch "${mod}0" 10
    bind_move "${mod}${shiftnum:9:1}" 10
else
    bind_switch "${mod}0" 0
    bind_move "${mod}${shiftnum:9:1}" 0
fi

# Switch to workspace
bind_switch "${mod}1" 1
bind_switch "${mod}2" 2
bind_switch "${mod}3" 3
bind_switch "${mod}4" 4
bind_switch "${mod}5" 5
bind_switch "${mod}6" 6
bind_switch "${mod}7" 7
bind_switch "${mod}8" 8
bind_switch "${mod}9" 9

# Move pane to workspace
bind_move "${mod}${shiftnum:0:1}" 1
bind_move "${mod}${shiftnum:1:1}" 2
bind_move "${mod}${shiftnum:2:1}" 3
bind_move "${mod}${shiftnum:3:1}" 4
bind_move "${mod}${shiftnum:4:1}" 5
bind_move "${mod}${shiftnum:5:1}" 6
bind_move "${mod}${shiftnum:6:1}" 7
bind_move "${mod}${shiftnum:7:1}" 8
bind_move "${mod}${shiftnum:8:1}" 9

tmux $bind "${mod}${left}" resize-pane -L 10
tmux $bind "${mod}${down}" resize-pane -D 5
tmux $bind "${mod}${up}" resize-pane -U 10
tmux $bind "${mod}${right}" resize-pane -R 5
tmux $bind "${mod}-" resize-pane -L 20
tmux $bind "${mod}_" resize-pane -D 10
tmux $bind "${mod}=" resize-pane -R 20
tmux $bind "${mod}+" resize-pane -U 10

if [ "$autotiling" = "on" ]; then
    ratio_int=$(to_ratio_int "$splitratio")
    tmux $bind "${mod}enter" if-shell '[ "$(expr #{pane_width} \* 10)" -ge "$(expr #{pane_height} \* '"$ratio_int"')" ]' \
        'split-pane -h -c "#{pane_current_path}"' \
        'split-pane -v -c "#{pane_current_path}"'
else
    tmux $bind "${mod}enter" split-pane -c "#{pane_current_path}"
fi
tmux $bind "${mod}/" split-pane -v -c "#{pane_current_path}"
tmux $bind "${mod}\\" split-pane -h -c "#{pane_current_path}"

tmux $bind "${mod}," command-prompt -p 'Workspace name:' 'rename-window "%%"'
tmux $bind "${mod}[" previous-window
tmux $bind "${mod}]" next-window
tmux $bind "${mod}\`" last-window

if [ "$bind_pane_nav" = "true" ]; then
    tmux $bind "${mod}${h}" select-pane -L
    tmux $bind "${mod}${j}" select-pane -D
    tmux $bind "${mod}${k}" select-pane -U
    tmux $bind "${mod}${l}" select-pane -R
fi

tmux $bind "${mod}${H}" run-shell "\"$CURRENT_DIR/scripts/move.sh\" left"
tmux $bind "${mod}${J}" run-shell "\"$CURRENT_DIR/scripts/move.sh\" down"
tmux $bind "${mod}${K}" run-shell "\"$CURRENT_DIR/scripts/move.sh\" up"
tmux $bind "${mod}${L}" run-shell "\"$CURRENT_DIR/scripts/move.sh\" right"

tmux $bind "${mod}a" run-shell "tea -a"
tmux $bind "${mod}A" display-popup -w "90%" -h "90%" -d "#{pane_current_path}" -E "opencode"
tmux $bind "${mod}b" set-option status
tmux $bind "${mod}c" display-popup -w "90%" -h "90%" -E "$EDITOR $config_path"
tmux $bind "${mod}C" customize-mode
tmux $bind "${mod}d" select-pane -t '{bottom-right}' \\\; split-pane "bash -c dexe --wait-before-exit"
tmux $bind "${mod}D" detach-client
bind_layout "${mod}e" 'even-vertical'
bind_layout "${mod}E" 'even-horizontal'
tmux $bind "${mod}f" run-shell "\"$plugin_path/extrakto/scripts/open.sh\" \"#{pane_id}\""
tmux $bind "${mod}F" display-popup -w "90%" -h "90%" -d "#{pane_current_path}" -E "$EDITOR \"\$(fzf)\""
tmux $bind "${mod}g" display-popup -w "90%" -h "90%" -d "#{pane_current_path}" -E "lazygit"
tmux $bind "${mod}i" setw synchronize-panes\\\; display-message "Synchronize panes #{?pane_synchronized,on,off}"
tmux $bind "${mod}I" display-popup -w "90%" -h "90%" -E "$EDITOR \"$CURRENT_DIR/README.md\""
bind_layout "${mod}m" 'main-vertical'
bind_layout "${mod}M" 'main-horizontal'
tmux $bind "${mod}n" display-popup -w "90%" -h "90%" -d "$NOTES_DIR" -E "tdo -t"
tmux $bind "${mod}N" display-popup -w "80%" -h "80%" -d "$NOTES_DIR" -E "tdo -f"
tmux $bind "${mod}o" display-popup -w "90%" -h "90%" -d "#{pane_current_path}" -E "$SHELL"
tmux $bind "${mod}p" last-pane
tmux $bind "${mod}q" kill-session
tmux $bind "${mod}r" source-file $config_path\\\; display-message "Config Reloaded"
tmux $bind "${mod}R" rotate-window
tmux $bind "${mod}s" choose-tree
tmux $bind "${mod}t" run-shell "tea"
bind_layout "${mod}T" 'tiled'
tmux $bind "${mod}w" break-pane
tmux $bind "${mod}x" kill-pane
tmux $bind "${mod}X" kill-window
tmux $bind "${mod}y" copy-mode
tmux $bind "${mod}z" resize-pane -Z

# Alternate move between panes
tmux bind -n S-Left previous-window
tmux bind -n S-Right next-window

# Prefix keys
tmux bind r source-file "$config_path"\\\; display-message "Config Reloaded"
tmux bind -r H resize-pane -L 10
tmux bind -r L resize-pane -R 10
tmux bind -r K resize-pane -U 5
tmux bind -r J resize-pane -D 5

# Passthrough C-hjkl
tmux bind C-h send-keys 'C-h'
tmux bind C-j send-keys 'C-j'
tmux bind C-k send-keys 'C-k'
tmux bind C-l send-keys 'C-l'

# Copy mode bindings
tmux bind-key -T copy-mode-vi 'v' send -X begin-selection
tmux bind-key -T copy-mode-vi 'y' send -X copy-selection
tmux bind-key -T copy-mode-vi 'C-v' send-keys -X rectangle-toggle
tmux bind-key -T copy-mode-vi "${mod}y" send-keys -X cancel
tmux bind-key -T copy-mode "${mod}y" send-keys -X cancel

# Autorefresh layout after deleting a pane.
if [ "$autotiling" = "on" ]; then
    tmux set-hook -g after-split-window "select-layout -E"
    tmux set-hook -g pane-exited "select-layout -E"
else
    tmux set-hook -g after-split-window "select-layout; select-layout -E"
    tmux set-hook -g pane-exited "select-layout; select-layout -E"
fi
